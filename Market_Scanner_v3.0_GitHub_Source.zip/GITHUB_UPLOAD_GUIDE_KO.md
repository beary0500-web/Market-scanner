# GitHub 업로드 및 APK 빌드 안내 (v3.0-dev)

## 업로드 전 확인

- 브랜치: `v2.1-dev`를 계속 사용하거나 별도 `v3.0-dev` 브랜치를 생성
- ZIP 파일만 올리면 저장소의 소스 구조가 갱신되지 않음. ZIP을 압축 해제한 내부 파일과 폴더를 저장소 루트에 업로드해야 함.
- 기존 `.github/workflows/android.yml`도 새 파일로 교체해야 v3.0-dev 빌드 설정이 적용됨.
- 기존 `Market_Scanner_v2.1_GitHub_Source.zip` 파일은 보관용으로 남겨도 무방.

## GitHub Actions

`.github/workflows/android.yml`은 `app/**`, Gradle 설정, workflow 변경 시 Android Debug APK를 빌드합니다.

빌드 성공 시 Actions 실행 상세의 Artifacts에서 `market-scanner-v3-debug-apk`를 다운로드합니다.

## 모바일에서 업로드할 때

1. ZIP을 다운로드하고 삼성 내 파일에서 압축을 풉니다.
2. GitHub 저장소에서 대상 브랜치를 선택합니다.
3. Add file → Upload files를 선택합니다.
4. 압축 해제된 최상위 폴더 내부의 파일·폴더를 저장소 루트에 업로드합니다. `app`, `backend`, `docs`, `.github`, Gradle 파일 등을 포함합니다.
5. 기존 파일과 경로가 겹치는 경우 교체를 확인합니다.
6. Commit changes 후 Actions 실행 결과를 확인합니다.

## 보안

- `.env`, 실제 API Key, EODHD 토큰, DART 키, SEC 개인 연락처 값, 개인 계좌 정보는 업로드하지 않습니다.
- 앱에 입력하는 서버 API Key는 세션 메모리에서만 사용합니다.
- Toss Client ID/Secret 및 증권사 주문 자격증명은 사용하지 않습니다.

## 주의

APK 빌드 성공은 앱 패키징 성공을 의미할 뿐, 시장 데이터 서버가 배포되었거나 실데이터 추천·푸시 알림이 작동한다는 의미가 아닙니다.
