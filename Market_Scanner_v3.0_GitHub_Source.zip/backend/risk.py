"""Portfolio-level risk gates. These are configurable guardrails, not return forecasts."""
from __future__ import annotations
from dataclasses import dataclass
from math import isfinite

@dataclass
class RiskConfig:
    account_value: float = 6_000_000
    max_position_pct: float = 0.15
    max_sector_pct: float = 0.25
    max_country_pct: float = 0.40
    per_trade_risk_pct: float = 0.005
    warning_drawdown_pct: float = -5.0
    reduce_drawdown_pct: float = -7.5
    halt_drawdown_pct: float = -10.0

    def __post_init__(self):
        values=(self.account_value,self.max_position_pct,self.max_sector_pct,self.max_country_pct,
                self.per_trade_risk_pct,self.warning_drawdown_pct,self.reduce_drawdown_pct,self.halt_drawdown_pct)
        if not all(isfinite(float(v)) for v in values):
            raise ValueError("RiskConfig values must be finite")
        if self.account_value<=0 or not 0<self.per_trade_risk_pct<=1:
            raise ValueError("account_value must be positive and per_trade_risk_pct in (0,1]")
        if any(not 0<=v<=1 for v in (self.max_position_pct,self.max_sector_pct,self.max_country_pct)):
            raise ValueError("position/sector/country limits must be between 0 and 1")
        if not (0>=self.warning_drawdown_pct>self.reduce_drawdown_pct>self.halt_drawdown_pct>=-100):
            raise ValueError("drawdown thresholds must be ordered from warning to halt within [-100,0]")

def drawdown_state(drawdown_pct: float, cfg: RiskConfig | None = None) -> dict:
    c=cfg or RiskConfig()
    if not isfinite(float(drawdown_pct)) or drawdown_pct>0 or drawdown_pct < -100:
        raise ValueError("drawdown_pct must be finite and between -100 and 0")
    if drawdown_pct <= c.halt_drawdown_pct:
        return {"state":"HALT","allow_new_buys":False,"buy_budget_multiplier":0.0,
                "action":"자동매매 중단 및 사용자 검토"}
    if drawdown_pct <= c.reduce_drawdown_pct:
        return {"state":"REDUCE_RISK","allow_new_buys":False,"buy_budget_multiplier":0.0,
                "action":"신규매수 중단 및 위험 노출 축소"}
    if drawdown_pct <= c.warning_drawdown_pct:
        return {"state":"WARNING","allow_new_buys":True,"buy_budget_multiplier":0.5,
                "action":"신규매수 예산 50% 감축"}
    return {"state":"NORMAL","allow_new_buys":True,"buy_budget_multiplier":1.0,
            "action":"기본 위험 한도 적용"}

def size_position(account_value: float, entry: float, stop: float, available_cash: float,
                  current_position_value: float=0, sector_exposure: float=0,
                  country_exposure: float=0, drawdown_pct: float=0,
                  cost_buffer_pct: float=0, gap_buffer_pct: float=0,
                  cfg: RiskConfig | None=None) -> dict:
    c=cfg or RiskConfig(account_value=account_value)
    vals=[account_value,entry,stop,available_cash,current_position_value,sector_exposure,country_exposure,
          cost_buffer_pct,gap_buffer_pct]
    if not all(isfinite(float(v)) for v in vals+[drawdown_pct]):
        raise ValueError("Sizing inputs must be finite numbers")
    if any(v < 0 for v in vals) or entry <= 0 or stop <= 0 or stop >= entry:
        raise ValueError("Invalid sizing inputs: require positive entry and stop below entry; other values non-negative")
    if cost_buffer_pct > 20 or gap_buffer_pct > 50:
        raise ValueError("cost_buffer_pct must be <=20 and gap_buffer_pct <=50")
    state=drawdown_state(drawdown_pct,c)
    risk_budget=account_value*c.per_trade_risk_pct*state["buy_budget_multiplier"]
    # Cost and adverse-gap buffers are optional explicit assumptions. Defaults
    # are zero because a universal fee/slippage estimate would be misleading.
    per_share_risk=(entry-stop) + entry*((cost_buffer_pct+gap_buffer_pct)/100)
    risk_qty=int(risk_budget//per_share_risk) if risk_budget else 0
    pos_cap=account_value*c.max_position_pct
    pos_qty=int(max(0,pos_cap-current_position_value)//entry)
    cash_qty=int(available_cash//entry)
    sector_room=max(0,account_value*c.max_sector_pct-sector_exposure)
    country_room=max(0,account_value*c.max_country_pct-country_exposure)
    sector_qty=int(sector_room//entry)
    country_qty=int(country_room//entry)
    qty=min(risk_qty,pos_qty,cash_qty,sector_qty,country_qty)
    if not state["allow_new_buys"]: qty=0
    return {"quantity":qty,"investment":qty*entry,"planned_stop_loss":qty*per_share_risk,
            "risk_budget":risk_budget,"risk_per_share_including_buffers":per_share_risk,
            "buffers":{"cost_pct":cost_buffer_pct,"gap_pct":gap_buffer_pct},
            "limits":{"risk_qty":risk_qty,"position_qty":pos_qty,
            "cash_qty":cash_qty,"sector_qty":sector_qty,"country_qty":country_qty},
            "drawdown":state,"config":{"per_trade_risk_pct":c.per_trade_risk_pct,
            "max_position_pct":c.max_position_pct,"max_sector_pct":c.max_sector_pct,
            "max_country_pct":c.max_country_pct}}

def portfolio_exposure(positions: list[dict], account_value: float) -> dict:
    if not isfinite(float(account_value)) or account_value <= 0: raise ValueError("account_value must be positive and finite")
    by_sector={}; by_country={}; total=0.0
    for p in positions:
        value=float(p.get("market_value",0))
        if not isfinite(value): raise ValueError("market_value must be finite")
        if value<0: raise ValueError("market_value cannot be negative")
        total+=value
        by_sector[p.get("sector","UNKNOWN")]=by_sector.get(p.get("sector","UNKNOWN"),0)+value
        by_country[p.get("country","UNKNOWN")]=by_country.get(p.get("country","UNKNOWN"),0)+value
    return {"invested_value":total,"cash_estimate":max(0,account_value-total),
            "gross_exposure_pct":total/account_value*100,
            "sector_exposure_pct":{k:v/account_value*100 for k,v in by_sector.items()},
            "country_exposure_pct":{k:v/account_value*100 for k,v in by_country.items()},
            "over_invested":total>account_value}
