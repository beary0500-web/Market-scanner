"""Optional EODHD ETF fundamentals quality adapter with fail-closed validation."""
from __future__ import annotations
import os, time
import httpx
BASE_URL="https://eodhd.com/api/v1.1/fundamentals"
_CACHE: dict[str, tuple[float,dict]]={}
_TTL=6*60*60
class ETFQualityNotConfigured(RuntimeError): pass
class ETFQualityProviderError(RuntimeError): pass

def normalize_etf_fundamentals(payload:dict)->dict:
    general=payload.get("General") or {}; data=payload.get("ETF_Data") or {}
    if not isinstance(data,dict): raise ETFQualityProviderError("ETF_Data section is missing")
    expense=data.get("NetExpenseRatio")
    if expense is None: expense=data.get("Ongoing_Charge")
    if expense is None: expense=general.get("NetExpenseRatio")
    assets=data.get("TotalAssets")
    if assets is None: assets=data.get("Portfolio_Net_Assets")
    holdings_count=data.get("Holdings_Count")
    holdings=data.get("Holdings")
    if holdings_count is None and isinstance(holdings,(dict,list)): holdings_count=len(holdings)
    top10=data.get("Top_10_Holdings"); weights=[]
    iterable=top10.values() if isinstance(top10,dict) else top10 if isinstance(top10,list) else []
    for item in iterable:
        if isinstance(item,dict):
            weight=item.get("Assets_%")
            if weight is None: weight=item.get("Weight",item.get("weight"))
            if isinstance(weight,(int,float)): weights.append(float(weight))
    concentration=sum(weights) if weights else None
    expense=float(expense) if isinstance(expense,(int,float)) else None
    assets=float(assets) if isinstance(assets,(int,float)) else None
    holdings_count=int(holdings_count) if isinstance(holdings_count,(int,float)) else None
    if expense is None or assets is None or holdings_count is None:
        return {"status":"INSUFFICIENT_DATA","expense_ratio_pct":expense,"total_assets":assets,"holdings_count":holdings_count,"top10_concentration_pct":concentration,"source":"EODHD ETF fundamentals"}
    if expense<0 or expense>10 or assets<=0 or holdings_count<=0: return {"status":"INVALID_DATA","source":"EODHD ETF fundamentals"}
    cost=max(0.0,min(100.0,100.0-expense*20.0)); breadth=min(100.0,holdings_count/5.0)
    parts=[cost,breadth]
    if concentration is not None: parts.append(max(0.0,min(100.0,100.0-max(0.0,concentration-20.0)*1.25)))
    return {"status":"AVAILABLE","expense_ratio_pct":expense,"total_assets":assets,"holdings_count":holdings_count,"top10_concentration_pct":concentration,"quality_score":round(sum(parts)/len(parts),2),"source":"EODHD ETF fundamentals"}

async def fetch_etf_quality(symbol:str,exchange:str)->dict:
    token=os.getenv("EODHD_API_TOKEN")
    if not token: raise ETFQualityNotConfigured("EODHD_API_TOKEN is required for ETF fundamentals")
    ticker=f"{symbol}.{exchange}"; cached=_CACHE.get(ticker); now=time.monotonic()
    if cached and now-cached[0]<_TTL: return cached[1]
    try:
        async with httpx.AsyncClient(timeout=20,headers={"User-Agent":"MarketScanner/2.0 ETF fundamentals"}) as client:
            response=await client.get(f"{BASE_URL}/{ticker}",params={"api_token":token,"filter":"General,ETF_Data"}); response.raise_for_status(); payload=response.json()
        if not isinstance(payload,dict): raise ETFQualityProviderError("Unexpected ETF fundamentals payload")
        result=normalize_etf_fundamentals(payload); _CACHE[ticker]=(time.monotonic(),result); return result
    except (httpx.HTTPError,ValueError) as exc: raise ETFQualityProviderError(f"ETF fundamentals lookup failed for {ticker}: {exc}") from exc
