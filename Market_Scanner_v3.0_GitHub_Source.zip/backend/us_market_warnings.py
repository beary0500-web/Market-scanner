"""Official Nasdaq Trader RSS feed adapter for current US trading halts."""
from __future__ import annotations
import asyncio, time, xml.etree.ElementTree as ET
from typing import Any
import httpx
NASDAQ_HALT_RSS = "https://www.nasdaqtrader.com/rss.aspx?feed=tradehalts"
_CACHE: dict[str, Any] = {"at": 0.0, "symbols": {}}
_LOCK = asyncio.Lock()
_TTL = 60.0
class USWarningProviderError(RuntimeError): pass

def parse_halt_rss(xml_bytes: bytes) -> dict[str, list[dict]]:
    try: root = ET.fromstring(xml_bytes)
    except ET.ParseError as exc: raise USWarningProviderError("Invalid Nasdaq Trader halt RSS XML") from exc
    result: dict[str, list[dict]] = {}
    for item in root.findall(".//item"):
        title = (item.findtext("title") or "").strip()
        description = (item.findtext("description") or "").strip()
        words = title.replace(",", " ").split()
        symbol = None
        for index, word in enumerate(words):
            if word.lower() == "security" and index + 1 < len(words):
                symbol = words[index + 1].strip(" .,:;").upper(); break
        if not symbol:
            lower = description.lower(); marker = "symbol:"
            if marker in lower:
                symbol = description[lower.index(marker)+len(marker):].split()[0].strip(" .,:;").upper()
        if symbol:
            result.setdefault(symbol, []).append({"source":"Nasdaq Trader current trading halts RSS", "title":title[:300], "description":description[:1000]})
    return result

async def fetch_us_trading_halts(client: httpx.AsyncClient | None = None) -> dict[str, list[dict]]:
    now=time.monotonic()
    if now-_CACHE["at"] < _TTL: return _CACHE["symbols"]
    async with _LOCK:
        now=time.monotonic()
        if now-_CACHE["at"] < _TTL: return _CACHE["symbols"]
        own=client is None
        session=client or httpx.AsyncClient(timeout=15, headers={"User-Agent":"MarketScanner/2.0 (US trading halt compliance)"})
        try:
            response=await session.get(NASDAQ_HALT_RSS); response.raise_for_status()
            symbols=parse_halt_rss(response.content)
            _CACHE.update({"at":time.monotonic(),"symbols":symbols})
            return symbols
        except httpx.HTTPError as exc: raise USWarningProviderError(f"Nasdaq Trader halt feed unavailable: {exc}") from exc
        finally:
            if own: await session.aclose()
