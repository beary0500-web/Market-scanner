import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from scoring import score_snapshot

def test_missing_data_is_not_neutral_imputed():
    r = score_snapshot({"price": 100, "ma20": 90, "ma50": 80, "ma200": 70,
                        "return_3m_pct": 5, "return_6m_pct": 10, "return_12m_pct": 15,
                        "volatility_annual_pct": 20, "max_drawdown_pct": -10,
                        "avg_daily_turnover": 2_000_000})
    assert r["components"]["fundamentals"] is None
    assert r["components"]["valuation"] is None
    assert r["coverage_pct"] == 75.0
    assert r["status"] == "PARTIAL"

def test_no_data_has_no_score():
    r = score_snapshot({})
    assert r["score"] is None
    assert r["coverage_pct"] == 0



def test_fundamental_subscore_uses_sec_ttm_aliases():
    from scoring import fundamental_subscore
    score, detail = fundamental_subscore({
        "revenue_ttm_yoy_pct": 20,
        "net_income_ttm_yoy_pct": 10,
        "roe_pct": 12,
        "operating_margin_ttm_pct": 18,
        "net_margin_ttm_pct": 9,
        "debt_to_assets_pct": 30,
        "fcf_margin_ttm_pct": 8,
    })
    assert score is not None
    assert 0 <= score <= 100
    assert len(detail) == 7


def test_fundamental_subscore_does_not_invent_missing_metrics():
    from scoring import fundamental_subscore
    score, detail = fundamental_subscore({})
    assert score is None
    assert detail == {}


def test_fundamental_subscore_bounds_extreme_values():
    from scoring import fundamental_subscore
    score, detail = fundamental_subscore({
        "revenue_ttm_yoy_pct": 10000,
        "net_income_ttm_yoy_pct": -10000,
        "roe_pct": 10000,
        "operating_margin_ttm_pct": -10000,
        "debt_to_assets_pct": 10000,
        "fcf_margin_ttm_pct": 10000,
    })
    assert 0 <= score <= 100
    assert all(0 <= value <= 100 for value in detail.values())


def test_score_snapshot_includes_auditable_fundamental_detail():
    from scoring import score_snapshot
    result = score_snapshot({"revenue_ttm_yoy_pct": 15, "roe_pct": 10,
                             "debt_to_assets_pct": 25})
    assert result["components"]["fundamentals"] is not None
    assert set(result["fundamental_detail"]) == {"revenue_growth", "roe", "leverage"}



def test_fundamentals_prefers_total_liabilities_to_assets_for_comparability():
    from scoring import fundamental_subscore
    score, detail = fundamental_subscore({"liabilities_to_assets_pct": 40})
    assert score == 50.0
    assert detail["leverage"] == 50.0



def test_valuation_component_blends_per_and_pbr_when_both_exist():
    from scoring import score_snapshot
    result = score_snapshot({"per": 10, "pbr": 2})
    assert result["components"]["valuation"] == 84.5
