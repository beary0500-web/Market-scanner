from datetime import date
import pytest
from bulk_market import (BulkMarketStore, BulkMarketBudgetError,
                         parse_bulk_csv)


def test_parse_bulk_csv_adjusts_ohlc_to_adjusted_close():
    payload=("code,exchange,date,open,high,low,close,adjusted_close,volume\n"
             "AAA,US,2026-11-20,100,110,90,100,95,1000\n")
    day,rows=parse_bulk_csv(payload,"2026-11-20")
    assert day=="2026-11-20"
    assert rows[0]["close"]==95
    assert rows[0]["open"]==95
    assert rows[0]["high"]==104.5


def test_bulk_refresh_enforces_100_units_per_missing_weekday_before_network(tmp_path):
    class CalendarResponse:
        status_code=200
        def raise_for_status(self): pass
        def json(self): return {"ExchangeHolidays":{}}
    class Client:
        async def get(self,url,params=None): return CalendarResponse()
    store=BulkMarketStore(db_path=str(tmp_path/"db.sqlite"),token="fake",client=Client())
    with pytest.raises(BulkMarketBudgetError):
        import asyncio
        asyncio.run(store.refresh("US",date(2026,11,20),date(2026,11,20),99))


def test_bulk_refresh_caches_exchange_day_and_reuses_snapshot(tmp_path):
    import asyncio
    class Response:
        status_code=200
        text=("code,exchange,date,open,high,low,close,adjusted_close,volume\n"
              "AAA,US,2026-11-20,100,110,90,100,100,1000\n")
        def raise_for_status(self): pass
        def json(self): return [{"Code":"AAA","Name":"Alpha","Type":"Common Stock"}]
    class Client:
        def __init__(self): self.calls=[]
        async def get(self,url,params=None):
            self.calls.append((url,params))
            if "exchange-details" in url:
                class CalendarResponse:
                    status_code=200
                    def raise_for_status(self): pass
                    def json(self): return {"ExchangeHolidays":{"2026-11-19":{"Date":"2026-11-19","Type":"Official"}}}
                return CalendarResponse()
            if "exchange-symbol-list" in url:
                class MasterResponse:
                    status_code=200
                    def raise_for_status(self): pass
                    def json(self): return [{"Code":"AAA","Name":"Alpha","Type":"Common Stock"}]
                return MasterResponse()
            return Response()
    client=Client(); store=BulkMarketStore(db_path=str(tmp_path/"db.sqlite"),token="fake",client=client)
    async def run():
        first=await store.refresh("US",date(2026,11,20),date(2026,11,20),100)
        second=await store.refresh("US",date(2026,11,20),date(2026,11,20),0)
        master=await store.exchange_symbols("US")
        return first,second,master
    first,second,master=asyncio.run(run())
    assert first["api_call_units_used"]==100
    assert second["api_call_units_used"]==0
    assert len(client.calls)==3
    assert master["AAA"]["Type"]=="Common Stock"
    series=store.load_series("US",date(2026,11,20),date(2026,11,20),1)
    assert series["AAA"][0]["close"]==100



def test_bulk_store_supports_kosdaq_exchange_code():
    from bulk_market import ALLOWED_EXCHANGES
    assert "KQ" in ALLOWED_EXCHANGES
