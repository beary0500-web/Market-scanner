import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from universe import _rows, parse_krx_rows

def test_nasdaq_pipe_file_parser_skips_metadata():
    raw = "Symbol|Security Name|Market Category|Test Issue|Financial Status\nAAPL|Apple Inc.|Q|N|N\nTEST|Test Co|Q|Y|N\nFile Creation Time: 0101202600:00||||\n"
    rows = _rows(raw)
    assert len(rows) == 2
    assert rows[0]["Symbol"] == "AAPL"

def test_krx_symbol_normalization():
    rows = parse_krx_rows([{"ISU_SRT_CD":"005930","ISU_ABBRV":"삼성전자"}], "KOSPI")
    assert rows[0].symbol == "005930"
    assert rows[0].name == "삼성전자"
