import os,sys
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from selection import market_regime, correlation_matrix, decide_candidates

def bars(values):
    return [{"date":f"2025-{i//28+1:02d}-{i%28+1:02d}","close":v} for i,v in enumerate(values)]

def test_market_regime_requires_history():
    assert market_regime(bars(list(range(100,150)))[0:])['state']=="UNKNOWN"

def test_bull_regime():
    data=bars([100+i*.5 for i in range(220)])
    assert market_regime(data)['state']=="BULL"

def test_correlation_identical_series():
    a=bars([100+i for i in range(40)])
    out=correlation_matrix({"A":a,"B":a},30)
    assert out['matrix']['A']['B']==1.0

def test_decision_blocks_low_coverage_and_bear_market():
    c={"symbol":"ABC","score":90,"coverage_pct":90,"status":"OK","observations":250,
       "price":120,"ma200":100,"return_3m_pct":10,"volatility_annual_pct":20}
    assert decide_candidates([c],{"state":"BEAR"})[0]['decision']=="BLOCKED"
    c['coverage_pct']=40
    assert decide_candidates([c],{"state":"BULL"})[0]['decision']=="BLOCKED"

def test_decision_candidate_not_order():
    c={"symbol":"ABC","score":90,"coverage_pct":90,"status":"OK","observations":250,
       "price":120,"ma200":100,"return_3m_pct":10,"volatility_annual_pct":20}
    assert decide_candidates([c],{"state":"BULL"})[0]['decision']=="BUY_CANDIDATE"

def test_decision_blocks_high_correlation_to_existing_holding():
    c={"symbol":"NEW","score":90,"coverage_pct":90,"status":"OK","observations":250,
       "price":120,"ma200":100,"return_3m_pct":10,"volatility_annual_pct":20}
    result=decide_candidates([c],{"state":"BULL"},[{"symbol":"HELD"}],5,
                             {"NEW":{"HELD":0.91}})
    assert result[0]['decision']=="BLOCKED"
    assert any("상관계수" in x for x in result[0]['blockers'])



def test_decision_limits_correlation_between_new_candidates():
    base = {"score": 90, "coverage_pct": 90, "status": "OK", "observations": 250,
            "price": 120, "ma200": 100, "return_3m_pct": 10,
            "volatility_annual_pct": 20}
    candidates = [{**base, "symbol": "A"}, {**base, "symbol": "B"}]
    correlations = {"matrix": {"A": {"B": 0.93}, "B": {"A": 0.93}}}
    result = decide_candidates(candidates, {"state": "BULL"}, [], 5,
                               correlations, 0.85)
    decisions = {x["symbol"]: x["decision"] for x in result}
    assert decisions["A"] == "BUY_CANDIDATE"
    assert decisions["B"] == "WATCH"
    assert any("중복 위험" in x for item in result if item["symbol"] == "B"
               for x in item["blockers"])


def test_candidate_with_required_but_missing_fundamentals_is_not_buy_candidate():
    c={"symbol":"ABC","score":90,"coverage_pct":90,"status":"OK","observations":250,
       "price":120,"ma200":100,"return_3m_pct":10,"volatility_annual_pct":20,
       "fundamentals_required":True,"fundamentals_status":"NOT_ATTACHED"}
    result=decide_candidates([c],{"state":"BULL"})[0]
    assert result["decision"] == "BLOCKED"
    assert "필수 재무 데이터 미확보" in result["blockers"]



def test_candidate_with_missing_existing_holding_history_is_blocked():
    c={"symbol":"ABC","score":90,"coverage_pct":90,"status":"OK","observations":250,
       "price":120,"ma200":100,"return_3m_pct":10,"volatility_annual_pct":20,
       "holdings_required":True,"holdings_loaded":True,
       "holdings_history_complete":False}
    result=decide_candidates([c],{"state":"BULL"})[0]
    assert result["decision"] == "BLOCKED"
    assert "기존 보유종목 가격이력 미확보" in result["blockers"]



def test_candidate_with_open_buy_order_is_blocked_to_prevent_duplicate():
    c={"symbol":"ABC","score":90,"coverage_pct":90,"status":"OK","observations":250,
       "price":120,"ma200":100,"return_3m_pct":10,"volatility_annual_pct":20,
       "open_order_pending":True}
    result=decide_candidates([c],{"state":"BULL"})[0]
    assert result["decision"] == "BLOCKED"
    assert "동일 종목 미체결 매수주문 존재" in result["blockers"]



def test_candidate_with_active_or_unavailable_warnings_is_blocked():
    c={"symbol":"ABC","score":90,"coverage_pct":90,"status":"OK","observations":250,
       "price":120,"ma200":100,"return_3m_pct":10,"volatility_annual_pct":20,
       "warnings_required":True,"warnings_status":"ACTIVE"}
    result=decide_candidates([c],{"state":"BULL"})[0]
    assert result["decision"] == "BLOCKED"
    assert "토스 매수 유의사항 존재 또는 조회 실패" in result["blockers"]



def test_etf_without_fundamental_quality_data_is_not_buy_candidate():
    c={"symbol":"069500","score":95,"coverage_pct":95,"status":"OK","observations":260,
       "price":40000,"ma200":35000,"return_3m_pct":10,"volatility_annual_pct":15,
       "etf_quality_required":True,"etf_quality_status":"NOT_CONFIGURED"}
    result=decide_candidates([c],{"state":"BULL"})[0]
    assert result["decision"] == "BLOCKED"
    assert "ETF 기초정보·비용 데이터 미확보" in result["blockers"]


def test_candidate_blocked_when_sector_cap_would_be_exceeded():
    c={"symbol":"AAA","market":"US","sector":"Technology","score":90,
       "coverage_pct":90,"status":"OK","observations":250,"price":120,
       "ma200":100,"return_3m_pct":10,"volatility_annual_pct":20,
       "portfolio_exposure_required":True}
    result=decide_candidates([c],{"state":"BULL"},sector_exposure_pct={"Technology":.15},
        country_exposure_pct={"US":.10},max_position_pct=.15,max_sector_pct=.25,
        max_country_pct=.40,sector_coverage_pct=100)[0]
    assert result["decision"]=="BLOCKED"
    assert "섹터 한도 초과" in result["blockers"][0]


def test_candidate_blocked_when_country_cap_would_be_exceeded():
    c={"symbol":"AAA","market":"US","sector":"Technology","score":90,
       "coverage_pct":90,"status":"OK","observations":250,"price":120,
       "ma200":100,"return_3m_pct":10,"volatility_annual_pct":20,
       "portfolio_exposure_required":True}
    result=decide_candidates([c],{"state":"BULL"},sector_exposure_pct={"Technology":.05},
        country_exposure_pct={"US":.30},max_position_pct=.15,max_sector_pct=.25,
        max_country_pct=.40,sector_coverage_pct=100)[0]
    assert result["decision"]=="BLOCKED"
    assert any("국가 한도 초과" in x for x in result["blockers"])


def test_candidate_blocked_when_sector_classification_coverage_is_insufficient():
    c={"symbol":"AAA","market":"US","sector":"Technology","score":90,
       "coverage_pct":90,"status":"OK","observations":250,"price":120,
       "ma200":100,"return_3m_pct":10,"volatility_annual_pct":20,
       "portfolio_exposure_required":True}
    result=decide_candidates([c],{"state":"BULL"},sector_coverage_pct=70)[0]
    assert result["decision"]=="BLOCKED"
    assert any("섹터 분류 커버리지" in x for x in result["blockers"])


def test_candidate_with_missing_sector_metadata_is_blocked_for_account_scan():
    c={"symbol":"AAA","market":"US","score":90,"coverage_pct":90,"status":"OK",
       "observations":250,"price":120,"ma200":100,"return_3m_pct":10,
       "volatility_annual_pct":20,"portfolio_exposure_required":True}
    result=decide_candidates([c],{"state":"BULL"},sector_coverage_pct=100)[0]
    assert result["decision"]=="BLOCKED"
    assert "후보 종목 섹터 정보 미확보" in result["blockers"]


def test_existing_holding_is_not_recommended_as_new_buy_candidate():
    c={"symbol":"AAA","score":90,"coverage_pct":90,"status":"OK","observations":250,
       "price":120,"ma200":100,"return_3m_pct":10,"volatility_annual_pct":20}
    result=decide_candidates([c],{"state":"BULL"},holdings=[{"symbol":"AAA"}])[0]
    assert result["decision"]=="BLOCKED"
    assert any("이미 보유 중인 종목" in x for x in result["blockers"])
