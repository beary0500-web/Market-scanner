import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from fastapi import HTTPException
from main import authorize

def test_auth_fails_closed_without_api_key(monkeypatch):
    monkeypatch.delenv("API_KEY", raising=False)
    try:
        authorize(None)
        assert False, "must reject"
    except HTTPException as exc:
        assert exc.status_code == 503

def test_auth_rejects_wrong_key(monkeypatch):
    monkeypatch.setenv("API_KEY", "secret-test")
    try:
        authorize("wrong")
        assert False, "must reject"
    except HTTPException as exc:
        assert exc.status_code == 401

def test_auth_accepts_matching_key(monkeypatch):
    monkeypatch.setenv("API_KEY", "secret-test")
    assert authorize("secret-test") is None
