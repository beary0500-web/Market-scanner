import pytest
import watchlist


def test_watchlist_persists_and_limits(monkeypatch,tmp_path):
    monkeypatch.setattr(watchlist,"DB_PATH",str(tmp_path/"w.sqlite3"))
    rows=watchlist.set_watchlist([{"symbol":"AAPL.US","market":"US"},{"symbol":"005930.KO","market":"KR","name":"삼성전자"}])
    assert len(rows)==2
    assert {x["symbol"] for x in rows}=={"AAPL.US","005930.KO"}
    with pytest.raises(ValueError):
        watchlist.set_watchlist([{"symbol":f"S{i}.US","market":"US"} for i in range(13)])


def test_watchlist_rejects_wrong_market_suffix(monkeypatch,tmp_path):
    monkeypatch.setattr(watchlist,"DB_PATH",str(tmp_path/"w.sqlite3"))
    with pytest.raises(ValueError):
        watchlist.set_watchlist([{"symbol":"AAPL","market":"US"}])


def test_daily_usage_and_quota(monkeypatch,tmp_path):
    monkeypatch.setattr(watchlist,"DB_PATH",str(tmp_path/"w.sqlite3"))
    for _ in range(20): watchlist._reserve_call()
    assert watchlist.usage()["used"]==20
    with pytest.raises(watchlist.WatchlistQuotaExceeded): watchlist._reserve_call()
