import os,sys
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from risk import drawdown_state, size_position, portfolio_exposure

def test_drawdown_gates():
    assert drawdown_state(-4)["state"]=="NORMAL"
    assert drawdown_state(-5)["buy_budget_multiplier"]==0.5
    assert drawdown_state(-7.5)["allow_new_buys"] is False
    assert drawdown_state(-10)["state"]=="HALT"

def test_position_size_uses_minimum_of_all_limits():
    result=size_position(6_000_000,100_000,92_000,2_000_000,
                         sector_exposure=1_400_000,country_exposure=1_000_000)
    assert result["quantity"]==1
    assert result["planned_stop_loss"]==8_000
    assert result["limits"]["risk_qty"]==3
    assert result["limits"]["sector_qty"]==1

def test_position_size_blocks_buys_after_drawdown():
    result=size_position(6_000_000,100_000,92_000,2_000_000,drawdown_pct=-8)
    assert result["quantity"]==0

def test_exposure_rollup():
    result=portfolio_exposure([
        {"market_value":500_000,"sector":"Tech","country":"US"},
        {"market_value":300_000,"sector":"Tech","country":"KR"}],6_000_000)
    assert result["invested_value"]==800_000
    assert round(result["sector_exposure_pct"]["Tech"],2)==13.33



def test_position_size_can_include_explicit_cost_and_gap_buffers():
    base = size_position(6_000_000, 100_000, 92_000, 2_000_000)
    buffered = size_position(6_000_000, 100_000, 92_000, 2_000_000,
                             cost_buffer_pct=0.2, gap_buffer_pct=1.0)
    assert base["risk_per_share_including_buffers"] == 8_000
    assert buffered["risk_per_share_including_buffers"] == 9_200
    assert buffered["quantity"] <= base["quantity"]


def test_position_size_rejects_unreasonable_buffer_inputs():
    import pytest
    with pytest.raises(ValueError):
        size_position(6_000_000, 100_000, 92_000, 2_000_000,
                      gap_buffer_pct=60)


def test_risk_engine_rejects_nan_and_invalid_drawdown_thresholds():
    import math
    import pytest
    from risk import RiskConfig, size_position, drawdown_state
    with pytest.raises(ValueError):
        size_position(1_000_000, math.nan, 90, 500_000)
    with pytest.raises(ValueError):
        drawdown_state(1.0)
    with pytest.raises(ValueError):
        RiskConfig(warning_drawdown_pct=-8, reduce_drawdown_pct=-5)
