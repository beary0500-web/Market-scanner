import os,sys
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from market_data import normalize_eod_payload
from features import features_from_bars, rank_candidates

def test_normalize_eod_payload_rejects_bad_bars():
    data=normalize_eod_payload([{"symbol":"AAPL","date":"2026-01-02","open":10,"high":12,"low":9,"close":11,"volume":100},
                                {"symbol":"BAD","date":"2026-01-02","open":10,"high":8,"low":9,"close":11,"volume":100}])
    assert len(data["AAPL"])==1
    assert "BAD" not in data

def test_features_need_sufficient_history():
    bars=[{"date":f"2026-01-{i+1:02d}","close":100+i,"volume":1000} for i in range(30)]
    assert features_from_bars(bars,"US")["status"]=="INSUFFICIENT_HISTORY"

def test_features_and_rank():
    bars=[{"date":f"2025-{(i//28)+1:02d}-{(i%28)+1:02d}","close":100+i*.5,"volume":100000} for i in range(260)]
    f=features_from_bars(bars,"US")
    assert f["status"]=="OK"
    assert f["ma200"] is not None
    assert f["return_3m_pct"]>0
    row={"symbol":"TEST","status":"OK","observations":260,"score":80,"coverage_pct":75,"avg_daily_turnover":1e7}
    assert rank_candidates([row])[0]["symbol"]=="TEST"



def test_eodapi_prices_response_shape_is_normalized():
    payload = {"prices": {"AAPL": [
        {"date": "2026-01-02", "open": 10, "high": 12, "low": 9,
         "close": 11, "volume": 100}
    ]}, "failed": [], "meta": {"tier": "free"}}
    result = normalize_eod_payload(payload)
    assert result["AAPL"][0]["close"] == 11


def test_eodapi_adapter_uses_tickers_and_days_parameters(monkeypatch):
    import asyncio
    from datetime import date
    import market_data

    observed = {}

    class FakeResponse:
        status_code = 200
        def raise_for_status(self):
            return None
        def json(self):
            return {"prices": {"AAPL": [
                {"date": "2026-01-02", "open": 10, "high": 12, "low": 9,
                 "close": 11, "volume": 100},
                {"date": "2026-02-02", "open": 11, "high": 13, "low": 10,
                 "close": 12, "volume": 110},
            ]}}

    class FakeClient:
        def __init__(self, *args, **kwargs):
            pass
        async def __aenter__(self):
            return self
        async def __aexit__(self, *args):
            return False
        async def get(self, url, params, headers):
            observed.update({"url": url, "params": params, "headers": headers})
            return FakeResponse()

    monkeypatch.setattr(market_data.httpx, "AsyncClient", FakeClient)
    provider = market_data.EodApiProvider("test-token")
    result = asyncio.run(provider.daily_bars(
        ["AAPL"], date(2026, 1, 1), date(2026, 1, 31)
    ))
    assert observed["params"]["tickers"] == "AAPL"
    assert "days" in observed["params"]
    assert "from" not in observed["params"]
    assert observed["headers"]["Authorization"] == "Bearer test-token"
    assert len(result["AAPL"]) == 1



def test_eodapi_free_tier_rejects_more_than_one_year():
    import asyncio
    from datetime import date
    import pytest
    from market_data import EodApiProvider

    provider = EodApiProvider("test-token")
    with pytest.raises(ValueError, match="one year"):
        asyncio.run(provider.daily_bars(
            ["AAPL"], date(2024, 1, 1), date(2026, 1, 1)
        ))


def test_nasdaq_trader_rss_parser_extracts_symbols_and_halt_descriptions():
    from us_market_warnings import parse_halt_rss
    xml=b'''<?xml version="1.0"?><rss><channel><item><title>Security ABCD halted on 11/20/2026</title><description>News pending</description></item><item><title>Security XYZ resumed on 11/20/2026</title><description>Resumed</description></item></channel></rss>'''
    result=parse_halt_rss(xml)
    assert "ABCD" in result and "XYZ" in result
    assert result["ABCD"][0]["source"]=="Nasdaq Trader current trading halts RSS"
