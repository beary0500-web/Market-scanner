import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi.testclient import TestClient
import pytest
import main


def test_health_is_public():
    client = TestClient(main.app)
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_protected_scoring_fails_closed_without_api_key(monkeypatch):
    monkeypatch.delenv("API_KEY", raising=False)
    client = TestClient(main.app)
    response = client.post("/scan/score", json={"snapshots": []})
    assert response.status_code == 503


def test_protected_scoring_rejects_wrong_api_key(monkeypatch):
    monkeypatch.setenv("API_KEY", "expected-secret")
    client = TestClient(main.app)
    response = client.post(
        "/scan/score",
        headers={"X-API-Key": "wrong-secret"},
        json={"snapshots": []},
    )
    assert response.status_code == 401


def test_scoring_endpoint_returns_auditable_fundamental_details(monkeypatch):
    monkeypatch.setenv("API_KEY", "test-secret")
    client = TestClient(main.app)
    response = client.post(
        "/scan/score",
        headers={"X-API-Key": "test-secret"},
        json={"snapshots": [{
            "symbol": "TEST",
            "market": "US",
            "revenue_ttm_yoy_pct": 15,
            "net_income_ttm_yoy_pct": 12,
            "roe_pct": 10,
            "debt_to_assets_pct": 25,
        }]},
    )
    assert response.status_code == 200
    item = response.json()["results"][0]
    assert item["components"]["fundamentals"] is not None
    assert item["fundamental_detail"]["revenue_growth"] is not None



def test_unified_analyze_endpoint_combines_price_features_and_fundamentals(monkeypatch):
    monkeypatch.setenv("API_KEY", "test-secret")
    client = TestClient(main.app)
    bars = []
    from datetime import date, timedelta
    start = date(2025, 1, 1)
    for i in range(260):
        day = start + timedelta(days=i)
        close = 100 + i * 0.5
        bars.append({
            "date": day.isoformat(), "open": close, "high": close + 1,
            "low": close - 1, "close": close, "volume": 100000,
        })
    response = client.post(
        "/scan/analyze",
        headers={"X-API-Key": "test-secret"},
        json={"items": [{
            "symbol": "TEST", "name": "Test Corp", "market": "US",
            "bars": bars,
            "fundamentals": {
                "revenue_ttm_yoy_pct": 12,
                "net_income_ttm_yoy_pct": 15,
                "liabilities_to_assets_pct": 40,
                "roe_pct": 10,
            },
        }]},
    )
    assert response.status_code == 200
    result = response.json()["results"][0]
    assert result["features"]["observations"] == 260
    assert result["components"]["fundamentals"] is not None
    assert result["score"] is not None



def test_risk_position_size_endpoint_applies_drawdown_and_buffers(monkeypatch):
    monkeypatch.setenv("API_KEY", "test-secret")
    client = TestClient(main.app)
    response = client.post(
        "/risk/position-size",
        headers={"X-API-Key": "test-secret"},
        json={
            "account_value": 6000000, "entry": 100000, "stop": 92000,
            "available_cash": 2000000, "drawdown_pct": -8,
            "cost_buffer_pct": 0.2, "gap_buffer_pct": 1.0,
        },
    )
    assert response.status_code == 200
    result = response.json()
    assert result["quantity"] == 0
    assert result["drawdown"]["state"] == "REDUCE_RISK"
    assert result["risk_per_share_including_buffers"] == 9200



def test_toss_provider_paginates_adjusted_daily_candles():
    import asyncio
    from toss_market_data import TossMarketDataProvider

    class Response:
        def __init__(self, payload, status=200):
            self.payload, self.status_code = payload, status
            self.headers = {}
        def json(self):
            return self.payload

    class FakeClient:
        def __init__(self):
            self.token_calls = 0
            self.candle_calls = []
        async def post(self, url, data, headers):
            self.token_calls += 1
            return Response({"access_token": "test-token", "expires_in": 86400})
        async def get(self, url, params, headers):
            self.candle_calls.append((url, params, headers))
            if len(self.candle_calls) == 1:
                return Response({"result": {
                    "candles": [
                        {"timestamp": "2026-03-03T09:00:00+09:00", "openPrice": "12",
                         "highPrice": "13", "lowPrice": "11", "closePrice": "12.5", "volume": "100"},
                        {"timestamp": "2026-03-02T09:00:00+09:00", "openPrice": "11",
                         "highPrice": "12", "lowPrice": "10", "closePrice": "11.5", "volume": "90"},
                    ],
                    "nextBefore": "2026-03-02T09:00:00+09:00",
                }})
            return Response({"result": {
                "candles": [
                    {"timestamp": "2026-03-02T09:00:00+09:00", "openPrice": "11",
                     "highPrice": "12", "lowPrice": "10", "closePrice": "11.5", "volume": "90"},
                    {"timestamp": "2026-03-01T09:00:00+09:00", "openPrice": "10",
                     "highPrice": "11", "lowPrice": "9", "closePrice": "10.5", "volume": "80"},
                ],
                "nextBefore": None,
            }})

    async def run():
        fake = FakeClient()
        provider = TossMarketDataProvider("client", "secret", client=fake)
        bars = await provider.daily_bars("005930", count=3, adjusted=True)
        assert [x["date"] for x in bars] == ["2026-03-01", "2026-03-02", "2026-03-03"]
        assert fake.token_calls == 1
        assert len(fake.candle_calls) == 2
        assert fake.candle_calls[0][1]["adjusted"] == "true"
        assert fake.candle_calls[1][1]["before"] == "2026-03-02T09:00:00+09:00"
    asyncio.run(run())


def test_toss_provider_requires_server_credentials():
    import pytest
    from toss_market_data import TossMarketDataProvider, TossNotConfigured
    with pytest.raises(TossNotConfigured):
        TossMarketDataProvider(client_id="", client_secret="")



def test_toss_rankings_uses_market_scope_and_count():
    import asyncio
    from toss_market_data import TossMarketDataProvider

    class Response:
        status_code = 200
        headers = {}
        def json(self):
            return {"result": {"rankedAt": "2026-11-20T15:30:00+09:00",
                               "rankings": [{"rank": 1, "symbol": "AAPL"}]}}

    class FakeClient:
        def __init__(self):
            self.params = None
        async def post(self, url, data, headers):
            return type("TokenResponse", (), {
                "status_code": 200,
                "json": lambda self: {"access_token": "t", "expires_in": 86400}
            })()
        async def get(self, url, params, headers):
            self.params = params
            return Response()

    async def run():
        fake = FakeClient()
        provider = TossMarketDataProvider("id", "secret", client=fake)
        result = await provider.rankings("US", "1w", 50)
        assert result["rankings"][0]["symbol"] == "AAPL"
        assert fake.params["marketCountry"] == "US"
        assert fake.params["duration"] == "1w"
        assert fake.params["count"] == 50
        assert fake.params["type"] == "MARKET_TRADING_AMOUNT"
    asyncio.run(run())



def test_toss_ranked_scan_orchestrates_technical_shortlist(monkeypatch):
    from datetime import date, timedelta

    monkeypatch.setenv("API_KEY", "test-secret")
    bars = []
    start = date(2025, 1, 1)
    for i in range(260):
        close = 100 + i * 0.3
        bars.append({
            "date": (start + timedelta(days=i)).isoformat(),
            "open": close, "high": close + 1, "low": close - 1,
            "close": close, "volume": 100000,
        })

    class FakeProvider:
        async def rankings(self, market_country, duration, count, ranking_type, exclude):
            return {"rankedAt": "2026-11-20T15:30:00+09:00",
                    "rankings": [{"rank": 1, "symbol": "AAPL" if market_country == "US" else "005930",
                                 "tradingAmount": "1000000000"}]}
        async def stocks(self, symbols):
            return [{"symbol": symbol, "name": symbol, "securityType": "STOCK",
                     "status": "ACTIVE", "isCommonShare": True} for symbol in symbols]
        async def daily_bars(self, symbol, count, adjusted=True):
            return bars
        async def warnings(self, symbol):
            return []
        async def market_indicator_daily_bars(self, symbol, count):
            return bars
        async def aclose(self):
            return None

    monkeypatch.setattr(main, "TossMarketDataProvider", FakeProvider)
    client = TestClient(main.app)
    response = client.post(
        "/scan/toss-ranked",
        headers={"X-API-Key": "test-secret"},
        json={"markets": ["US", "KR"], "count_per_market": 1, "history_count": 260},
    )
    assert response.status_code == 200
    payload = response.json()
    assert payload["universe_scope"] == "TOP_RANKED_ONLY"
    assert payload["count"] == 2
    assert all(x["features"]["observations"] == 260 for x in payload["results"])
    assert all(x["fundamentals_status"] == "NOT_ATTACHED" for x in payload["results"])
    assert all(x["decision"] == "BLOCKED" for x in payload["results"])



def test_toss_token_is_shared_between_provider_instances(monkeypatch):
    import asyncio
    import toss_market_data

    toss_market_data._TOKEN_VALUE = None
    toss_market_data._TOKEN_CLIENT_ID = None
    toss_market_data._TOKEN_EXPIRES_AT = 0.0

    class Response:
        status_code = 200
        headers = {}
        def json(self):
            return {"access_token": "shared-token", "expires_in": 86400}

    class FakeClient:
        def __init__(self):
            self.post_calls = 0
        async def post(self, *args, **kwargs):
            self.post_calls += 1
            return Response()

    async def run():
        fake = FakeClient()
        one = toss_market_data.TossMarketDataProvider("same-id", "secret", client=fake)
        two = toss_market_data.TossMarketDataProvider("same-id", "secret", client=fake)
        assert await one._access_token() == "shared-token"
        assert await two._access_token() == "shared-token"
        assert fake.post_calls == 1
    asyncio.run(run())



def test_toss_ranked_scan_can_enrich_shortlist_with_sec_and_dart(monkeypatch):
    from datetime import date, timedelta
    import asyncio

    monkeypatch.setenv("API_KEY", "test-secret")
    monkeypatch.setenv("SEC_USER_AGENT", "MarketScanner/2.0 contact@mydomain.kr")
    monkeypatch.setenv("DART_API_KEY", "configured")

    bars = []
    start = date(2025, 1, 1)
    for i in range(260):
        close = 100 + i * 0.3
        bars.append({
            "date": (start + timedelta(days=i)).isoformat(),
            "open": close, "high": close + 1, "low": close - 1,
            "close": close, "volume": 100000,
        })

    class FakeProvider:
        async def rankings(self, market_country, duration, count, ranking_type, exclude):
            symbol = "AAPL" if market_country == "US" else "005930"
            return {"rankings": [{"rank": 1, "symbol": symbol}]}
        async def stocks(self, symbols):
            return [{"symbol": symbol, "name": symbol, "securityType": "STOCK",
                     "status": "ACTIVE", "isCommonShare": True} for symbol in symbols]
        async def daily_bars(self, symbol, count, adjusted=True):
            return bars
        async def warnings(self, symbol):
            return []
        async def market_indicator_daily_bars(self, symbol, count):
            return bars
        async def aclose(self):
            return None

    async def fake_sec(symbol):
        return {"revenue_ttm_yoy_pct": 20, "roe_pct": 15,
                "liabilities_to_assets_pct": 35}
    async def fake_dart(symbol):
        return {"score_inputs": {"sales_growth_pct": 18, "roe_pct": 14,
                                 "liabilities_to_assets_pct": 40}}

    monkeypatch.setattr(main, "TossMarketDataProvider", FakeProvider)
    monkeypatch.setattr(main, "fetch_sec_fundamentals", fake_sec)
    monkeypatch.setattr(main, "fetch_kr_fundamentals", fake_dart)
    client = TestClient(main.app)
    response = client.post(
        "/scan/toss-ranked",
        headers={"X-API-Key": "test-secret"},
        json={"markets": ["US", "KR"], "count_per_market": 1, "history_count": 260,
              "include_fundamentals": True, "fundamental_count": 1},
    )
    assert response.status_code == 200
    payload = response.json()
    assert payload["fundamentals_requested"] is True
    assert all(x["fundamentals_status"] == "AVAILABLE" for x in payload["results"])
    assert all(x["components"]["fundamentals"] is not None for x in payload["results"])
    assert all("필수 재무 데이터 미확보" not in x["decision_blockers"]
               for x in payload["results"])



def test_toss_market_indicator_daily_bars_uses_index_candles_endpoint():
    import asyncio
    from toss_market_data import TossMarketDataProvider

    class Response:
        status_code = 200
        headers = {}
        def json(self):
            return {"result": {"candles": [{
                "timestamp": "2026-06-11T09:00:00+09:00",
                "openPrice": "2800", "highPrice": "2820", "lowPrice": "2790",
                "closePrice": "2812", "volume": "500000000"
            }], "nextBefore": None}}

    class FakeClient:
        def __init__(self):
            self.url = None
            self.params = None
        async def post(self, *args, **kwargs):
            return type("TokenResponse", (), {
                "status_code": 200,
                "json": lambda self: {"access_token": "idx-token", "expires_in": 86400}
            })()
        async def get(self, url, params, headers):
            self.url, self.params = url, params
            return Response()

    async def run():
        import toss_market_data
        toss_market_data._TOKEN_VALUE = None
        toss_market_data._TOKEN_CLIENT_ID = None
        toss_market_data._TOKEN_EXPIRES_AT = 0.0
        fake = FakeClient()
        provider = TossMarketDataProvider("idx-id", "secret", client=fake)
        result = await provider.market_indicator_daily_bars("KOSPI", 1)
        assert result[0]["close"] == 2812
        assert fake.url.endswith("/api/v1/market-indicators/KOSPI/candles")
        assert fake.params == {"interval": "1d", "count": 1}
    asyncio.run(run())



def test_toss_accounts_endpoint_masks_full_account_number(monkeypatch):
    monkeypatch.setenv("API_KEY", "test-secret")

    class FakeProvider:
        async def accounts(self):
            return [{"accountNo": "12345678901", "accountSeq": 7,
                     "accountType": "BROKERAGE"}]
        async def aclose(self):
            return None

    monkeypatch.setattr(main, "TossMarketDataProvider", FakeProvider)
    client = TestClient(main.app)
    response = client.get("/toss/accounts", headers={"X-API-Key": "test-secret"})
    assert response.status_code == 200
    account = response.json()["accounts"][0]
    assert account["maskedAccountNo"] == "*******8901"
    assert "accountNo" not in account


def test_toss_holdings_endpoint_uses_read_only_provider(monkeypatch):
    monkeypatch.setenv("API_KEY", "test-secret")

    class FakeProvider:
        async def holdings(self, account_seq):
            return {"items": [{"symbol": "005930", "quantity": "10"}]}
        async def aclose(self):
            return None

    monkeypatch.setattr(main, "TossMarketDataProvider", FakeProvider)
    client = TestClient(main.app)
    response = client.get("/toss/holdings?account_seq=7",
                          headers={"X-API-Key": "test-secret"})
    assert response.status_code == 200
    assert response.json()["read_only"] is True
    assert response.json()["data"]["items"][0]["quantity"] == "10"



def test_toss_holdings_provider_sends_account_sequence_header():
    import asyncio
    import toss_market_data

    class Response:
        status_code = 200
        headers = {}
        def json(self):
            return {"result": {"items": []}}

    class FakeClient:
        def __init__(self):
            self.headers = None
        async def post(self, *args, **kwargs):
            return type("TokenResponse", (), {
                "status_code": 200,
                "json": lambda self: {"access_token": "account-token", "expires_in": 86400}
            })()
        async def get(self, url, params, headers):
            self.headers = headers
            return Response()

    async def run():
        toss_market_data._TOKEN_VALUE = None
        toss_market_data._TOKEN_CLIENT_ID = None
        toss_market_data._TOKEN_EXPIRES_AT = 0.0
        fake = FakeClient()
        provider = toss_market_data.TossMarketDataProvider("account-id", "secret", client=fake)
        await provider.holdings(42)
        assert fake.headers["X-Tossinvest-Account"] == "42"
    asyncio.run(run())



def test_toss_portfolio_summary_converts_usd_to_krw(monkeypatch):
    monkeypatch.setenv("API_KEY", "test-secret")

    class FakeProvider:
        async def holdings(self, account_seq):
            return {
                "marketValue": {"amount": {"krw": "7000000", "usd": "1000"}},
                "items": [
                    {"symbol": "005930", "marketCountry": "KR",
                     "marketValue": {"amount": "7000000"}},
                    {"symbol": "AAPL", "marketCountry": "US",
                     "marketValue": {"amount": "1000"}},
                ],
            }
        async def buying_power(self, account_seq, currency):
            return {"cashBuyingPower": "500000" if currency == "KRW" else "200"}
        async def exchange_rate(self, base_currency, quote_currency):
            return {"rate": "1400", "validUntil": "2026-11-20T17:02:00+09:00"}
        async def stocks(self, symbols):
            return [{"symbol":"005930","sectorName":"Technology"}]
        async def aclose(self):
            return None

    monkeypatch.setattr(main, "TossMarketDataProvider", FakeProvider)
    client = TestClient(main.app)
    response = client.get("/toss/portfolio-summary?account_seq=3",
                          headers={"X-API-Key": "test-secret"})
    assert response.status_code == 200
    result = response.json()
    assert result["securities_krw"] == 8400000
    assert result["cash_buying_power_krw"] == 780000
    assert result["total_estimated_value_krw"] == 9180000
    assert result["country_exposure_krw"]["US"] == 1400000
    assert result["sector_exposure_krw"]["Technology"] == 7000000
    assert result["sector_classification_coverage_pct"] == 83.33



def test_toss_exchange_rate_provider_uses_usd_krw_pair():
    import asyncio
    import toss_market_data

    class Response:
        status_code = 200
        headers = {}
        def json(self):
            return {"result": {"baseCurrency": "USD", "quoteCurrency": "KRW",
                               "rate": "1400.25", "validUntil": "2026-11-20T17:03:00+09:00"}}

    class FakeClient:
        def __init__(self):
            self.params = None
        async def post(self, *args, **kwargs):
            return type("TokenResponse", (), {
                "status_code": 200,
                "json": lambda self: {"access_token": "fx-token", "expires_in": 86400}
            })()
        async def get(self, url, params, headers):
            self.params = params
            return Response()

    async def run():
        toss_market_data._TOKEN_VALUE = None
        toss_market_data._TOKEN_CLIENT_ID = None
        toss_market_data._TOKEN_EXPIRES_AT = 0.0
        fake = FakeClient()
        provider = toss_market_data.TossMarketDataProvider("fx-id", "secret", client=fake)
        result = await provider.exchange_rate("USD", "KRW")
        assert result["rate"] == "1400.25"
        assert fake.params == {"baseCurrency": "USD", "quoteCurrency": "KRW"}
    asyncio.run(run())



def test_toss_open_orders_endpoint_returns_minimal_read_only_fields(monkeypatch):
    monkeypatch.setenv("API_KEY", "test-secret")

    class FakeProvider:
        async def orders(self, account_seq, status):
            return {"orders": [{
                "orderId": "opaque-id", "symbol": "AAPL", "side": "BUY",
                "orderType": "LIMIT", "status": "PENDING", "price": "180",
                "quantity": "2", "currency": "USD", "orderedAt": "2026-11-20T10:00:00+09:00",
                "secretField": "must-not-return",
            }]}
        async def aclose(self):
            return None

    monkeypatch.setattr(main, "TossMarketDataProvider", FakeProvider)
    client = TestClient(main.app)
    response = client.get("/toss/orders?account_seq=2&status=OPEN",
                          headers={"X-API-Key": "test-secret"})
    assert response.status_code == 200
    order = response.json()["orders"][0]
    assert order["symbol"] == "AAPL"
    assert "secretField" not in order
    assert response.json()["read_only"] is True



def test_account_aware_scan_blocks_duplicate_pending_buy_order(monkeypatch):
    from datetime import date, timedelta

    monkeypatch.setenv("API_KEY", "test-secret")
    bars = []
    start = date(2025, 1, 1)
    for i in range(260):
        close = 100 + i * 0.3
        bars.append({
            "date": (start + timedelta(days=i)).isoformat(),
            "open": close, "high": close + 1, "low": close - 1,
            "close": close, "volume": 100000,
        })

    class FakeProvider:
        async def rankings(self, market_country, duration, count, ranking_type, exclude):
            return {"rankings": [{"rank": 1, "symbol": "AAPL"}]}
        async def stocks(self, symbols):
            return [{"symbol": x, "name": x, "securityType": "STOCK",
                     "status": "ACTIVE", "isCommonShare": True} for x in symbols]
        async def holdings(self, account_seq):
            return {"items": [{"symbol": "MSFT", "marketCountry": "US"}]}
        async def orders(self, account_seq, status):
            return {"orders": [{"symbol": "AAPL", "side": "BUY", "status": "PENDING"}]}
        async def daily_bars(self, symbol, count, adjusted=True):
            return bars
        async def warnings(self, symbol):
            return []
        async def aclose(self):
            return None

    monkeypatch.setattr(main, "TossMarketDataProvider", FakeProvider)
    client = TestClient(main.app)
    response = client.post(
        "/scan/toss-ranked",
        headers={"X-API-Key": "test-secret"},
        json={"markets": ["US"], "count_per_market": 1, "history_count": 260,
              "account_seq": 7},
    )
    assert response.status_code == 200
    payload = response.json()
    assert payload["holdings_loaded"] is True
    assert payload["open_buy_orders_count"] == 1
    candidate = payload["results"][0]
    assert candidate["decision"] == "BLOCKED"
    assert "동일 종목 미체결 매수주문 존재" in candidate["decision_blockers"]



def test_backtest_enters_next_session_and_fills_gap_stop_worse_than_stop():
    from backtest import run_backtest
    bars = {"AAA": [
        {"date": "2026-01-01", "open": 100, "high": 105, "low": 99, "close": 102, "volume": 1000},
        {"date": "2026-01-02", "open": 100, "high": 102, "low": 95, "close": 98, "volume": 1000},
        {"date": "2026-01-03", "open": 90, "high": 92, "low": 88, "close": 89, "volume": 1000},
    ]}
    result = run_backtest(
        bars, [{"date": "2026-01-01", "symbol": "AAA", "score": 90, "coverage_pct": 80}],
        initial_capital=1_000_000, risk_per_trade_pct=0.01,
        max_position_pct=0.5, stop_loss_pct=0.08,
    )
    trade = result["trades"][0]
    assert trade["entry_date"] == "2026-01-02"
    assert trade["exit_date"] == "2026-01-03"
    assert trade["exit_price"] == 90
    assert trade["reason"] == "STOP"
    assert trade["pnl"] < 0


def test_backtest_uses_next_available_symbol_session_not_global_date():
    from backtest import run_backtest
    bars = {
        "KR": [
            {"date": "2026-01-02", "open": 100, "high": 101, "low": 99, "close": 100, "volume": 1000},
            {"date": "2026-01-05", "open": 101, "high": 102, "low": 100, "close": 101, "volume": 1000},
        ],
        "US": [
            {"date": "2026-01-02", "open": 50, "high": 51, "low": 49, "close": 50, "volume": 1000},
            {"date": "2026-01-03", "open": 51, "high": 52, "low": 50, "close": 51, "volume": 1000},
        ],
    }
    result = run_backtest(
        bars, [{"date": "2026-01-02", "symbol": "KR", "score": 90, "coverage_pct": 80}],
        initial_capital=1_000_000, risk_per_trade_pct=0.01, max_position_pct=0.5,
    )
    assert result["open_positions"][0]["symbol"] == "KR"
    assert result["open_positions"][0]["entry_date"] == "2026-01-05"


def test_backtest_rejects_lookahead_execution_and_bad_limits():
    import pytest
    from backtest import run_backtest
    bars = {"AAA": [
        {"date": "2026-01-01", "open": 100, "high": 101, "low": 99, "close": 100, "volume": 1},
        {"date": "2026-01-02", "open": 100, "high": 101, "low": 99, "close": 100, "volume": 1},
    ]}
    result = run_backtest(
        bars, [{"date": "2026-01-02", "symbol": "AAA", "score": 90, "coverage_pct": 90}]
    )
    assert result["closed_trades"] == 0
    assert result["open_positions"] == []
    with pytest.raises(ValueError):
        run_backtest(bars, [], fee_bps=1000)


def test_backtest_api_requires_auth_and_returns_metrics(monkeypatch):
    monkeypatch.setenv("API_KEY", "test-secret")
    client = TestClient(main.app)
    bars = {"AAA": [
        {"date": "2026-01-01", "open": 100, "high": 101, "low": 99, "close": 100, "volume": 1},
        {"date": "2026-01-02", "open": 100, "high": 101, "low": 99, "close": 100, "volume": 1},
    ]}
    response = client.post(
        "/backtest/run", headers={"X-API-Key": "test-secret"},
        json={"bars_by_symbol": bars, "signals": []},
    )
    assert response.status_code == 200
    assert "max_drawdown_pct" in response.json()


def test_us_halt_endpoint_returns_fail_closed_status(monkeypatch):
    monkeypatch.setenv("API_KEY", "test-secret")
    async def fake_halts():
        return {"AAPL": [{"source": "Nasdaq Trader", "title": "Security AAPL halted"}]}
    monkeypatch.setattr(main, "fetch_us_trading_halts", fake_halts)
    client = TestClient(main.app)
    response = client.get("/market-data/us/trading-halts/AAPL", headers={"X-API-Key":"test-secret"})
    assert response.status_code == 200
    assert response.json()["status"] == "ACTIVE"


def test_etf_quality_normalization_requires_core_metrics():
    from etf_quality import normalize_etf_fundamentals
    complete = normalize_etf_fundamentals({"ETF_Data": {
        "NetExpenseRatio": 0.2, "TotalAssets": 1_000_000_000,
        "Holdings_Count": 100, "Top_10_Holdings": {
            "AAA": {"Weight": 8}, "BBB": {"Weight": 7}
        }
    }})
    assert complete["status"] == "AVAILABLE"
    assert complete["expense_ratio_pct"] == 0.2
    assert complete["top10_concentration_pct"] == 15
    missing = normalize_etf_fundamentals({"ETF_Data": {"NetExpenseRatio": 0.2}})
    assert missing["status"] == "INSUFFICIENT_DATA"


def test_etf_without_configured_quality_data_remains_blocked(monkeypatch):
    from etf_quality import ETFQualityNotConfigured
    monkeypatch.delenv("EODHD_API_TOKEN", raising=False)
    import asyncio
    from etf_quality import fetch_etf_quality
    with pytest.raises(ETFQualityNotConfigured):
        asyncio.run(fetch_etf_quality("SPY", "US"))


def test_krx_etf_daily_normalizes_nav_and_net_assets(monkeypatch):
    monkeypatch.setenv("API_KEY", "test-secret")
    monkeypatch.setenv("KRX_AUTH_KEY", "krx-test")
    class Response:
        def raise_for_status(self): pass
        def json(self):
            return {"OutBlock_1": [{"ISU_SRT_CD":"069500", "ISU_ABBRV":"KODEX 200",
                "TDD_CLSPRC":"40000", "NAV":"40100", "ACC_TRDVOL":"1000",
                "ACC_TRDVAL":"40000000", "MKTCAP":"5000000000",
                "INVSTASST_NETASST_TOTAMT":"4900000000", "LIST_SHRS":"100000",
                "IDX_IND_NM":"KOSPI 200", "OBJ_STKPRC_IDX":"350", "FLUC_RT_IDX":"0.5"}]}
    class Client:
        async def __aenter__(self): return self
        async def __aexit__(self,*args): pass
        async def post(self,*args,**kwargs): return Response()
    monkeypatch.setattr(main.httpx, "AsyncClient", lambda **kwargs: Client())
    client=TestClient(main.app)
    response=client.get("/market/kr/etf/daily?bas_dd=20261120",headers={"X-API-Key":"test-secret"})
    assert response.status_code==200
    row=response.json()["data"][0]
    assert row["nav"]==40100
    assert row["net_assets"]==4900000000


def test_full_universe_scan_is_disabled_without_explicit_paid_bulk_budget(monkeypatch):
    monkeypatch.setenv("API_KEY", "test-secret")
    monkeypatch.delenv("EODHD_BULK_CALL_UNITS_PER_RUN", raising=False)
    client=TestClient(main.app)
    response=client.post("/scan/full-universe",headers={"X-API-Key":"test-secret"},json={
        "markets":["US"],"start_date":"2025-01-01","end_date":"2025-11-20"})
    assert response.status_code==503
    assert "paid EODHD plan" in response.json()["detail"]


def test_full_universe_scan_uses_whole_exchange_history_and_master(monkeypatch,tmp_path):
    from datetime import date, timedelta
    monkeypatch.setenv("API_KEY","test-secret")
    monkeypatch.setenv("EODHD_API_TOKEN","fake")
    monkeypatch.setenv("EODHD_BULK_CALL_UNITS_PER_RUN","10000")
    bars=[]; day=date(2025,1,1)
    for i in range(220):
        close=100+i*.5
        bars.append({"date":(day+timedelta(days=i)).isoformat(),"open":close,"high":close+1,
                     "low":close-1,"close":close,"volume":10000})
    class FakeStore:
        def __init__(self): pass
        async def refresh(self,exchange,start,end,budget):
            return {"exchange":exchange,"new_snapshots":1,"api_call_units_used":100}
        async def exchange_symbols(self,exchange):
            return {"AAA":{"Code":"AAA","Name":"Alpha","Type":"Common Stock","Sector":"Technology"},
                    "SPY":{"Code":"SPY","Name":"SPDR S&P 500 ETF","Type":"ETF"}}
        def load_series(self,exchange,start,end,min_observations):
            return {"AAA":bars,"SPY":bars}
        async def close(self): pass
    monkeypatch.setattr(main,"BulkMarketStore",FakeStore)
    async def fake_halts(): return {}
    async def fake_sec(symbol):
        return {"revenue_ttm_yoy_pct":15,"net_income_ttm_yoy_pct":12,"roe_pct":14,
                "operating_margin_ttm_pct":18,"net_margin_ttm_pct":10,
                "liabilities_to_assets_pct":40,"fcf_margin_ttm_pct":8,
                "net_income_ttm":1000000,"stockholders_equity":5000000}
    async def fake_etf(symbol,exchange):
        return {"status":"AVAILABLE","quality_score":85,"expense_ratio_pct":0.2,
                "total_assets":1000000000,"holdings_count":100}
    monkeypatch.setattr(main,"fetch_us_trading_halts",fake_halts)
    monkeypatch.setattr(main,"fetch_sec_fundamentals",fake_sec)
    monkeypatch.setattr(main,"fetch_etf_quality",fake_etf)
    client=TestClient(main.app)
    response=client.post("/scan/full-universe",headers={"X-API-Key":"test-secret"},json={
        "markets":["US"],"start_date":"2025-01-01","end_date":"2025-11-20",
        "min_observations":200,"limit":10,"include_fundamentals":True,"fundamental_count":10})
    assert response.status_code==200
    data=response.json()
    assert data["universe_scope"]=="WHOLE_CURRENT_EXCHANGE_MASTER"
    assert data["markets"]["US"]["eligible_symbols"]==2
    assert all(x["warnings_status"]=="CLEAR" for x in data["results"])
    assert all(x["decision"] in ("BUY_CANDIDATE","WATCH","BLOCKED") for x in data["results"])
    assert all("decision_blockers" in x for x in data["results"])


def test_full_universe_backtest_reads_persistent_point_in_time_cache(monkeypatch,tmp_path):
    import sqlite3
    from datetime import date,timedelta
    monkeypatch.setenv("API_KEY","test-secret")
    db_path=tmp_path/"market.sqlite3"
    with sqlite3.connect(db_path) as db:
        db.execute("CREATE TABLE bars(exchange TEXT NOT NULL,symbol TEXT NOT NULL,day TEXT NOT NULL,open REAL,high REAL,low REAL,close REAL,volume REAL,PRIMARY KEY(exchange,symbol,day))")
        rows=[]; start=date(2025,1,1)
        for symbol,base,step in (("SPY",100,.5),("AAA",20,.2)):
            for i in range(230):
                close=base+i*step; day=(start+timedelta(days=i)).isoformat()
                rows.append(("US",symbol,day,close,close+1,close-1,close,100000))
        db.executemany("INSERT INTO bars VALUES(?,?,?,?,?,?,?,?)",rows)
    monkeypatch.setenv("MARKET_DATA_DB",str(db_path))
    client=TestClient(main.app)
    response=client.post("/backtest/full-universe",headers={"X-API-Key":"test-secret"},json={
        "market":"US","start_date":"2025-01-01","end_date":"2025-08-31",
        "score_threshold":0,"min_coverage_pct":0,"initial_capital":1000000})
    assert response.status_code==200
    result=response.json()
    assert result["market"]=="US"
    assert result["universe_symbols_with_history"]==2
    assert "signal_metadata" in result



def test_backtest_handles_stop_hit_on_entry_session():
    from backtest import run_backtest
    bars={"AAA":[
        {"date":"2026-01-01","open":100,"high":101,"low":99,"close":100,"volume":1000},
        {"date":"2026-01-02","open":100,"high":102,"low":90,"close":95,"volume":1000},
        {"date":"2026-01-03","open":95,"high":96,"low":94,"close":95,"volume":1000},
    ]}
    result=run_backtest(bars,[{"date":"2026-01-01","symbol":"AAA","score":90,"coverage_pct":80}],
        initial_capital=1_000_000,risk_per_trade_pct=.01,max_position_pct=.5,stop_loss_pct=.08)
    assert result["closed_trades"]==1
    assert result["trades"][0]["reason"]=="SAME_DAY_STOP"
    assert result["trades"][0]["entry_date"]==result["trades"][0]["exit_date"]


def test_full_universe_account_aware_scan_enforces_sector_cap(monkeypatch):
    from datetime import date,timedelta
    monkeypatch.setenv("API_KEY","test-secret")
    monkeypatch.setenv("EODHD_API_TOKEN","fake")
    monkeypatch.setenv("EODHD_BULK_CALL_UNITS_PER_RUN","10000")
    bars=[]; start=date(2025,1,1)
    for i in range(220):
        close=100+i*.5
        bars.append({"date":(start+timedelta(days=i)).isoformat(),"open":close,
                     "high":close+1,"low":close-1,"close":close,"volume":100000})
    class FakeStore:
        def __init__(self): pass
        async def refresh(self,exchange,start,end,budget): return {"exchange":exchange,"new_snapshots":1,"api_call_units_used":100}
        async def exchange_symbols(self,exchange):
            return {"AAA":{"Code":"AAA","Name":"Alpha","Type":"Common Stock","Sector":"Technology"},
                    "SPY":{"Code":"SPY","Name":"SPDR S&P 500 ETF","Type":"ETF"}}
        def load_series(self,exchange,start,end,min_observations): return {"AAA":bars,"SPY":bars}
        async def close(self): pass
    class FakeToss:
        async def holdings(self,account_seq):
            return {"items":[{"symbol":"MSFT","marketCountry":"US","marketValue":{"amount":"2000"}}],
                    "marketValue":{"amount":{"krw":"0","usd":"2000"}}}
        async def orders(self,account_seq,status): return {"orders":[]}
        async def buying_power(self,account_seq,currency): return {"cashBuyingPower":"8000" if currency=="USD" else "0"}
        async def exchange_rate(self,base_currency,quote_currency): return {"rate":"1400"}
        async def stocks(self,symbols): return [{"symbol":"MSFT","sectorName":"Technology"}]
        async def daily_bars(self,symbol,count,adjusted=True): return bars
        async def aclose(self): pass
    async def fake_halts(): return {}
    async def fake_sec(symbol):
        return {"revenue_ttm_yoy_pct":15,"net_income_ttm_yoy_pct":12,"roe_pct":14,
                "operating_margin_ttm_pct":18,"net_margin_ttm_pct":10,
                "liabilities_to_assets_pct":40,"fcf_margin_ttm_pct":8}
    monkeypatch.setattr(main,"BulkMarketStore",FakeStore)
    monkeypatch.setattr(main,"TossMarketDataProvider",FakeToss)
    monkeypatch.setattr(main,"fetch_us_trading_halts",fake_halts)
    monkeypatch.setattr(main,"fetch_sec_fundamentals",fake_sec)
    client=TestClient(main.app)
    response=client.post("/scan/full-universe",headers={"X-API-Key":"test-secret"},json={
        "markets":["US"],"start_date":"2025-01-01","end_date":"2025-11-20",
        "min_observations":200,"limit":10,"account_seq":7,"fundamental_count":10})
    assert response.status_code==200
    candidate=next(x for x in response.json()["results"] if x["symbol"]=="AAA")
    assert candidate["decision"]=="BLOCKED"
    assert any("섹터 한도 초과" in x for x in candidate["decision_blockers"])


def test_korean_full_universe_scan_covers_kospi_and_kosdaq_exchanges(monkeypatch):
    from datetime import date,timedelta
    monkeypatch.setenv("API_KEY","test-secret")
    monkeypatch.setenv("EODHD_API_TOKEN","fake")
    monkeypatch.setenv("EODHD_BULK_CALL_UNITS_PER_RUN","10000")
    bars=[]; start=date(2025,1,1)
    for i in range(220):
        close=100+i*.5
        bars.append({"date":(start+timedelta(days=i)).isoformat(),"open":close,
                     "high":close+1,"low":close-1,"close":close,"volume":100000})
    class FakeStore:
        def __init__(self): pass
        async def refresh(self,exchange,start,end,budget):
            return {"exchange":exchange,"new_snapshots":1,"api_call_units_used":100}
        async def exchange_symbols(self,exchange):
            if exchange=="KO":
                return {"069500":{"Type":"ETF","Name":"KODEX 200"},
                        "AAA":{"Type":"Common Stock","Name":"Alpha"}}
            return {"BBB":{"Type":"Common Stock","Name":"Beta"}}
        def load_series(self,exchange,start,end,min_observations):
            if exchange=="KO": return {"069500":bars,"AAA":bars}
            return {"BBB":bars}
        async def close(self): pass
    class FakeToss:
        async def warnings(self,symbol): return []
        async def aclose(self): pass
    monkeypatch.setattr(main,"BulkMarketStore",FakeStore)
    monkeypatch.setattr(main,"TossMarketDataProvider",FakeToss)
    client=TestClient(main.app)
    response=client.post("/scan/full-universe",headers={"X-API-Key":"test-secret"},json={
        "markets":["KR"],"start_date":"2025-01-01","end_date":"2025-11-20",
        "min_observations":200,"limit":10,"include_fundamentals":False,"fundamental_count":0})
    assert response.status_code==200
    data=response.json()
    assert len(data["markets"]["KR"]["exchanges"])==2
    assert data["markets"]["KR"]["current_master_count"]==3
    assert data["markets"]["KR"]["api_call_units_used"]==200
    assert {x["symbol"] for x in data["results"]}=={"AAA","BBB","069500"}
