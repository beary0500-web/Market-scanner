import os,sys
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from fundamentals import extract_us_fundamentals

def fact(units):
    return {"label":"fixture","units":{"USD":units}}

def test_sec_fundamentals_respects_filing_cutoff_and_annual_growth():
    facts={"facts":{"us-gaap":{
      "Revenues":fact([
        {"fy":2024,"fp":"FY","form":"10-K","filed":"2025-02-10","start":"2024-01-01","end":"2024-12-31","val":1000},
        {"fy":2025,"fp":"FY","form":"10-K","filed":"2026-02-10","start":"2025-01-01","end":"2025-12-31","val":1200},
        {"fy":2026,"fp":"FY","form":"10-K","filed":"2027-02-10","start":"2026-01-01","end":"2026-12-31","val":1500},
      ]),
      "OperatingIncomeLoss":fact([{"form":"10-Q","filed":"2026-08-01","end":"2026-06-30","val":200}]),
      "NetIncomeLoss":fact([
        {"fy":2024,"fp":"FY","form":"10-K","filed":"2025-02-10","start":"2024-01-01","end":"2024-12-31","val":100},
        {"fy":2025,"fp":"FY","form":"10-K","filed":"2026-02-10","start":"2025-01-01","end":"2025-12-31","val":130},
      ]),
      "StockholdersEquity":fact([{"form":"10-Q","filed":"2026-08-01","end":"2026-06-30","val":500}]),
      "Assets":fact([{"form":"10-Q","filed":"2026-08-01","end":"2026-06-30","val":1000}]),
    }}}
    result=extract_us_fundamentals(facts,"2026-11-01")
    assert result["revenue_latest"]==1200
    assert result["revenue_yoy_pct_fy"]==20
    assert result["net_income_yoy_pct_fy"]==30
    assert result["revenue_filed_at"]=="2026-02-10"

def test_sec_fundamentals_no_future_filing_leakage():
    facts={"facts":{"us-gaap":{"Revenues":fact([
        {"fy":2026,"fp":"FY","form":"10-K","filed":"2027-02-10","start":"2026-01-01","end":"2026-12-31","val":1500}
    ])}}}
    result=extract_us_fundamentals(facts,"2026-11-01")
    assert result["revenue_latest"] is None
    assert result["revenue_yoy_pct_fy"] is None

def test_ttm_uses_discrete_quarters_from_ytd_and_annual_filings():
    from fundamentals import trailing_four_quarters
    rows=[
      {"fy":2025,"fp":"Q1","form":"10-Q","filed":"2025-05-01","start":"2025-01-01","end":"2025-03-31","val":100},
      {"fy":2025,"fp":"Q2","form":"10-Q","filed":"2025-08-01","start":"2025-01-01","end":"2025-06-30","val":230},
      {"fy":2025,"fp":"Q3","form":"10-Q","filed":"2025-11-01","start":"2025-01-01","end":"2025-09-30","val":390},
      {"fy":2025,"fp":"FY","form":"10-K","filed":"2026-02-15","start":"2025-01-01","end":"2025-12-31","val":560},
      {"fy":2026,"fp":"Q1","form":"10-Q","filed":"2026-05-01","start":"2026-01-01","end":"2026-03-31","val":160},
    ]
    fact_obj=fact(rows)
    result=trailing_four_quarters(fact_obj,__import__('datetime').date(2026,11,1))
    # Q2=130, Q3=160, Q4=170, Q1 2026=160 => 620
    assert result["value"]==620
    assert [q["quarter"] for q in result["quarters"]]==["Q2","Q3","Q4","Q1"]

def test_ttm_excludes_future_filed_quarter():
    from fundamentals import trailing_four_quarters
    rows=[]
    for fy,fp,start,end,val,filed in [
      (2025,"Q1","2025-01-01","2025-03-31",100,"2025-05-01"),
      (2025,"Q2","2025-01-01","2025-06-30",220,"2025-08-01"),
      (2025,"Q3","2025-01-01","2025-09-30",360,"2025-11-01"),
      (2025,"FY","2025-01-01","2025-12-31",500,"2026-02-01"),
      (2026,"Q1","2026-01-01","2026-03-31",140,"2026-05-01"),
    ]:
      rows.append({"fy":fy,"fp":fp,"form":"10-K" if fp=="FY" else "10-Q","filed":filed,"start":start,"end":end,"val":val})
    result=trailing_four_quarters(fact(rows),__import__('datetime').date(2026,4,1))
    assert result["value"]==500
    assert result["period_end"]=="2025-12-31"

def test_ttm_yoy_compares_adjacent_four_quarter_windows():
    from fundamentals import trailing_four_quarters
    rows=[]
    # FY2024 quarters: 100, 110, 120, 130 (annual 460)
    # FY2025 quarters: 120, 130, 140, 150 (annual 540)
    for fy, vals in [(2024,[100,110,120,130]),(2025,[120,130,140,150])]:
        q1,q2,q3,q4=vals
        rows.extend([
          {"fy":fy,"fp":"Q1","form":"10-Q","filed":f"{fy}-05-01","start":f"{fy}-01-01","end":f"{fy}-03-31","val":q1},
          {"fy":fy,"fp":"Q2","form":"10-Q","filed":f"{fy}-08-01","start":f"{fy}-01-01","end":f"{fy}-06-30","val":q1+q2},
          {"fy":fy,"fp":"Q3","form":"10-Q","filed":f"{fy}-11-01","start":f"{fy}-01-01","end":f"{fy}-09-30","val":q1+q2+q3},
          {"fy":fy,"fp":"FY","form":"10-K","filed":f"{fy+1}-02-15","start":f"{fy}-01-01","end":f"{fy}-12-31","val":sum(vals)},
        ])
    result=trailing_four_quarters(fact(rows),__import__('datetime').date(2026,3,1))
    assert result["prior_value"]==460
    assert result["value"]==540
    assert result["yoy_pct"]==17.39

def test_dart_amount_and_statement_normalization():
    from fundamentals_kr import parse_amount, normalize_dart_rows
    assert parse_amount("(1,234)")==-1234
    assert parse_amount("-") is None
    rows=[
      {"account_id":"ifrs-full_Revenue","account_nm":"수익(매출액)","sj_div":"IS","fs_div":"CFS","thstrm_amount":"100","thstrm_add_amount":"280","frmtrm_amount":"90","frmtrm_add_amount":"250","currency":"KRW"},
      {"account_id":"ifrs-full_Assets","account_nm":"자산총계","sj_div":"BS","fs_div":"CFS","thstrm_amount":"1,000","currency":"KRW"},
    ]
    result=normalize_dart_rows(rows,"11012")
    assert result["accounts"]["revenue"]["current_period"]==100
    assert result["accounts"]["revenue"]["current_cumulative"]==280
    assert result["accounts"]["total_assets"]["current_period"]==1000


def test_dart_corp_code_zip_parser():
    import io,zipfile
    from fundamentals_kr import parse_corp_code_zip
    xml=b'<result><list><corp_code>00126380</corp_code><corp_name>Test Corp</corp_name><stock_code>005930</stock_code></list><list><corp_code>00000001</corp_code><corp_name>Private</corp_name><stock_code></stock_code></list></result>'
    stream=io.BytesIO()
    with zipfile.ZipFile(stream,"w") as z: z.writestr("CORPCODE.xml",xml)
    rows=parse_corp_code_zip(stream.getvalue())
    assert rows==[{"corp_code":"00126380","stock_code":"005930","corp_name":"Test Corp"}]



def test_korean_ttm_uses_last_four_consecutive_quarters():
    from fundamentals_kr import calculate_kr_ttm

    def report(value_period=None, value_cumulative=None):
        return {"accounts": {"revenue": {
            "current_period": value_period,
            "current_cumulative": value_cumulative,
        }}}

    reports = {
        2025: {"Q1": report(100, 100), "H1": report(110, 210),
               "Q3": report(150, 360), "FY": report(500, 500)},
        2026: {"Q1": report(130, 130), "H1": report(140, 270),
               "Q3": report(150, 420)},
    }
    result = calculate_kr_ttm(reports)
    assert result["revenue"]["value"] == 560
    assert result["revenue"]["quarters"] == [
        "2025-Q4", "2026-Q1", "2026-Q2", "2026-Q3"
    ]


def test_korean_ttm_does_not_fill_missing_quarter_with_zero():
    from fundamentals_kr import calculate_kr_ttm

    def report(value_period=None, value_cumulative=None):
        return {"accounts": {"revenue": {
            "current_period": value_period,
            "current_cumulative": value_cumulative,
        }}}

    reports = {
        2025: {"Q1": report(100, 100), "Q3": report(300, 300), "FY": report(400, 400)},
        2026: {"Q1": report(120, 120)},
    }
    result = calculate_kr_ttm(reports)
    assert result["revenue"] is None
    assert result["data_status"] == "INSUFFICIENT_QUARTERS"


def test_korean_ttm_yoy_requires_eight_consecutive_quarters():
    from fundamentals_kr import calculate_kr_ttm

    def report(period, cumulative):
        return {"accounts": {"revenue": {
            "current_period": period, "current_cumulative": cumulative,
        }}}

    reports = {
        2024: {"Q1": report(80, 80), "H1": report(90, 170),
               "Q3": report(100, 270), "FY": report(380, 380)},
        2025: {"Q1": report(100, 100), "H1": report(110, 210),
               "Q3": report(120, 330), "FY": report(460, 460)},
    }
    result = calculate_kr_ttm(reports)
    assert result["revenue"]["value"] == 460
    assert result["revenue"]["prior_value"] == 380
    assert result["revenue"]["yoy_pct"] == 21.05


def test_sec_total_interest_bearing_debt_sums_matching_instant_facts():
    from fundamentals import _latest_interest_bearing_debt
    from datetime import date

    facts = {"us-gaap": {
        "LongTermDebtCurrent": {"units": {"USD": [{
            "filed": "2026-02-15", "end": "2025-12-31", "val": 100,
            "form": "10-K"
        }]}},
        "LongTermDebtNoncurrent": {"units": {"USD": [{
            "filed": "2026-02-15", "end": "2025-12-31", "val": 900,
            "form": "10-K"
        }]}},
    }}
    result = _latest_interest_bearing_debt(facts, date(2026, 3, 1))
    assert result["value"] == 1000
    assert result["method"] == "current_plus_noncurrent"


def test_sec_debt_pair_requires_matching_balance_sheet_date():
    from fundamentals import _latest_interest_bearing_debt
    from datetime import date

    facts = {"us-gaap": {
        "LongTermDebtCurrent": {"units": {"USD": [{
            "filed": "2026-02-15", "end": "2025-12-31", "val": 100
        }]}},
        "LongTermDebtNoncurrent": {"units": {"USD": [{
            "filed": "2026-02-15", "end": "2025-09-30", "val": 900
        }]}},
    }}
    assert _latest_interest_bearing_debt(facts, date(2026, 3, 1)) is None


def test_sec_reports_total_liabilities_to_assets_separately():
    from fundamentals import extract_us_fundamentals
    payload = {"facts": {"us-gaap": {
        "Liabilities": {"units": {"USD": [{
            "filed": "2026-02-15", "end": "2025-12-31", "val": 600,
            "form": "10-K"
        }]}},
        "Assets": {"units": {"USD": [{
            "filed": "2026-02-15", "end": "2025-12-31", "val": 1000,
            "form": "10-K"
        }]}},
    }}}
    result = extract_us_fundamentals(payload, "2026-03-01")
    assert result["total_liabilities"] == 600
    assert result["liabilities_to_assets_pct"] == 60



def test_korean_score_inputs_flatten_ttm_and_balance_sheet_metrics():
    from fundamentals_kr import build_kr_score_inputs
    ttm = {
        "revenue": {"value": 1000, "yoy_pct": 10},
        "operating_income": {"value": 150},
        "net_income": {"value": 100, "yoy_pct": 20},
        "free_cash_flow": {"value": 80},
    }
    reports = {2026: {"Q3": {"accounts": {
        "total_assets": {"current_period": 1000},
        "total_liabilities": {"current_period": 600},
        "total_equity": {"current_period": 400},
    }}}}
    result = build_kr_score_inputs(ttm, reports)
    assert result["sales_growth_pct"] == 10
    assert result["earnings_growth_pct"] == 20
    assert result["operating_margin_ttm_pct"] == 15
    assert result["net_margin_ttm_pct"] == 10
    assert result["fcf_margin_ttm_pct"] == 8
    assert result["liabilities_to_assets_pct"] == 60
    assert result["roe_pct"] == 25


def test_korean_score_inputs_leave_missing_facts_missing():
    from fundamentals_kr import build_kr_score_inputs
    result = build_kr_score_inputs({}, {})
    assert all(value is None for value in result.values())
