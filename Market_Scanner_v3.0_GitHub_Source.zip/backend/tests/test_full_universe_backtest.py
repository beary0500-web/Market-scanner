from datetime import date,timedelta
from full_universe_backtest import generate_signals


def make_bars(n=230,base=100,step=.5):
    start=date(2025,1,1); out=[]
    for i in range(n):
        c=base+i*step
        out.append({"date":(start+timedelta(days=i)).isoformat(),"open":c,
                    "high":c+1,"low":c-1,"close":c,"volume":100000})
    return out


def test_historical_signal_generator_only_uses_data_up_to_signal_day():
    series={"SPY":make_bars(),"AAA":make_bars(base=20,step=.2)}
    signals,meta=generate_signals(series,"US",min_history=200,score_threshold=0,min_coverage_pct=0)
    assert signals
    first=signals[0]
    assert first["date"] >= series["AAA"][199]["date"]
    assert meta["lookahead_control"].startswith("each signal uses only bars dated")


def test_historical_signal_generator_blocks_bear_benchmark():
    spy=make_bars()
    for i,b in enumerate(spy):
        c=200-i*.5
        b.update({"open":c,"high":c+1,"low":c-1,"close":c})
    series={"SPY":spy,"AAA":make_bars()}
    signals,_=generate_signals(series,"US",min_history=200,score_threshold=0,min_coverage_pct=0)
    assert signals==[]
