


def test_features_include_last_price_as_of_date():
    from features import features_from_bars
    from datetime import date, timedelta
    bars = []
    start = date(2025, 1, 1)
    for i in range(70):
        close = 100 + i
        bars.append({"date": (start + timedelta(days=i)).isoformat(),
                     "open": close, "high": close + 1, "low": close - 1,
                     "close": close, "volume": 1000})
    result = features_from_bars(bars, "US")
    assert result["price_as_of"] == bars[-1]["date"]
