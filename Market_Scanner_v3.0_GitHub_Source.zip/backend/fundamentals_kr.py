"""OpenDART financial-statement adapter with conservative quarterly TTM derivation."""
from __future__ import annotations
import os, re, io, zipfile, time
import xml.etree.ElementTree as ET
from typing import Any
import httpx

DART_BASE = "https://opendart.fss.or.kr/api"
REPORTS = {"Q1":"11013", "H1":"11012", "Q3":"11014", "FY":"11011"}

class DartNotConfigured(RuntimeError): pass
class DartProviderError(RuntimeError): pass

_CORP_CODE_CACHE: list[dict] | None = None
_CORP_CODE_CACHE_AT = 0.0
_CORP_CODE_CACHE_TTL = 24 * 60 * 60


async def _company_registry(client: httpx.AsyncClient, api_key: str) -> list[dict]:
    """Cache the large official corporation-code registry for one day per process."""
    global _CORP_CODE_CACHE, _CORP_CODE_CACHE_AT
    now = time.monotonic()
    if _CORP_CODE_CACHE is not None and now - _CORP_CODE_CACHE_AT < _CORP_CODE_CACHE_TTL:
        return _CORP_CODE_CACHE
    response = await client.get(f"{DART_BASE}/corpCode.xml", params={"crtfc_key": api_key})
    response.raise_for_status()
    parsed = parse_corp_code_zip(response.content)
    _CORP_CODE_CACHE = parsed
    _CORP_CODE_CACHE_AT = now
    return parsed


def parse_amount(value: Any) -> float | None:
    if value is None: return None
    raw=str(value).strip().replace(",", "")
    if not raw or raw in ("-", "N/A"): return None
    negative=raw.startswith("(") and raw.endswith(")")
    if negative: raw=raw[1:-1]
    try:
        number=float(raw)
        return -number if negative else number
    except ValueError:
        return None


def parse_corp_code_zip(content: bytes) -> list[dict]:
    """Parse official corpCode.xml ZIP into ticker/name/corp-code records."""
    with zipfile.ZipFile(io.BytesIO(content)) as archive:
        xml_name=next((n for n in archive.namelist() if n.lower().endswith(".xml")),None)
        if not xml_name: raise DartProviderError("corpCode archive contains no XML")
        root=ET.fromstring(archive.read(xml_name))
    records=[]
    for node in root.findall("list"):
        def val(tag):
            child=node.find(tag)
            return (child.text or "").strip() if child is not None else ""
        corp_code=val("corp_code"); stock_code=val("stock_code"); corp_name=val("corp_name")
        if corp_code and stock_code and re.fullmatch(r"\d{6}",stock_code):
            records.append({"corp_code":corp_code,"stock_code":stock_code,"corp_name":corp_name})
    return records


def normalize_dart_rows(rows: list[dict], report_code: str) -> dict:
    """Normalize key account rows without conflating cumulative and quarterly values."""
    aliases={
      "revenue":["ifrs-full_Revenue","ifrs_Revenue","RevenueFromContractWithCustomerExcludingAssessedTax"],
      "operating_income":["ifrs-full_ProfitLossFromOperatingActivities","OperatingIncomeLoss"],
      "net_income":["ifrs-full_ProfitLoss","ProfitLoss"],
      "total_assets":["ifrs-full_Assets","Assets"],
      "total_equity":["ifrs-full_Equity","StockholdersEquity"],
      "total_liabilities":["ifrs-full_Liabilities","Liabilities"],
      "cash_from_operations":["ifrs-full_CashFlowsFromUsedInOperatingActivities","NetCashProvidedByUsedInOperatingActivities"],
      "capital_expenditure":["ifrs-full_PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities","PaymentsToAcquirePropertyPlantAndEquipment"],
    }
    result={"report_code":report_code,"accounts":{},"source":"OpenDART"}
    for key, ids in aliases.items():
        matches=[r for r in rows if r.get("account_id") in ids]
        if not matches:
            # Korean display-name fallback is deliberately conservative.
            names={"revenue":["매출액","수익(매출액)"],"operating_income":["영업이익","영업이익(손실)"],
                   "net_income":["당기순이익","당기순이익(손실)"],"total_assets":["자산총계"],
                   "total_equity":["자본총계"],"total_liabilities":["부채총계"],
                   "cash_from_operations":["영업활동현금흐름"],"capital_expenditure":["유형자산의 취득"]}
            matches=[r for r in rows if r.get("account_nm") in names.get(key,[])]
        if matches:
            # Prefer consolidated statements when returned in a mixed fixture.
            row=next((r for r in matches if r.get("fs_div")=="CFS"),matches[0])
            result["accounts"][key]={
              "account_id":row.get("account_id"),"account_name":row.get("account_nm"),
              "statement":row.get("sj_div"),"currency":row.get("currency"),
              "current_period":parse_amount(row.get("thstrm_amount")),
              "current_cumulative":parse_amount(row.get("thstrm_add_amount")),
              "prior_period":parse_amount(row.get("frmtrm_amount")),
              "prior_cumulative":parse_amount(row.get("frmtrm_add_amount")),
            }
    return result


def calculate_kr_ttm(reports_by_year: dict[int, dict]) -> dict:
    """Calculate TTM flows from OpenDART Q1/H1/Q3/FY reports.

    OpenDART's interim reports provide both the current 3-month amount and
    year-to-date cumulative amount. The cumulative values are used to derive
    quarters when a 3-month value is absent. FY Q4 is annual minus Q3 YTD.
    Balance-sheet instant values are intentionally excluded from TTM.
    """
    flow_keys = ("revenue", "operating_income", "net_income",
                 "cash_from_operations", "capital_expenditure")
    quarter_rows = []

    def account(report, key):
        return ((report or {}).get("accounts") or {}).get(key) or {}

    years = sorted(reports_by_year)
    for year in years:
        reports = reports_by_year[year]
        q1 = reports.get("Q1")
        h1 = reports.get("H1")
        q3 = reports.get("Q3")
        fy = reports.get("FY")
        for key in flow_keys:
            q1_row, h1_row, q3_row, fy_row = (
                account(q1, key), account(h1, key), account(q3, key), account(fy, key)
            )
            q1_cum = q1_row.get("current_cumulative")
            if q1_cum is None:
                q1_cum = q1_row.get("current_period")
            q1_value = q1_row.get("current_period")
            if q1_value is None:
                q1_value = q1_cum

            h1_cum = h1_row.get("current_cumulative")
            h1_q2 = h1_row.get("current_period")
            if h1_q2 is None and h1_cum is not None and q1_cum is not None:
                h1_q2 = h1_cum - q1_cum

            q3_cum = q3_row.get("current_cumulative")
            q3_value = q3_row.get("current_period")
            if q3_value is None and q3_cum is not None and h1_cum is not None:
                q3_value = q3_cum - h1_cum

            fy_total = fy_row.get("current_period")
            if fy_total is None:
                fy_total = fy_row.get("current_cumulative")
            q4_value = None
            if fy_total is not None and q3_cum is not None:
                q4_value = fy_total - q3_cum

            values = {
                "Q1": q1_value,
                "Q2": h1_q2,
                "Q3": q3_value,
                "Q4": q4_value,
            }
            for quarter, value in values.items():
                if value is not None:
                    quarter_rows.append({
                        "fiscal_year": year, "quarter": quarter,
                        "key": key, "value": float(value)
                    })

    # A TTM value requires the four most recent sequential quarters for that
    # metric. A missing quarter is not replaced with zero.
    results = {}
    for key in flow_keys:
        by_period = {}
        for row in quarter_rows:
            if row["key"] == key:
                by_period[(row["fiscal_year"], row["quarter"])] = row["value"]
        ordered = []
        for year in years:
            for quarter in ("Q1", "Q2", "Q3", "Q4"):
                period = (year, quarter)
                if period in by_period:
                    ordered.append((period, by_period[period]))
        if len(ordered) >= 4:
            last_four = ordered[-4:]
            # Ensure no missing fiscal quarter exists between the four points.
            positions = [y * 4 + ("Q1", "Q2", "Q3", "Q4").index(q)
                         for (y, q), _ in last_four]
            if positions[-1] - positions[0] == 3:
                current_value = sum(v for _, v in last_four)
                prior_value = None
                if len(ordered) >= 8:
                    prior_four = ordered[-8:-4]
                    prior_positions = [y * 4 + ("Q1", "Q2", "Q3", "Q4").index(q)
                                       for (y, q), _ in prior_four]
                    if (prior_positions[-1] - prior_positions[0] == 3
                            and positions[0] - prior_positions[-1] == 1):
                        prior_value = sum(v for _, v in prior_four)
                yoy = (round((current_value / prior_value - 1) * 100, 2)
                       if prior_value not in (None, 0) else None)
                results[key] = {
                    "value": current_value,
                    "prior_value": prior_value,
                    "yoy_pct": yoy,
                    "quarters": [f"{y}-{q}" for (y, q), _ in last_four],
                    "period_end": f"{last_four[-1][0][0]}-{last_four[-1][0][1]}",
                }
            else:
                results[key] = None
        else:
            results[key] = None

    revenue = results.get("revenue")
    fcf = None
    cfo = results.get("cash_from_operations")
    capex = results.get("capital_expenditure")
    if cfo and capex:
        fcf = cfo["value"] - abs(capex["value"])
    results["free_cash_flow"] = (
        {"value": fcf, "period_end": cfo["period_end"], "quarters": cfo["quarters"]}
        if fcf is not None else None
    )
    results["data_status"] = "AVAILABLE" if revenue else "INSUFFICIENT_QUARTERS"
    return results


def build_kr_score_inputs(ttm: dict, reports_by_year: dict[int, dict]) -> dict:
    """Flatten Korean TTM flows and latest balance-sheet ratios for shared scoring."""
    latest_balance = None
    for report_year in sorted(reports_by_year, reverse=True):
        year_reports = reports_by_year[report_year]
        for label in ("FY", "Q3", "H1", "Q1"):
            candidate = year_reports.get(label)
            if candidate and any(
                key in candidate.get("accounts", {})
                for key in ("total_assets", "total_liabilities", "total_equity")
            ):
                latest_balance = candidate.get("accounts", {})
                break
        if latest_balance is not None:
            break

    def ttm_value(key):
        item = ttm.get(key)
        return item.get("value") if item else None

    revenue_ttm = ttm_value("revenue")
    operating_ttm = ttm_value("operating_income")
    net_ttm = ttm_value("net_income")
    fcf_ttm = ttm_value("free_cash_flow")
    assets = (latest_balance or {}).get("total_assets", {}).get("current_period")
    liabilities = (latest_balance or {}).get("total_liabilities", {}).get("current_period")
    equity = (latest_balance or {}).get("total_equity", {}).get("current_period")
    return {
        "sales_growth_pct": (ttm.get("revenue") or {}).get("yoy_pct"),
        "earnings_growth_pct": (ttm.get("net_income") or {}).get("yoy_pct"),
        "operating_margin_ttm_pct": round(operating_ttm / revenue_ttm * 100, 2)
            if operating_ttm is not None and revenue_ttm else None,
        "net_margin_ttm_pct": round(net_ttm / revenue_ttm * 100, 2)
            if net_ttm is not None and revenue_ttm else None,
        "fcf_margin_ttm_pct": round(fcf_ttm / revenue_ttm * 100, 2)
            if fcf_ttm is not None and revenue_ttm else None,
        "liabilities_to_assets_pct": round(liabilities / assets * 100, 2)
            if liabilities is not None and assets else None,
        "roe_pct": round(net_ttm / equity * 100, 2)
            if net_ttm is not None and equity else None,
        "net_income_ttm": net_ttm,
        "stockholders_equity": equity,
    }


async def fetch_kr_fundamentals(stock_code: str, bsns_year: int | None=None, fs_div: str="CFS") -> dict:
    api_key=os.getenv("DART_API_KEY")
    if not api_key: raise DartNotConfigured("DART_API_KEY must be configured on the server")
    stock_code=stock_code.strip()
    if not re.fullmatch(r"\d{6}",stock_code): raise ValueError("stock_code must be a 6-digit Korean ticker")
    if fs_div not in ("CFS","OFS"): raise ValueError("fs_div must be CFS or OFS")
    year=bsns_year or __import__("datetime").date.today().year
    params={"crtfc_key":api_key}
    async with httpx.AsyncClient(timeout=40) as client:
        companies=await _company_registry(client, api_key)
        company=next((x for x in companies if x["stock_code"]==stock_code),None)
        if not company: raise ValueError("No DART corporation code found for this stock code")
        reports_by_year={}
        for report_year in (year-2, year-1, year):
            reports={}
            for label, code in REPORTS.items():
                r=await client.get(f"{DART_BASE}/fnlttSinglAcntAll.json",params={
                    **params,"corp_code":company["corp_code"],"bsns_year":str(report_year),
                    "reprt_code":code,"fs_div":fs_div})
                r.raise_for_status(); payload=r.json()
                status=payload.get("status")
                if status=="000":
                    reports[label]=normalize_dart_rows(payload.get("list",[]),code)
                elif status=="013":
                    continue
                else:
                    raise DartProviderError(
                        f"OpenDART status {status}: {payload.get('message','unknown error')}"
                    )
            reports_by_year[report_year]=reports
    ttm=calculate_kr_ttm(reports_by_year)
    score_inputs=build_kr_score_inputs(ttm,reports_by_year)
    return {"ticker":stock_code,"company":company["corp_name"],"corp_code":company["corp_code"],
            "fiscal_year":year,"fs_div":fs_div,"reports":reports_by_year,
            "ttm":ttm,"score_inputs":score_inputs,
            "source":"OpenDART fnlttSinglAcntAll",
            "warning":"TTM is calculated only when four consecutive quarterly flow values can be derived. Issuer-specific account mapping, fiscal-year differences, restatements and missing filings may leave fields unavailable."}
