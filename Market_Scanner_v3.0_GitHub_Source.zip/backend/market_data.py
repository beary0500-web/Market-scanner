"""Provider adapters for daily OHLCV. Providers are opt-in and keys stay server-side."""
from __future__ import annotations
import os
from datetime import date
from typing import Any
import httpx

class ProviderNotConfigured(RuntimeError): pass
class ProviderError(RuntimeError): pass

class EodApiProvider:
    """Adapter for EODAPI. Free plan limits are too small for a full-universe daily scan."""
    BASE_URL = "https://eodapi.com/api/get_prices"
    def __init__(self, token: str | None = None):
        self.token = token or os.getenv("EODAPI_TOKEN")
        if not self.token:
            raise ProviderNotConfigured("EODAPI_TOKEN is not configured")

    async def daily_bars(self, symbols: list[str], start: date, end: date) -> dict[str, list[dict[str, Any]]]:
        if not symbols:
            return {}
        if len(symbols) > 3:
            raise ValueError("EODAPI free-tier adapter batches at most 3 symbols per request")
        if start > end:
            raise ValueError("start must be on or before end")
        # EODAPI free tier is limited to the latest one year of history.
        if (end - start).days > 365:
            raise ValueError("EODAPI free tier supports at most one year of history")
        # EODAPI accepts a number of trading days, not a from/to date range.
        calendar_days = (end - start).days + 1
        requested_sessions = min(252, max(1, int(calendar_days * 5 / 7) + 5))
        params = {"tickers": ",".join(symbols), "days": requested_sessions}
        headers = {"Authorization": f"Bearer {self.token}"}
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(self.BASE_URL, params=params, headers=headers)
            if response.status_code in (401,403,429):
                raise ProviderError(f"EODAPI rejected request: HTTP {response.status_code}")
            response.raise_for_status()
            payload = response.json()
        normalized = normalize_eod_payload(payload)
        return {
            symbol: [bar for bar in rows
                     if start.isoformat() <= bar["date"] <= end.isoformat()]
            for symbol, rows in normalized.items()
        }


def normalize_eod_payload(payload: Any) -> dict[str, list[dict[str, Any]]]:
    """Normalize provider output while rejecting malformed OHLCV rows."""
    if isinstance(payload, dict) and "prices" in payload:
        payload = payload["prices"]
    elif isinstance(payload, dict) and "data" in payload:
        payload = payload["data"]
    if isinstance(payload, dict):
        records = []
        for symbol, rows in payload.items():
            if isinstance(rows, list):
                records.extend(dict(r, symbol=r.get("symbol", symbol)) for r in rows if isinstance(r, dict))
    elif isinstance(payload, list):
        records = payload
    else:
        raise ProviderError("Unexpected EODAPI response shape")
    out: dict[str, list[dict[str, Any]]] = {}
    for row in records:
        symbol = str(row.get("symbol") or row.get("ticker") or "").strip().upper()
        day = str(row.get("date") or row.get("datetime") or "")[:10]
        try:
            bar = {"date": day, "open": float(row["open"]), "high": float(row["high"]),
                   "low": float(row["low"]), "close": float(row["close"]),
                   "volume": float(row.get("volume") or 0)}
        except (KeyError, TypeError, ValueError):
            continue
        if not symbol or len(day) != 10 or min(bar["open"],bar["high"],bar["low"],bar["close"]) <= 0:
            continue
        if bar["high"] < max(bar["open"],bar["close"],bar["low"]) or bar["low"] > min(bar["open"],bar["close"],bar["high"]):
            continue
        out.setdefault(symbol, []).append(bar)
    for symbol in out:
        out[symbol].sort(key=lambda x:x["date"])
    return out
