from __future__ import annotations
import os
import asyncio
import hmac
from datetime import date, datetime, timezone, timedelta
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
import httpx
from universe import fetch_us_universe, parse_krx_rows
from scoring import score_snapshot
from market_data import EodApiProvider, ProviderNotConfigured, ProviderError
from features import features_from_bars, rank_candidates
from risk import drawdown_state, size_position, portfolio_exposure
from selection import market_regime, correlation_matrix, decide_candidates
from fundamentals import fetch_sec_fundamentals, extract_us_fundamentals, SecNotConfigured
from fundamentals_kr import fetch_kr_fundamentals, DartNotConfigured, DartProviderError
from toss_market_data import TossMarketDataProvider, TossNotConfigured, TossProviderError
from backtest import run_backtest
from etf_quality import fetch_etf_quality, ETFQualityNotConfigured, ETFQualityProviderError
from us_market_warnings import fetch_us_trading_halts, USWarningProviderError
from bulk_market import BulkMarketStore, BulkMarketNotConfigured, BulkMarketBudgetError, BulkMarketProviderError
from full_universe_backtest import backtest_cached_universe
from watchlist import get_watchlist, set_watchlist, scan_watchlist, usage as watchlist_usage, WatchlistNotConfigured, WatchlistQuotaExceeded, WatchlistProviderError

app = FastAPI(title="Market Scanner API", version="3.0-dev")

class ScanInput(BaseModel):
    snapshots: list[dict] = Field(default_factory=list, max_length=5000)


class AnalyzeItem(BaseModel):
    symbol: str
    name: str | None = None
    market: str
    bars: list[dict] = Field(default_factory=list, max_length=1000)
    fundamentals: dict = Field(default_factory=dict)


class AnalyzeInput(BaseModel):
    items: list[AnalyzeItem] = Field(default_factory=list, max_length=500)

def configured_bulk_budget() -> int:
    raw = os.getenv("EODHD_BULK_CALL_UNITS_PER_RUN", "0") or "0"
    try:
        value = int(raw)
    except (TypeError, ValueError):
        raise HTTPException(status_code=503, detail="EODHD_BULK_CALL_UNITS_PER_RUN must be a non-negative integer")
    if value < 0:
        raise HTTPException(status_code=503, detail="EODHD_BULK_CALL_UNITS_PER_RUN cannot be negative")
    return value


def authorize(x_api_key: str | None):
    expected = os.getenv("API_KEY")
    if not expected:
        raise HTTPException(status_code=503, detail="API_KEY is not configured; protected API is fail-closed")
    if not x_api_key or not hmac.compare_digest(x_api_key, expected):
        raise HTTPException(status_code=401, detail="Invalid API key")

@app.get("/health")
def health():
    return {"status": "ok", "version": app.version, "time": datetime.now(timezone.utc).isoformat()}


@app.get("/watchlist")
def read_watchlist(x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    return {"items": get_watchlist(), "max_items": 12, "usage": watchlist_usage()}

@app.put("/watchlist")
def write_watchlist(body: dict, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    items=body.get("items")
    if not isinstance(items,list):
        raise HTTPException(status_code=422,detail="items must be a list")
    try:
        saved=set_watchlist(items)
        return {"items":saved,"count":len(saved),"max_items":12}
    except ValueError as exc:
        raise HTTPException(status_code=422,detail=str(exc)) from exc

@app.get("/watchlist/usage")
def read_watchlist_usage(x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    return watchlist_usage()

@app.post("/watchlist/scan")
async def run_watchlist_scan(x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    try:
        return await scan_watchlist()
    except WatchlistNotConfigured as exc:
        raise HTTPException(status_code=503,detail=str(exc)) from exc
    except WatchlistQuotaExceeded as exc:
        raise HTTPException(status_code=429,detail=str(exc)) from exc
    except WatchlistProviderError as exc:
        raise HTTPException(status_code=502,detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422,detail=str(exc)) from exc

@app.get("/universe/us")
async def us_universe(include_etfs: bool = True, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    securities = await fetch_us_universe(include_etfs=include_etfs)
    return {"market": "US", "count": len(securities), "source": "Nasdaq Trader Symbol Directory",
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "securities": [s.__dict__ for s in securities]}

@app.post("/scan/full-universe")
async def scan_full_universe(body: dict, x_api_key: str | None = Header(default=None)):
    """Whole-exchange scan plus conservative candidate gates; orders remain disabled."""
    authorize(x_api_key)
    markets=body.get("markets",["KR","US"])
    if not isinstance(markets,list) or not markets or any(x not in ("KR","US") for x in markets):
        raise HTTPException(status_code=422,detail="markets must be a non-empty list containing KR and/or US")
    markets=list(dict.fromkeys(markets))
    try:
        start=date.fromisoformat(body.get("start_date","")); end=date.fromisoformat(body.get("end_date",""))
    except (TypeError,ValueError):
        raise HTTPException(status_code=422,detail="start_date and end_date must be ISO dates")
    if start>end or (end-start).days>550:
        raise HTTPException(status_code=422,detail="date range must be ordered and no longer than 550 calendar days")
    min_obs=body.get("min_observations",200); limit=body.get("limit",100)
    include_fundamentals=body.get("include_fundamentals",True)
    fundamental_count=body.get("fundamental_count",10)
    account_seq=body.get("account_seq")
    if not isinstance(min_obs,int) or not 200<=min_obs<=500:
        raise HTTPException(status_code=422,detail="min_observations must be 200..500")
    if not isinstance(limit,int) or not 1<=limit<=500:
        raise HTTPException(status_code=422,detail="limit must be 1..500")
    if not isinstance(include_fundamentals,bool):
        raise HTTPException(status_code=422,detail="include_fundamentals must be boolean")
    if not isinstance(fundamental_count,int) or not 0<=fundamental_count<=10:
        raise HTTPException(status_code=422,detail="fundamental_count must be 0..10")
    if account_seq is not None and (not isinstance(account_seq,int) or account_seq<=0):
        raise HTTPException(status_code=422,detail="account_seq must be a positive integer")
    budget=configured_bulk_budget()
    if budget<=0:
        raise HTTPException(status_code=503,detail="Full-universe scan is disabled: configure a paid EODHD plan and EODHD_BULK_CALL_UNITS_PER_RUN server-side budget")
    store=None; toss_provider=None; summaries={}; results=[]; enrichment_errors=[]
    try:
        store=BulkMarketStore()
        exchange_jobs=[(market,exchange) for market in markets for exchange in (("KO","KQ") if market=="KR" else ("US",))]
        per_exchange_budget=budget//len(exchange_jobs)
        # Toss is needed for Korean warning checks and whenever the user selects an account.
        if "KR" in markets or account_seq is not None:
            try:
                toss_provider=TossMarketDataProvider()
            except TossNotConfigured:
                toss_provider=None
        if account_seq is not None and toss_provider is None:
            raise HTTPException(status_code=503,detail="Toss credentials are required for account-aware full-universe analysis")
        holdings=[]; open_orders=[]; holdings_loaded=False
        sector_exposure_pct={}; country_exposure_pct={}; sector_coverage_pct=100.0
        if account_seq is not None:
            holdings_payload=await toss_provider.holdings(account_seq)
            holding_items=holdings_payload.get("items",[])
            holdings=[{"symbol":x.get("symbol"),"marketCountry":x.get("marketCountry")}
                      for x in holding_items if x.get("symbol") and x.get("marketCountry") in ("KR","US")]
            open_payload=await toss_provider.orders(account_seq,"OPEN")
            open_orders=open_payload.get("orders",[])
            kr_cash=await toss_provider.buying_power(account_seq,"KRW")
            us_cash=await toss_provider.buying_power(account_seq,"USD")
            fx_payload=await toss_provider.exchange_rate("USD","KRW")
            fx_rate=float(fx_payload.get("rate"))
            market_value_block=holdings_payload.get("marketValue") or {}
            holdings_value=market_value_block.get("amount",{}) if isinstance(market_value_block,dict) else {}
            securities_krw=float(holdings_value.get("krw") or 0)+float(holdings_value.get("usd") or 0)*fx_rate
            cash_krw=float(kr_cash.get("cashBuyingPower") or 0)+float(us_cash.get("cashBuyingPower") or 0)*fx_rate
            account_total=securities_krw+cash_krw
            country_values={"KR":0.0,"US":0.0}; sector_values={}; classified=0.0
            holding_symbols=[h["symbol"] for h in holdings]; holding_metadata={}
            for offset in range(0,len(holding_symbols),200):
                chunk=holding_symbols[offset:offset+200]
                if chunk:
                    for meta in await toss_provider.stocks(chunk):
                        holding_metadata[str(meta.get("symbol") or "")]=meta
            for item in holding_items:
                market_country=item.get("marketCountry")
                mv=item.get("marketValue") or {}; amount=mv.get("amount") if isinstance(mv,dict) else mv
                if isinstance(amount,dict): value=float(amount.get("krw" if market_country=="KR" else "usd") or 0)
                else: value=float(amount or 0)
                value_krw=value if market_country=="KR" else value*fx_rate if market_country=="US" else 0
                if market_country in country_values: country_values[market_country]+=value_krw
                meta=holding_metadata.get(str(item.get("symbol") or ""),{})
                sector=meta.get("sectorName") or meta.get("sector") or meta.get("industryName") or meta.get("industry")
                if sector:
                    sector_values[sector]=sector_values.get(sector,0.0)+value_krw
                    classified+=value_krw
            if account_total>0:
                country_exposure_pct={k:v/account_total for k,v in country_values.items()}
                sector_exposure_pct={k:v/account_total for k,v in sector_values.items()}
            sector_coverage_pct=classified/securities_krw*100 if securities_krw>0 else 100.0
            holdings_loaded=True
        open_buy_symbols={x.get("symbol") for x in open_orders if x.get("side")=="BUY"}
        open_order_positions=[{"symbol":x.get("symbol"),
            "marketCountry":x.get("marketCountry") or ("KR" if str(x.get("symbol","")).isdigit() else "US")}
            for x in open_orders if x.get("symbol")]
        portfolio_symbols=holdings+open_order_positions
        us_halts={}; us_halt_error=None
        if "US" in markets:
            try: us_halts=await fetch_us_trading_halts()
            except USWarningProviderError as exc: us_halt_error=str(exc)

        for market in markets:
            exchange_codes=("KO","KQ") if market=="KR" else ("US",)
            exchange_summaries=[]; master={}; series={}; eligible={}
            for exchange in exchange_codes:
                exchange_summary=await store.refresh(exchange,start,end,per_exchange_budget)
                exchange_summaries.append(exchange_summary)
                exchange_master=await store.exchange_symbols(exchange)
                exchange_series=store.load_series(exchange,start,end,min_obs)
                for symbol,meta in exchange_master.items():
                    kind=str(meta.get("Type") or meta.get("type") or "").upper()
                    name=str(meta.get("Name") or meta.get("name") or symbol)
                    allowed_types=("COMMON STOCK","ETF","ADR","REIT")
                    if not kind or not any(k in kind for k in allowed_types):
                        continue
                    eligible[symbol]={"name":name,"security_type":"ETF" if "ETF" in kind else "STOCK",
                        "sector":meta.get("Sector") or meta.get("sector"),
                        "industry":meta.get("Industry") or meta.get("industry"),
                        "shares_outstanding":meta.get("SharesOutstanding") or meta.get("sharesOutstanding"),
                        "exchange_code":exchange}
                    master[symbol]=meta
                for symbol,bars in exchange_series.items():
                    if symbol in series:
                        by_day={str(x["date"]):x for x in series[symbol]}
                        by_day.update({str(x["date"]):x for x in bars})
                        series[symbol]=sorted(by_day.values(),key=lambda x:x["date"])
                    else:
                        series[symbol]=bars
            market_rows=[]
            for symbol,bars in series.items():
                if symbol not in eligible: continue
                features=features_from_bars(bars,market)
                scored=score_snapshot({**features,"market":market})
                market_rows.append({"symbol":symbol,"name":eligible[symbol]["name"],"market":market,
                    "security_type":eligible[symbol]["security_type"],"sector":eligible[symbol]["sector"],
                    "industry":eligible[symbol]["industry"],"shares_outstanding":eligible[symbol]["shares_outstanding"],
                    "exchange_code":eligible[symbol]["exchange_code"],
                    "features":features,**scored})
            market_rows.sort(key=lambda x:(x.get("score") is not None,x.get("score") or -1),reverse=True)
            benchmark_symbol="069500" if market=="KR" else "SPY"
            regime=market_regime(series.get(benchmark_symbol,[]))
            selected=market_rows[:limit]
            # Enrich only the highest-scoring subset; every other symbol remains blocked without fundamentals.
            enrich=selected[:fundamental_count] if include_fundamentals else []
            warning_errors=[]
            warning_semaphore=asyncio.Semaphore(2)
            async def enrich_candidate(item):
                symbol=item["symbol"]
                if market=="KR":
                    if toss_provider is None:
                        item["warnings_status"]="ERROR"
                    else:
                        try:
                            async with warning_semaphore:
                                warnings=await toss_provider.warnings(symbol)
                            item["warnings"]=warnings
                            item["warnings_status"]="ACTIVE" if warnings else "CLEAR"
                        except Exception as exc:
                            item["warnings_status"]="ERROR"; warning_errors.append(f"{symbol}: {exc}")
                else:
                    item["warnings"]=us_halts.get(symbol,[])
                    item["warnings_status"]="ERROR" if us_halt_error else ("ACTIVE" if item["warnings"] else "CLEAR")
                if not include_fundamentals:
                    return
                try:
                    if item["security_type"]=="ETF":
                        quality=await fetch_etf_quality(symbol,item.get("exchange_code") or (os.getenv("EODHD_KR_EXCHANGE","KO") if market=="KR" else os.getenv("EODHD_US_EXCHANGE","US")))
                        item["etf_quality"]=quality
                        item["etf_quality_status"]=quality.get("status","NO_DATA")
                        if quality.get("status")=="AVAILABLE":
                            item["etf_quality_score"]=quality.get("quality_score")
                            rescored=score_snapshot({**item["features"],"market":market,"instrument_type":"ETF",
                                                     "etf_quality_score":quality.get("quality_score")})
                            for key in ("score","coverage_pct","components","fundamental_detail","status"):
                                item[key]=rescored.get(key)
                        item["fundamentals_status"]="NOT_APPLICABLE"
                    else:
                        if market=="US":
                            fund=await fetch_sec_fundamentals(symbol)
                        else:
                            fund_payload=await fetch_kr_fundamentals(symbol)
                            fund=fund_payload.get("score_inputs",{})
                        shares=float(item.get("shares_outstanding") or 0)
                        price=float(item["features"].get("price") or 0)
                        net_income=float(fund.get("net_income_ttm") or 0)
                        equity=float(fund.get("stockholders_equity") or 0)
                        if shares>0 and price>0 and net_income>0:
                            fund["per"]=round(price/(net_income/shares),2)
                        if shares>0 and price>0 and equity>0:
                            fund["pbr"]=round(price*shares/equity,2)
                        item["fundamentals"]=fund
                        item["fundamentals_status"]="AVAILABLE" if any(isinstance(v,(int,float)) for v in fund.values()) else "NO_DATA"
                        rescored=score_snapshot({**item["features"],**fund,"market":market})
                        for key in ("score","coverage_pct","components","fundamental_detail","status"):
                            item[key]=rescored.get(key)
                except (SecNotConfigured,DartNotConfigured,ETFQualityNotConfigured) as exc:
                    item["fundamentals_status"]="NOT_CONFIGURED"
                    item["etf_quality_status"]="NOT_CONFIGURED" if item["security_type"]=="ETF" else item.get("etf_quality_status")
                    enrichment_errors.append(f"{market} {symbol}: {exc}")
                except Exception as exc:
                    item["fundamentals_status"]="ERROR"
                    item["etf_quality_status"]="ERROR" if item["security_type"]=="ETF" else item.get("etf_quality_status")
                    enrichment_errors.append(f"{market} {symbol}: {exc}")
            await asyncio.gather(*(enrich_candidate(x) for x in enrich))
            selected.sort(key=lambda x:(x.get("score") is not None,x.get("score") or -1),reverse=True)
            held_market=[h for h in holdings if h["marketCountry"]==market]
            order_market=[h for h in open_order_positions if h["marketCountry"]==market]
            held_symbols={h["symbol"] for h in held_market+order_market}
            holdings_history_errors=[]
            if holdings_loaded:
                for held_symbol in held_symbols:
                    if held_symbol in series: continue
                    if toss_provider is None:
                        holdings_history_errors.append(held_symbol); continue
                    try:
                        series[held_symbol]=await toss_provider.daily_bars(held_symbol,260,adjusted=True)
                    except Exception:
                        holdings_history_errors.append(held_symbol)
            corr_symbols={x["symbol"] for x in selected}|held_symbols
            corr_series={symbol:series[symbol] for symbol in corr_symbols if symbol in series}
            correlations=correlation_matrix(corr_series,min_overlap=30).get("matrix",{})
            decisions_input=[]
            for item in selected:
                decisions_input.append({**item,**item["features"],
                    "fundamentals_required":item["security_type"]!="ETF",
                    "fundamentals_status":item.get("fundamentals_status","NOT_ATTACHED"),
                    "etf_quality_required":item["security_type"]=="ETF",
                    "etf_quality_status":item.get("etf_quality_status","NOT_ATTACHED"),
                    "warnings_required":True,"warnings_status":item.get("warnings_status","NOT_CHECKED"),
                    "holdings_required":account_seq is not None,"holdings_loaded":holdings_loaded,
                    "holdings_history_complete":not holdings_history_errors,
                    "portfolio_exposure_required":account_seq is not None,
                    "sector":item.get("sector"),
                    "open_order_pending":item["symbol"] in open_buy_symbols})
            decisions=decide_candidates(decisions_input,regime,held_market,5,correlations,.85,
                sector_exposure_pct=sector_exposure_pct,country_exposure_pct=country_exposure_pct,
                max_position_pct=.15,max_sector_pct=.25,max_country_pct=.40,
                sector_coverage_pct=sector_coverage_pct)
            decision_by_symbol={x["symbol"]:x for x in decisions}
            for rank,item in enumerate(selected,1):
                decision=decision_by_symbol.get(item["symbol"],{})
                results.append({**item,"rank":rank,"market_regime":regime,
                    "decision":decision.get("decision","BLOCKED"),
                    "decision_reasons":decision.get("reasons",[]),
                    "decision_blockers":decision.get("blockers",[])})
            summaries[market]={"exchanges":exchange_summaries,
                "new_snapshots":sum(x["new_snapshots"] for x in exchange_summaries),
                "api_call_units_used":sum(x["api_call_units_used"] for x in exchange_summaries),
                "current_master_count":len(master),"symbols_with_history":len(series),"eligible_symbols":len(market_rows),
                "benchmark_symbol":benchmark_symbol,"market_regime":regime,
                "fundamentals_enriched":len(enrich),"holdings_loaded":holdings_loaded,
                "holdings_count":len(held_market),"holdings_history_errors":holdings_history_errors,
                "sector_exposure_pct":sector_exposure_pct,"country_exposure_pct":country_exposure_pct,
                "sector_classification_coverage_pct":sector_coverage_pct,
                "warning_errors":warning_errors}
        return {"provider":"EODHD_BULK_EOD","universe_scope":"WHOLE_CURRENT_EXCHANGE_MASTER",
            "date_range":{"start":start.isoformat(),"end":end.isoformat()},"markets":summaries,
            "count":len(results),"results":results,"fundamentals_requested":include_fundamentals,
            "fundamental_errors":enrichment_errors,"us_halt_feed_error":us_halt_error,
            "holdings_loaded":holdings_loaded,"open_buy_orders_count":len(open_buy_symbols),
            "correlation_limit":.85,"execution":"DISABLED",
            "warning":"BUY_CANDIDATE is a research gate, not an order. Current exchange master is used for candidate eligibility; historical survivorship-free membership, point-in-time fundamentals, delisting proceeds, taxes, FX execution costs and market impact are not fully represented. All order execution remains disabled."}
    except BulkMarketNotConfigured as exc: raise HTTPException(status_code=503,detail=str(exc))
    except BulkMarketBudgetError as exc: raise HTTPException(status_code=402,detail=str(exc))
    except BulkMarketProviderError as exc: raise HTTPException(status_code=502,detail=str(exc))
    except (TossNotConfigured,TossProviderError) as exc: raise HTTPException(status_code=502,detail=str(exc))
    except ValueError as exc: raise HTTPException(status_code=422,detail=str(exc))
    finally:
        if toss_provider is not None: await toss_provider.aclose()
        if store is not None: await store.close()


@app.post("/scan/score")
def score_batch(body: ScanInput, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    scored = []
    for item in body.snapshots:
        scored.append({"symbol": item.get("symbol"), "name": item.get("name"),
                       "market": item.get("market"), **score_snapshot(item)})
    scored.sort(key=lambda x: (x["score"] is not None, x["score"] or -1), reverse=True)
    return {"count": len(scored), "results": scored,
            "note": "Scores are heuristic research signals, not investment advice."}

@app.get("/universe/kr")
async def kr_universe(bas_dd: str, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    auth = os.getenv("KRX_AUTH_KEY")
    if not auth:
        raise HTTPException(status_code=503, detail="KRX_AUTH_KEY is not configured on the server")
    base = os.getenv("KRX_BASE_URL", "https://data-dbg.krx.co.kr/svc/apis").rstrip("/")
    ids = [os.getenv("KRX_STOCK_BASE_API_ID", "stk_isu_base_info"),
           os.getenv("KRX_KOSDAQ_BASE_API_ID", "ksq_isu_base_info")]
    headers = {"AUTH_KEY": auth, "Content-Type": "application/json"}
    result = []
    async with httpx.AsyncClient(timeout=30) as client:
        for api_id, market in zip(ids, ("KOSPI", "KOSDAQ")):
            url = f"{base}/sto/{api_id}"
            response = await client.post(url, headers=headers, json={"basDd": bas_dd})
            response.raise_for_status()
            payload = response.json()
            rows = payload.get("OutBlock_1", payload.get("output", []))
            result.extend(parse_krx_rows(rows, market))
    return {"market": "KR", "count": len(result), "as_of": bas_dd,
            "source": "KRX Open API", "securities": [s.__dict__ for s in result]}


@app.get("/market/kr/daily")
async def kr_daily_market_data(bas_dd: str, market: str = "KOSPI", x_api_key: str | None = Header(default=None)):
    """KRX daily market snapshot for one market/date. Requires approved KRX API access."""
    authorize(x_api_key)
    auth = os.getenv("KRX_AUTH_KEY")
    if not auth:
        raise HTTPException(status_code=503, detail="KRX_AUTH_KEY is not configured on the server")
    if len(bas_dd) != 8 or not bas_dd.isdigit():
        raise HTTPException(status_code=422, detail="bas_dd must be YYYYMMDD")
    market = market.upper()
    api_map = {
        "KOSPI": os.getenv("KRX_STOCK_DAILY_API_ID", "stk_bydd_trd"),
        "KOSDAQ": os.getenv("KRX_KOSDAQ_DAILY_API_ID", "ksq_bydd_trd"),
    }
    if market not in api_map:
        raise HTTPException(status_code=422, detail="market must be KOSPI or KOSDAQ")
    base_url = os.getenv("KRX_BASE_URL", "https://data-dbg.krx.co.kr/svc/apis").rstrip("/")
    headers = {"AUTH_KEY": auth, "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(f"{base_url}/sto/{api_map[market]}", headers=headers, json={"basDd": bas_dd})
        response.raise_for_status()
        payload = response.json()
    rows = payload.get("OutBlock_1", payload.get("output", []))
    normalized = []
    for row in rows:
        def n(key):
            raw = str(row.get(key, "")).replace(",", "").strip()
            try: return float(raw) if raw else None
            except ValueError: return None
        normalized.append({
            "symbol": str(row.get("ISU_SRT_CD") or row.get("ISU_CD") or "").strip(),
            "name": str(row.get("ISU_ABBRV") or row.get("ISU_NM") or "").strip(),
            "market": market,
            "date": bas_dd,
            "close": n("TDD_CLSPRC"),
            "open": n("TDD_OPNPRC"),
            "high": n("TDD_HGPRC"),
            "low": n("TDD_LWPRC"),
            "volume": n("ACC_TRDVOL"),
            "turnover": n("ACC_TRDVAL"),
            "market_cap": n("MKTCAP"),
            "listed_shares": n("LIST_SHRS"),
        })
    return {"market": market, "date": bas_dd, "count": len(normalized),
            "source": "KRX Open API", "data": normalized}

@app.get("/market/kr/etf/daily")
async def kr_etf_daily(bas_dd: str, x_api_key: str | None = Header(default=None)):
    """KRX ETF daily snapshot including NAV, net assets, benchmark and turnover."""
    authorize(x_api_key)
    auth = os.getenv("KRX_AUTH_KEY")
    if not auth:
        raise HTTPException(status_code=503, detail="KRX_AUTH_KEY is not configured on the server")
    if len(bas_dd) != 8 or not bas_dd.isdigit():
        raise HTTPException(status_code=422, detail="bas_dd must be YYYYMMDD")
    base = os.getenv("KRX_BASE_URL", "https://data-dbg.krx.co.kr/svc/apis").rstrip("/")
    api_id = os.getenv("KRX_ETF_DAILY_API_ID", "etf_bydd_trd")
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(f"{base}/etp/{api_id}",
            headers={"AUTH_KEY": auth, "Content-Type": "application/json"},
            json={"basDd": bas_dd})
        response.raise_for_status(); payload = response.json()
    rows = payload.get("OutBlock_1", payload.get("output", []))
    data = []
    for row in rows:
        def number(key):
            raw = str(row.get(key, "")).replace(",", "").strip()
            try: return float(raw) if raw else None
            except ValueError: return None
        data.append({
            "symbol": str(row.get("ISU_SRT_CD") or row.get("ISU_CD") or "").strip(),
            "name": str(row.get("ISU_ABBRV") or row.get("ISU_NM") or "").strip(),
            "date": bas_dd, "close": number("TDD_CLSPRC"), "nav": number("NAV"),
            "volume": number("ACC_TRDVOL"), "turnover": number("ACC_TRDVAL"),
            "market_cap": number("MKTCAP"), "net_assets": number("INVSTASST_NETASST_TOTAMT"),
            "listed_shares": number("LIST_SHRS"), "benchmark_name": row.get("IDX_IND_NM"),
            "benchmark_close": number("OBJ_STKPRC_IDX"),
            "benchmark_return_pct": number("FLUC_RT_IDX"),
        })
    return {"market":"KR", "date":bas_dd, "count":len(data),
            "source":"KRX Open API etf_bydd_trd", "data":data,
            "warning":"This daily snapshot does not include expense ratio, tracking difference history or full portfolio holdings."}


@app.get("/market/kr/screen")
async def kr_liquidity_screen(bas_dd: str, market: str = "KOSPI", min_turnover: float = 1_000_000_000,
                              top_n: int = 100, x_api_key: str | None = Header(default=None)):
    """First-pass screen only: ranks by daily turnover, not an investment recommendation."""
    authorize(x_api_key)
    if not 1 <= top_n <= 1000:
        raise HTTPException(status_code=422, detail="top_n must be between 1 and 1000")
    # Reuse the validated daily-data collector.
    data = await kr_daily_market_data(bas_dd, market, x_api_key)
    rows = [r for r in data["data"] if (r.get("turnover") or 0) >= min_turnover]
    rows.sort(key=lambda r: r.get("turnover") or 0, reverse=True)
    return {"market": market, "date": bas_dd, "count": len(rows),
            "screen": {"minimum_daily_turnover": min_turnover, "sort": "turnover_desc"},
            "results": rows[:top_n],
            "warning": "Liquidity pre-screen only; no price-history or fundamental quality assessment."}


@app.get("/market-data/provider-status")
def market_data_provider_status(x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    return {"eodapi_configured": bool(os.getenv("EODAPI_TOKEN")),
            "provider": "EODAPI" if os.getenv("EODAPI_TOKEN") else None,
            "mode": "daily_bars",
            "warning": "Free plan is a limited validation tier, not sufficient for full-universe scanning."}

@app.get("/market-data/us/trading-halts/{symbol}")
async def us_trading_halts(symbol: str, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    symbol = symbol.strip().upper()
    if not symbol.isalnum() or len(symbol) > 12:
        raise HTTPException(status_code=422, detail="Invalid US symbol")
    try:
        halted = await fetch_us_trading_halts()
        return {"symbol": symbol, "warnings": halted.get(symbol, []),
                "status": "ACTIVE" if halted.get(symbol) else "CLEAR",
                "source": "Nasdaq Trader current trading halts RSS"}
    except USWarningProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc))


@app.get("/toss/accounts")
async def toss_accounts(x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    provider = None
    try:
        provider = TossMarketDataProvider()
        accounts = await provider.accounts()
        safe_accounts = []
        for account in accounts:
            number = str(account.get("accountNo") or "")
            safe_accounts.append({
                "accountSeq": account.get("accountSeq"),
                "accountType": account.get("accountType"),
                "maskedAccountNo": ("*" * max(0, len(number) - 4) + number[-4:]) if number else None,
            })
        return {"count": len(safe_accounts), "accounts": safe_accounts,
                "read_only": True, "order_execution": "DISABLED"}
    except TossNotConfigured as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except TossProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    finally:
        if provider is not None:
            await provider.aclose()


@app.get("/toss/orders")
async def toss_orders(account_seq: int, status: str = "OPEN",
                      x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    provider = None
    try:
        provider = TossMarketDataProvider()
        result = await provider.orders(account_seq, status)
        safe_orders = [{
            "orderId": x.get("orderId"), "symbol": x.get("symbol"),
            "side": x.get("side"), "orderType": x.get("orderType"),
            "status": x.get("status"), "price": x.get("price"),
            "quantity": x.get("quantity"), "currency": x.get("currency"),
            "orderedAt": x.get("orderedAt"),
        } for x in result.get("orders", [])]
        return {"account_seq": account_seq, "status": status.upper(),
                "count": len(safe_orders), "orders": safe_orders,
                "read_only": True, "order_execution": "DISABLED"}
    except TossNotConfigured as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except TossProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    finally:
        if provider is not None:
            await provider.aclose()


@app.get("/toss/holdings")
async def toss_holdings(account_seq: int, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    provider = None
    try:
        provider = TossMarketDataProvider()
        result = await provider.holdings(account_seq)
        return {"account_seq": account_seq, "read_only": True, "data": result}
    except TossNotConfigured as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except TossProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    finally:
        if provider is not None:
            await provider.aclose()


@app.get("/toss/buying-power")
async def toss_buying_power(account_seq: int, currency: str,
                            x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    provider = None
    try:
        provider = TossMarketDataProvider()
        result = await provider.buying_power(account_seq, currency)
        return {"account_seq": account_seq, "read_only": True, "data": result}
    except TossNotConfigured as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except TossProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    finally:
        if provider is not None:
            await provider.aclose()


@app.get("/toss/exchange-rate")
async def toss_exchange_rate(base_currency: str = "USD", quote_currency: str = "KRW",
                            x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    provider = None
    try:
        provider = TossMarketDataProvider()
        result = await provider.exchange_rate(base_currency, quote_currency)
        return {"read_only": True, "data": result}
    except TossNotConfigured as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except TossProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    finally:
        if provider is not None:
            await provider.aclose()


@app.get("/toss/portfolio-summary")
async def toss_portfolio_summary(account_seq: int, x_api_key: str | None = Header(default=None)):
    """Approximate total portfolio value in KRW from holdings, buying power and FX."""
    authorize(x_api_key)
    provider = None
    try:
        provider = TossMarketDataProvider()
        holdings = await provider.holdings(account_seq)
        krw_cash = await provider.buying_power(account_seq, "KRW")
        usd_cash = await provider.buying_power(account_seq, "USD")
        fx = await provider.exchange_rate("USD", "KRW")
        rate = float(fx.get("rate"))
        market_value_block = holdings.get("marketValue") or {}
        summary = market_value_block.get("amount", {}) if isinstance(market_value_block, dict) else {}
        if isinstance(summary, dict):
            holdings_krw = float(summary.get("krw") or 0)
            holdings_usd = float(summary.get("usd") or 0)
        else:
            holdings_krw = float(market_value_block.get("krw") or 0) if isinstance(market_value_block, dict) else 0.0
            holdings_usd = float(market_value_block.get("usd") or 0) if isinstance(market_value_block, dict) else 0.0
        cash_krw = float(krw_cash.get("cashBuyingPower") or 0)
        cash_usd = float(usd_cash.get("cashBuyingPower") or 0)
        securities_krw = holdings_krw + holdings_usd * rate
        cash_total_krw = cash_krw + cash_usd * rate
        total_krw = securities_krw + cash_total_krw
        country = {"KR": 0.0, "US": 0.0}
        holding_items = holdings.get("items", [])
        sector_values = {}
        classified_value = 0.0
        symbols = [str(x.get("symbol")) for x in holding_items if x.get("symbol")]
        metadata = {}
        for offset in range(0, len(symbols), 200):
            chunk = symbols[offset:offset+200]
            if chunk:
                for stock in await provider.stocks(chunk):
                    metadata[str(stock.get("symbol") or "")] = stock
        for item in holding_items:
            market_country = item.get("marketCountry")
            item_market_value = item.get("marketValue") or {}
            item_amount = item_market_value.get("amount") if isinstance(item_market_value, dict) else item_market_value
            if isinstance(item_amount, dict):
                value = float(item_amount.get("krw" if market_country == "KR" else "usd") or 0)
            else:
                value = float(item_amount or 0)
            value_krw = value if market_country == "KR" else value * rate if market_country == "US" else 0
            if market_country == "KR": country["KR"] += value
            elif market_country == "US": country["US"] += value_krw
            info = metadata.get(str(item.get("symbol") or ""), {})
            sector = (info.get("sectorName") or info.get("sector") or
                      info.get("industryName") or info.get("industry") or "UNCLASSIFIED")
            sector_values[sector] = sector_values.get(sector, 0.0) + value_krw
            if sector != "UNCLASSIFIED": classified_value += value_krw
        return {
            "account_seq": account_seq,
            "currency": "KRW",
            "fx": {"USD_KRW": rate, "valid_until": fx.get("validUntil")},
            "securities_krw": round(securities_krw, 2),
            "cash_buying_power_krw": round(cash_total_krw, 2),
            "total_estimated_value_krw": round(total_krw, 2),
            "country_exposure_krw": {k: round(v, 2) for k, v in country.items()},
            "country_exposure_pct_of_total": {
                k: round(v / total_krw * 100, 2) if total_krw else 0 for k, v in country.items()
            },
            "sector_exposure_krw": {k: round(v, 2) for k, v in sector_values.items()},
            "sector_exposure_pct_of_total": {
                k: round(v / total_krw * 100, 2) if total_krw else 0 for k, v in sector_values.items()
            },
            "sector_classification_coverage_pct": round(classified_value / securities_krw * 100, 2) if securities_krw else 0,
            "cash_pct_of_total": round(cash_total_krw / total_krw * 100, 2) if total_krw else 0,
            "caveat": "Estimate includes holdings market value and cash buying power only. It excludes pending orders, unsettled cash, options/bonds, taxes and other account assets. Toss display FX is indicative and may differ from execution FX.",
            "read_only": True,
        }
    except TossNotConfigured as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=502, detail=f"Unable to normalize portfolio data: {exc}")
    except TossProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    finally:
        if provider is not None:
            await provider.aclose()


@app.get("/toss/commissions")
async def toss_commissions(account_seq: int, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    provider = None
    try:
        provider = TossMarketDataProvider()
        result = await provider.commissions(account_seq)
        return {"account_seq": account_seq, "read_only": True, "data": result}
    except TossNotConfigured as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except TossProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    finally:
        if provider is not None:
            await provider.aclose()


@app.get("/market-data/toss/provider-status")
def toss_market_data_status(x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    return {
        "configured": bool(os.getenv("TOSS_CLIENT_ID") and os.getenv("TOSS_CLIENT_SECRET")),
        "provider": "TOSS_OPEN_API" if os.getenv("TOSS_CLIENT_ID") and os.getenv("TOSS_CLIENT_SECRET") else None,
        "mode": "read_only_market_data",
        "order_execution": "DISABLED",
        "note": "Broker credentials are used only by the server. A registered static egress IP is required."
    }


@app.get("/market-data/toss/rankings")
async def toss_rankings(market_country: str = "US", duration: str = "1d",
                        count: int = 100, ranking_type: str = "MARKET_TRADING_AMOUNT",
                        x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    provider = None
    try:
        provider = TossMarketDataProvider()
        result = await provider.rankings(market_country, duration, count, ranking_type)
        return {"provider": "TOSS_OPEN_API", "market_country": market_country.upper(),
                **result, "universe_scope": "TOP_RANKED_ONLY",
                "note": "This is a ranking-based candidate universe, not the complete exchange listing."}
    except TossNotConfigured as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except TossProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    finally:
        if provider is not None:
            await provider.aclose()


@app.post("/market-data/toss/daily")
async def toss_daily_bars(body: dict, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    symbols = body.get("symbols") or []
    if not isinstance(symbols, list) or not 1 <= len(symbols) <= 20 or not all(isinstance(x, str) for x in symbols):
        raise HTTPException(status_code=422, detail="symbols must be a list of 1 to 20 ticker strings")
    count = body.get("count", 260)
    adjusted = body.get("adjusted", True)
    if not isinstance(count, int) or not 1 <= count <= 1000:
        raise HTTPException(status_code=422, detail="count must be between 1 and 1000")
    if not isinstance(adjusted, bool):
        raise HTTPException(status_code=422, detail="adjusted must be boolean")
    provider = None
    try:
        provider = TossMarketDataProvider()
        result = {}
        for symbol in symbols:
            result[symbol] = await provider.daily_bars(symbol, count, adjusted)
        return {"provider": "TOSS_OPEN_API", "count": sum(len(v) for v in result.values()),
                "adjusted": adjusted, "data": result,
                "note": "Read-only market data. No order execution."}
    except TossNotConfigured as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except TossProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    finally:
        if provider is not None:
            await provider.aclose()


@app.post("/market-data/toss/prices")
async def toss_prices(body: dict, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    symbols = body.get("symbols") or []
    if not isinstance(symbols, list) or not 1 <= len(symbols) <= 200 or not all(isinstance(x, str) for x in symbols):
        raise HTTPException(status_code=422, detail="symbols must be a list of 1 to 200 ticker strings")
    provider = None
    try:
        provider = TossMarketDataProvider()
        result = await provider.prices(symbols)
        return {"provider": "TOSS_OPEN_API", "count": len(result), "data": result}
    except TossNotConfigured as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except TossProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    finally:
        if provider is not None:
            await provider.aclose()


@app.post("/market-data/us/daily")
async def us_daily_bars(body: dict, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    symbols = body.get("symbols") or []
    if not isinstance(symbols,list) or len(symbols)>3 or not all(isinstance(x,str) for x in symbols):
        raise HTTPException(status_code=422, detail="symbols must be a list of at most 3 ticker strings")
    try:
        provider = EodApiProvider()
        from datetime import date
        start=date.fromisoformat(body["start"])
        end=date.fromisoformat(body["end"])
        if start>end: raise ValueError("start must be on or before end")
        result=await provider.daily_bars(symbols,start,end)
        return {"provider":"EODAPI","count":sum(len(v) for v in result.values()),"data":result}
    except ProviderNotConfigured as exc:
        raise HTTPException(status_code=503,detail=str(exc))
    except (KeyError,ValueError) as exc:
        raise HTTPException(status_code=422,detail=str(exc))
    except ProviderError as exc:
        raise HTTPException(status_code=502,detail=str(exc))

@app.post("/scan/toss-ranked")
async def scan_toss_ranked(body: dict, x_api_key: str | None = Header(default=None)):
    """Scan a bounded shortlist from Toss market-wide rankings; not the full exchange universe."""
    authorize(x_api_key)
    markets = body.get("markets", ["KR", "US"])
    if not isinstance(markets, list) or not markets or any(x not in ("KR", "US") for x in markets):
        raise HTTPException(status_code=422, detail="markets must be a non-empty list containing KR and/or US")
    markets = list(dict.fromkeys(markets))
    count = body.get("count_per_market", 20)
    history_count = body.get("history_count", 260)
    duration = body.get("duration", "1w")
    ranking_type = body.get("ranking_type", "MARKET_TRADING_AMOUNT")
    include_fundamentals = body.get("include_fundamentals", False)
    fundamental_count = body.get("fundamental_count", 5)
    account_seq = body.get("account_seq")
    if account_seq is not None and (not isinstance(account_seq, int) or account_seq <= 0):
        raise HTTPException(status_code=422, detail="account_seq must be a positive integer")
    if not isinstance(count, int) or not 1 <= count <= 100:
        raise HTTPException(status_code=422, detail="count_per_market must be between 1 and 100")
    if not isinstance(history_count, int) or not 200 <= history_count <= 600:
        raise HTTPException(status_code=422, detail="history_count must be between 200 and 600")
    if not isinstance(include_fundamentals, bool):
        raise HTTPException(status_code=422, detail="include_fundamentals must be boolean")
    if not isinstance(fundamental_count, int) or not 0 <= fundamental_count <= 10:
        raise HTTPException(status_code=422, detail="fundamental_count must be between 0 and 10")
    provider = None
    try:
        provider = TossMarketDataProvider()
        rankings_by_market = {}
        bars_by_market = {market: {} for market in markets}
        for market in markets:
            ranked = await provider.rankings(market, duration, 100, ranking_type, True)
            selected_rankings = ranked.get("rankings", [])[:count]
            symbols = [x.get("symbol") for x in selected_rankings if x.get("symbol")]
            metadata = await provider.stocks(symbols) if symbols else []
            metadata_by_symbol = {x.get("symbol"): x for x in metadata}
            # Exclude inactive instruments and non-stock/non-ETF products.
            filtered = []
            for item in selected_rankings:
                info = metadata_by_symbol.get(item.get("symbol"), {})
                if info.get("status") not in (None, "ACTIVE"):
                    continue
                if info.get("securityType") not in (
                    None, "STOCK", "FOREIGN_STOCK", "DEPOSITARY_RECEIPT",
                    "ETF", "FOREIGN_ETF", "REIT"
                ):
                    continue
                if info.get("isCommonShare") is False:
                    continue
                item = {**item, "name": info.get("name") or item.get("symbol"),
                        "securityType": info.get("securityType"),
                        "sharesOutstanding": info.get("sharesOutstanding")}
                filtered.append(item)
            rankings_by_market[market] = filtered

        holdings = []
        open_orders = []
        holdings_loaded = False
        if account_seq is not None:
            holdings_result = await provider.holdings(account_seq)
            holdings_items = holdings_result.get("items", [])
            holdings = [
                {"symbol": x.get("symbol"), "marketCountry": x.get("marketCountry")}
                for x in holdings_items if x.get("symbol") and x.get("marketCountry") in ("KR", "US")
            ]
            order_result = await provider.orders(account_seq, "OPEN")
            open_orders = order_result.get("orders", [])
            holdings_loaded = True
        open_order_symbols = {x.get("symbol") for x in open_orders if x.get("side") == "BUY"}
        open_order_positions = [
            {"symbol": x.get("symbol"),
             "marketCountry": "KR" if str(x.get("symbol", "")).isdigit() else "US"}
            for x in open_orders if x.get("symbol")
        ]
        portfolio_symbols = holdings + open_order_positions

        semaphore = asyncio.Semaphore(3)

        async def analyze_one(market, item):
            symbol = item.get("symbol")
            if not symbol:
                return None
            async with semaphore:
                bars = await provider.daily_bars(symbol, history_count, adjusted=True)
                warnings = await provider.warnings(symbol) if market == "KR" else []
            bars_by_market[market][symbol] = bars
            features = features_from_bars(bars, market)
            scored = score_snapshot({**features, "market": market})
            return {
                "symbol": symbol,
                "name": item.get("name") or symbol,
                "market": market,
                "security_type": item.get("securityType"),
                "shares_outstanding": item.get("sharesOutstanding"),
                "rank": item.get("rank"),
                "ranking_price": item.get("price"),
                "trading_amount": item.get("tradingAmount"),
                "trading_volume": item.get("tradingVolume"),
                "features": features,
                **scored,
                "fundamentals_status": "NOT_APPLICABLE" if item.get("securityType") in ("ETF", "FOREIGN_ETF") else "NOT_ATTACHED",
                "fundamentals_required": item.get("securityType") not in ("ETF", "FOREIGN_ETF"),
                "etf_quality_required": item.get("securityType") in ("ETF", "FOREIGN_ETF"),
                "etf_quality_status": "NOT_CONFIGURED" if item.get("securityType") in ("ETF", "FOREIGN_ETF") else None,
                "warnings": warnings,
                "warnings_status": ("ACTIVE" if warnings else "CLEAR") if market == "KR" else "PENDING",
                "warnings_required": True,
            }

        tasks = [
            analyze_one(market, item)
            for market, items in rankings_by_market.items()
            for item in items
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        analyzed = []
        errors = []
        for result in results:
            if isinstance(result, Exception):
                errors.append(str(result))
            elif result is not None:
                analyzed.append(result)
        us_halt_error = None
        if "US" in markets:
            try:
                halted = await fetch_us_trading_halts()
                for item in analyzed:
                    if item["market"] == "US":
                        item["warnings"] = halted.get(item["symbol"], [])
                        item["warnings_status"] = "ACTIVE" if item["warnings"] else "CLEAR"
            except USWarningProviderError as exc:
                us_halt_error = str(exc)
                for item in analyzed:
                    if item["market"] == "US":
                        item["warnings"] = []
                        item["warnings_status"] = "ERROR"
        analyzed.sort(key=lambda x: (x["score"] is not None, x["score"] or -1), reverse=True)
        # Add held symbols' histories to the same-market correlation universe.
        holdings_history_errors = {market: [] for market in markets}
        if holdings_loaded:
            for held in portfolio_symbols:
                market = held["marketCountry"]
                symbol = held["symbol"]
                if market not in bars_by_market:
                    holdings_history_errors.setdefault(market, []).append(symbol)
                    continue
                if symbol in bars_by_market[market]:
                    continue
                try:
                    bars_by_market[market][symbol] = await provider.daily_bars(
                        symbol, history_count, adjusted=True
                    )
                except Exception:
                    # Missing held-symbol history means correlation risk cannot be cleared.
                    holdings_history_errors.setdefault(market, []).append(symbol)

        market_regimes = {}
        correlations_by_market = {}
        for market in markets:
            try:
                if market == "KR":
                    benchmark_bars = await provider.market_indicator_daily_bars("KOSPI", history_count)
                else:
                    benchmark_bars = await provider.daily_bars("SPY", history_count, adjusted=True)
                market_regimes[market] = market_regime(benchmark_bars)
            except Exception as exc:
                market_regimes[market] = {"state": "UNKNOWN", "reason": str(exc)}
            correlations_by_market[market] = correlation_matrix(
                bars_by_market[market], min_overlap=30
            ).get("matrix", {})
        fundamental_errors = []
        if include_fundamentals and fundamental_count:
            selected = []
            for market in markets:
                selected.extend([x for x in analyzed if x["market"] == market][:fundamental_count])
            fund_semaphore = asyncio.Semaphore(2)

            async def attach_fundamentals(item):
                async with fund_semaphore:
                    try:
                        if item.get("security_type") in ("ETF", "FOREIGN_ETF"):
                            exchange = os.getenv("EODHD_US_EXCHANGE", "US") if item["market"] == "US" else os.getenv("EODHD_KR_EXCHANGE", "KO")
                            quality = await fetch_etf_quality(item["symbol"], exchange)
                            item["etf_quality"] = quality
                            item["etf_quality_status"] = quality.get("status", "NO_DATA")
                            if quality.get("status") == "AVAILABLE":
                                item["etf_quality_score"] = quality.get("quality_score")
                                rescored = score_snapshot({**item["features"], "market": item["market"],
                                                           "instrument_type": "ETF",
                                                           "etf_quality_score": quality.get("quality_score")})
                                for key in ("score", "coverage_pct", "components", "fundamental_detail", "status"):
                                    item[key] = rescored.get(key)
                            else:
                                item["etf_quality_status"] = quality.get("status", "INSUFFICIENT_DATA")
                            return
                        if item["market"] == "US":
                            if (not os.getenv("SEC_USER_AGENT") or "example.com" in os.getenv("SEC_USER_AGENT", "").lower()
                                    or "replace-with" in os.getenv("SEC_USER_AGENT", "").lower()):
                                item["fundamentals_status"] = "NOT_CONFIGURED"
                                return
                            fund = await fetch_sec_fundamentals(item["symbol"])
                        else:
                            if not os.getenv("DART_API_KEY"):
                                item["fundamentals_status"] = "NOT_CONFIGURED"
                                return
                            fund = await fetch_kr_fundamentals(item["symbol"])
                            fund = fund.get("score_inputs", {})
                        shares = float(item.get("shares_outstanding") or 0)
                        price = float(item["features"].get("price") or 0)
                        net_income_ttm = float(fund.get("net_income_ttm") or 0)
                        equity = float(fund.get("stockholders_equity") or 0)
                        if shares > 0 and price > 0 and net_income_ttm > 0:
                            fund["per"] = round(price / (net_income_ttm / shares), 2)
                        if shares > 0 and price > 0 and equity > 0:
                            fund["pbr"] = round(price * shares / equity, 2)
                        item["fundamentals"] = fund
                        item["fundamentals_status"] = "AVAILABLE" if any(
                            isinstance(v, (int, float)) for v in fund.values()
                        ) else "NO_DATA"
                        rescored = score_snapshot({**item["features"], **fund, "market": item["market"]})
                        for key in ("score", "coverage_pct", "components", "fundamental_detail", "status"):
                            item[key] = rescored.get(key)
                    except Exception as exc:
                        item["fundamentals_status"] = "ERROR"
                        fundamental_errors.append(f"{item['symbol']}: {exc}")

            await asyncio.gather(*(attach_fundamentals(item) for item in selected))
            analyzed.sort(key=lambda x: (x["score"] is not None, x["score"] or -1), reverse=True)
        decisions_by_symbol = {}
        for market in markets:
            market_rows = []
            for item in analyzed:
                if item["market"] == market:
                    market_rows.append({**item, **item["features"],
                                        "holdings_required": account_seq is not None,
                                        "holdings_loaded": holdings_loaded,
                                        "holdings_history_complete": not holdings_history_errors.get(market, []),
                                        "open_order_pending": item["symbol"] in open_order_symbols,
                                        "warnings_required": item.get("warnings_required", False),
                                        "warnings_status": item.get("warnings_status", "ERROR")})
            decisions = decide_candidates(
                market_rows, market_regimes[market],
                holdings=[h for h in holdings if h["marketCountry"] == market],
                max_candidates=5, correlations=correlations_by_market[market],
                correlation_limit=0.85
            )
            for item in decisions:
                decisions_by_symbol[item["symbol"]] = item
        for item in analyzed:
            item["decision"] = decisions_by_symbol.get(item["symbol"], {}).get("decision", "BLOCKED")
            item["decision_reasons"] = decisions_by_symbol.get(item["symbol"], {}).get("reasons", [])
            item["decision_blockers"] = decisions_by_symbol.get(item["symbol"], {}).get("blockers", [])
        return {
            "provider": "TOSS_OPEN_API",
            "universe_scope": "TOP_RANKED_ONLY",
            "ranking_type": ranking_type,
            "duration": duration,
            "history_count": history_count,
            "count": len(analyzed),
            "results": analyzed,
            "errors": errors,
            "fundamental_errors": fundamental_errors,
            "us_halt_feed_error": us_halt_error,
            "fundamentals_requested": include_fundamentals,
            "market_regimes": market_regimes,
            "correlation_limit": 0.85,
            "holdings_loaded": holdings_loaded,
            "holdings_count": len(holdings),
            "open_buy_orders_count": len(open_order_symbols),
            "holdings_history_errors": holdings_history_errors,
            "warning": "Ranking-based shortlist only; not a full exchange scan. Fundamental data is attached only to the top selected candidates when providers are configured. Scores are research heuristics, not orders.",
            "execution": "DISABLED",
        }
    except TossNotConfigured as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except TossProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    finally:
        if provider is not None:
            await provider.aclose()


@app.post("/scan/analyze")
def scan_analyze(body: AnalyzeInput, x_api_key: str | None = Header(default=None)):
    """Analyze supplied OHLCV bars and normalized fundamentals in one auditable pass."""
    authorize(x_api_key)
    results = []
    for item in body.items:
        market = item.market.upper()
        if market not in ("KR", "US"):
            raise HTTPException(status_code=422, detail="market must be KR or US")
        features = features_from_bars(item.bars, market)
        snapshot = {**features, **item.fundamentals, "market": market}
        scored = score_snapshot(snapshot)
        results.append({
            "symbol": item.symbol,
            "name": item.name,
            "market": market,
            "features": features,
            **scored,
            "research_only": True,
        })
    results.sort(key=lambda x: (x["score"] is not None, x["score"] or -1), reverse=True)
    return {"count": len(results), "results": results,
            "note": "Analysis only. No broker connection or order execution is performed."}


@app.post("/scan/features")
def scan_features(body: dict, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    market=body.get("market","US")
    snapshots=[]
    for symbol,bars in (body.get("data") or {}).items():
        f=features_from_bars(bars,market)
        snapshots.append({"symbol":symbol,**f})
    return {"count":len(snapshots),"results":snapshots}

@app.post("/scan/rank")
def scan_rank(body: dict, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    rows=body.get("candidates") or []
    ranked=rank_candidates(rows, int(body.get("min_history",200)), int(body.get("top_n",100)))
    return {"candidate_count":len(rows),"qualified_count":len(ranked),"results":ranked,
            "note":"Research ranking only. Not an order instruction."}


@app.post("/backtest/full-universe")
def backtest_full_universe(body: dict, x_api_key: str | None = Header(default=None)):
    """Backtest cached point-in-time whole-exchange daily snapshots (single currency market)."""
    authorize(x_api_key)
    market=body.get("market")
    if market not in ("KR","US"):
        raise HTTPException(status_code=422,detail="market must be KR or US; do not mix currencies")
    try:
        start=date.fromisoformat(body.get("start_date","")); end=date.fromisoformat(body.get("end_date",""))
    except (TypeError,ValueError):
        raise HTTPException(status_code=422,detail="start_date and end_date must be ISO dates")
    if start>end or (end-start).days>550:
        raise HTTPException(status_code=422,detail="date range must be ordered and no longer than 550 days")
    db_path=os.getenv("MARKET_DATA_DB","/data/market_scanner.sqlite3")
    if not os.path.exists(db_path):
        raise HTTPException(status_code=404,detail="No bulk history database found; run full-universe scan first")
    try:
        import sqlite3
        with sqlite3.connect(db_path) as db:
            if market=="KR":
                rows=db.execute("SELECT symbol,day,open,high,low,close,volume FROM bars WHERE exchange IN ('KO','KQ') AND day>=? AND day<=? ORDER BY symbol,day",
                    (start.isoformat(),end.isoformat())).fetchall()
            else:
                rows=db.execute("SELECT symbol,day,open,high,low,close,volume FROM bars WHERE exchange='US' AND day>=? AND day<=? ORDER BY symbol,day",
                    (start.isoformat(),end.isoformat())).fetchall()
        grouped={}
        for symbol,day,op,hi,lo,close,volume in rows:
            grouped.setdefault(symbol,{})[day]={"date":day,"open":op,"high":hi,"low":lo,"close":close,"volume":volume}
        series={k:[v[d] for d in sorted(v)] for k,v in grouped.items()}
        series={k:v for k,v in series.items() if len(v)>=60}
        if not series: raise HTTPException(status_code=404,detail="No sufficient cached market history for the selected period")
        kwargs={k:body[k] for k in ("initial_capital","fee_bps","slippage_bps","score_threshold","min_coverage_pct","max_positions","risk_per_trade_pct","max_position_pct","stop_loss_pct","max_drawdown_stop_pct") if k in body}
        result=backtest_cached_universe(series,market,**kwargs)
        result["date_range"]={"start":start.isoformat(),"end":end.isoformat()}
        result["universe_symbols_with_history"]=len(series)
        result["currency"]="KRW" if market=="KR" else "USD"
        return result
    except (TypeError,ValueError) as exc:
        raise HTTPException(status_code=422,detail=str(exc))


@app.post("/backtest/run")
def backtest_run(body: dict, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    bars = body.get("bars_by_symbol")
    signals = body.get("signals")
    if not isinstance(bars, dict) or not 1 <= len(bars) <= 50:
        raise HTTPException(status_code=422, detail="bars_by_symbol must contain 1 to 50 symbols")
    if not isinstance(signals, list) or len(signals) > 10000:
        raise HTTPException(status_code=422, detail="signals must be a list of at most 10000 entries")
    if any(not isinstance(rows, list) or len(rows) > 5000 for rows in bars.values()):
        raise HTTPException(status_code=422, detail="each symbol may contain at most 5000 bars")
    allowed = {
        "initial_capital", "score_threshold", "min_coverage_pct", "max_positions",
        "risk_per_trade_pct", "max_position_pct", "stop_loss_pct", "fee_bps",
        "slippage_bps", "max_drawdown_stop_pct", "max_holding_sessions",
    }
    kwargs = {k: body[k] for k in allowed if k in body}
    try:
        return run_backtest(bars, signals, **kwargs)
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@app.post("/risk/drawdown-state")
def risk_drawdown(body: dict, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    try:
        return drawdown_state(float(body["drawdown_pct"]))
    except (KeyError,TypeError,ValueError) as exc:
        raise HTTPException(status_code=422,detail=str(exc))

@app.post("/risk/position-size")
def risk_position_size(body: dict, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    try:
        allowed={"account_value","entry","stop","available_cash","current_position_value",
                 "sector_exposure","country_exposure","drawdown_pct",
                 "cost_buffer_pct","gap_buffer_pct"}
        args={k:float(v) for k,v in body.items() if k in allowed}
        required={"account_value","entry","stop","available_cash"}
        if not required.issubset(args): raise ValueError("Required: account_value, entry, stop, available_cash")
        return size_position(**args)
    except (TypeError,ValueError) as exc:
        raise HTTPException(status_code=422,detail=str(exc))

@app.post("/risk/portfolio-exposure")
def risk_portfolio(body: dict, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    try:
        return portfolio_exposure(body.get("positions",[]),float(body["account_value"]))
    except (KeyError,TypeError,ValueError) as exc:
        raise HTTPException(status_code=422,detail=str(exc))


@app.post("/scan/market-regime")
def scan_market_regime(body: dict, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    return market_regime(body.get("bars", []))

@app.post("/scan/correlation")
def scan_correlation(body: dict, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    return correlation_matrix(body.get("series", {}), int(body.get("min_overlap", 30)))

@app.post("/scan/decisions")
def scan_decisions(body: dict, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    return {"count": len(body.get("candidates", [])),
            "results": decide_candidates(body.get("candidates", []), body.get("regime", {}),
                                          body.get("holdings", []), int(body.get("max_candidates", 5)),
                                          body.get("correlations", {}), float(body.get("correlation_limit", .85))),
            "execution": "DISABLED",
            "note": "BUY_CANDIDATE is a research shortlist only. User approval and separate order safety controls are mandatory."}


@app.get("/fundamentals/us/{ticker}")
async def us_fundamentals(ticker: str, as_of: str | None = None,
                          x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    if as_of:
        try:
            datetime.strptime(as_of,"%Y-%m-%d")
        except ValueError:
            raise HTTPException(status_code=422,detail="as_of must be YYYY-MM-DD")
    try:
        return await fetch_sec_fundamentals(ticker,as_of)
    except SecNotConfigured as exc:
        raise HTTPException(status_code=503,detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422,detail=str(exc))
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502,detail=f"SEC response error: HTTP {exc.response.status_code}")

@app.post("/fundamentals/us/normalize")
def normalize_sec_fundamentals(body: dict, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    try:
        return extract_us_fundamentals(body["companyfacts"],body.get("as_of"))
    except (KeyError,ValueError) as exc:
        raise HTTPException(status_code=422,detail=str(exc))

@app.get("/fundamentals/kr/{stock_code}")
async def kr_fundamentals(stock_code: str, bsns_year: int | None = None, fs_div: str = "CFS",
                          x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    try:
        return await fetch_kr_fundamentals(stock_code,bsns_year,fs_div)
    except DartNotConfigured as exc:
        raise HTTPException(status_code=503,detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422,detail=str(exc))
    except DartProviderError as exc:
        raise HTTPException(status_code=502,detail=str(exc))
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502,detail=f"OpenDART request failed: {exc}")


@app.get("/integrations/status")
def integrations_status(x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    return {"krx_configured": bool(os.getenv("KRX_AUTH_KEY")),
            "toss_configured": bool(os.getenv("TOSS_CLIENT_ID") and os.getenv("TOSS_CLIENT_SECRET")),
            "market_price_provider": "EODAPI_CONFIGURED" if os.getenv("EODAPI_TOKEN") else "NOT_CONFIGURED",
            "eodhd_etf_provider": "EODHD_CONFIGURED" if os.getenv("EODHD_API_TOKEN") else "NOT_CONFIGURED",
            "eodhd_bulk_provider": "EODHD_BULK_CONFIGURED" if os.getenv("EODHD_API_TOKEN") and configured_bulk_budget()>0 else "DISABLED",
            "us_fundamentals_provider": "SEC_CONFIGURED" if os.getenv("SEC_USER_AGENT") else "NOT_CONFIGURED",
            "kr_fundamentals_provider": "DART_CONFIGURED" if os.getenv("DART_API_KEY") else "NOT_CONFIGURED",
            "order_execution": "DISABLED",
            "reason": "Market data provider and safe order workflow must be validated before enabling trading."}
