"""Persistent EODHD whole-exchange historical snapshots.

The bulk endpoint is billed at 100 API-call units per exchange/day request.
This adapter refuses to run unless an explicit server-side budget is configured.
"""
from __future__ import annotations
import csv, io, os, sqlite3, time
from datetime import date, timedelta
from pathlib import Path
from typing import Any
import httpx

BASE = "https://eodhd.com/api/eod-bulk-last-day"
ALLOWED_EXCHANGES = {"US", "KO", "KQ"}
CALL_UNITS_PER_DAY = 100

class BulkMarketNotConfigured(RuntimeError): pass
class BulkMarketBudgetError(RuntimeError): pass
class BulkMarketProviderError(RuntimeError): pass

def parse_bulk_csv(payload: str, requested_date: str) -> tuple[str, list[dict]]:
    reader = csv.DictReader(io.StringIO(payload))
    if not reader.fieldnames:
        raise BulkMarketProviderError("Bulk EOD response has no CSV header")
    aliases = {x.lower().strip(): x for x in reader.fieldnames}
    def get(row, *names):
        for name in names:
            key = aliases.get(name.lower())
            if key is not None and row.get(key) not in (None, ""):
                return row[key]
        return None
    rows=[]; actual_date=requested_date
    for row in reader:
        symbol=get(row,"code","symbol","ticker")
        day=get(row,"date") or requested_date
        if not symbol: continue
        try:
            close=float(get(row,"adjusted_close","adjustedClose","close"))
            raw_close=float(get(row,"close"))
            op=float(get(row,"open")); hi=float(get(row,"high")); lo=float(get(row,"low"))
            volume=float(get(row,"volume") or 0)
        except (TypeError,ValueError):
            continue
        if min(close,raw_close,op,hi,lo)<=0 or hi<max(op,lo,raw_close) or lo>min(op,hi,raw_close):
            continue
        factor=close/raw_close if raw_close else 1.0
        bar={"symbol":str(symbol).strip().upper(),"date":str(day)[:10],
             "open":op*factor,"high":hi*factor,"low":lo*factor,
             "close":close,"volume":volume}
        if len(bar["date"])!=10: continue
        actual_date=bar["date"]; rows.append(bar)
    return actual_date, rows

class BulkMarketStore:
    def __init__(self, db_path: str | None = None, token: str | None = None,
                 client: httpx.AsyncClient | None = None):
        self.db_path=db_path or os.getenv("MARKET_DATA_DB","/data/market_scanner.sqlite3")
        self.token=token or os.getenv("EODHD_API_TOKEN")
        self.client=client
        self._own_client=False
        self._calendar_cache={}
        if not self.token: raise BulkMarketNotConfigured("EODHD_API_TOKEN is required for full-universe bulk history")
        Path(self.db_path).parent.mkdir(parents=True,exist_ok=True)
        with sqlite3.connect(self.db_path) as db:
            db.execute("CREATE TABLE IF NOT EXISTS bars(exchange TEXT NOT NULL,symbol TEXT NOT NULL,day TEXT NOT NULL,open REAL,high REAL,low REAL,close REAL,volume REAL,PRIMARY KEY(exchange,symbol,day))")
            db.execute("CREATE INDEX IF NOT EXISTS idx_bars_exchange_day ON bars(exchange,day)")
            db.execute("CREATE TABLE IF NOT EXISTS snapshots(exchange TEXT NOT NULL,day TEXT NOT NULL,row_count INTEGER NOT NULL,stored_at REAL NOT NULL,PRIMARY KEY(exchange,day))")

    async def _session(self):
        if self.client is None:
            self.client=httpx.AsyncClient(timeout=60,headers={"User-Agent":"MarketScanner/2.0 bulk EOD client"})
            self._own_client=True
        return self.client

    async def close(self):
        if self._own_client and self.client is not None:
            await self.client.aclose(); self.client=None; self._own_client=False

    def cached(self, exchange: str, day: str) -> bool:
        with sqlite3.connect(self.db_path) as db:
            return db.execute("SELECT 1 FROM snapshots WHERE exchange=? AND day=?",(exchange,day)).fetchone() is not None

    async def fetch_day(self, exchange: str, day: str) -> dict:
        exchange=exchange.upper()
        if exchange not in ALLOWED_EXCHANGES: raise ValueError("exchange must be US or KO")
        session=await self._session()
        try:
            response=await session.get(f"{BASE}/{exchange}",params={"api_token":self.token,"date":day,"fmt":"csv"})
            if response.status_code in (401,403,429): raise BulkMarketProviderError(f"EODHD bulk request rejected: HTTP {response.status_code}")
            response.raise_for_status()
            actual,rows=parse_bulk_csv(response.text,day)
            if not rows: raise BulkMarketProviderError(f"No usable EOD rows for {exchange} {day}")
            with sqlite3.connect(self.db_path) as db:
                db.executemany("INSERT OR REPLACE INTO bars VALUES(?,?,?,?,?,?,?,?)",[
                    (exchange,r["symbol"],r["date"],r["open"],r["high"],r["low"],r["close"],r["volume"]) for r in rows
                ])
                db.execute("INSERT OR REPLACE INTO snapshots VALUES(?,?,?,?)",(exchange,day,len(rows),time.time()))
                db.execute("INSERT OR REPLACE INTO snapshots VALUES(?,?,?,?)",(exchange,actual,len(rows),time.time()))
            return {"requested_date":day,"actual_date":actual,"rows":len(rows),"call_units":CALL_UNITS_PER_DAY}
        except httpx.HTTPError as exc: raise BulkMarketProviderError(f"EODHD bulk request failed: {exc}") from exc

    async def refresh(self, exchange: str, start: date, end: date, call_unit_budget: int) -> dict:
        if start>end: raise ValueError("start must be <= end")
        if call_unit_budget<0: raise ValueError("call_unit_budget cannot be negative")
        holidays=await self.exchange_holidays(exchange,start,end)
        dates=[]; cursor=start
        while cursor<=end:
            if cursor.weekday()<5 and cursor.isoformat() not in holidays: dates.append(cursor)
            cursor+=timedelta(days=1)
        missing=[d.isoformat() for d in dates if not self.cached(exchange,d.isoformat())]
        estimated=len(missing)*CALL_UNITS_PER_DAY
        if estimated>call_unit_budget:
            raise BulkMarketBudgetError(
                f"Refresh requires {estimated} API call units ({len(missing)} weekdays x 100); configured budget is {call_unit_budget}."
            )
        fetched=[]
        for day in missing:
            try: fetched.append(await self.fetch_day(exchange,day))
            except BulkMarketProviderError:
                # Holidays return prior session data or empty payload; do not silently mark missing data complete.
                raise
        return {"exchange":exchange,"requested_weekdays":len(dates),"new_snapshots":len(fetched),
                "api_call_units_used":estimated,"fetched_rows":sum(x["rows"] for x in fetched),
                "date_start":start.isoformat(),"date_end":end.isoformat()}

    async def exchange_holidays(self, exchange: str, start: date, end: date) -> set[str]:
        exchange=exchange.upper()
        if exchange not in ALLOWED_EXCHANGES: raise ValueError("exchange must be US or KO")
        cache_key=(exchange,start.isoformat(),end.isoformat())
        if cache_key in self._calendar_cache: return self._calendar_cache[cache_key]
        session=await self._session()
        try:
            response=await session.get(f"https://eodhd.com/api/exchange-details/{exchange}",
                params={"api_token":self.token,"from":start.isoformat(),"to":end.isoformat()})
            if response.status_code in (401,403,429): raise BulkMarketProviderError(f"EODHD exchange calendar rejected: HTTP {response.status_code}")
            response.raise_for_status(); payload=response.json()
            holidays=payload.get("ExchangeHolidays",{}) if isinstance(payload,dict) else {}
            result=set()
            values=holidays.values() if isinstance(holidays,dict) else holidays if isinstance(holidays,list) else []
            for item in values:
                if not isinstance(item,dict): continue
                day=str(item.get("Date") or item.get("date") or "")[:10]
                kind=str(item.get("Type") or item.get("type") or "").lower()
                # Early-close sessions remain trading sessions; Official/Bank holidays do not.
                if day and kind in ("official","bank","holiday"):
                    result.add(day)
            self._calendar_cache[cache_key]=result
            return result
        except (httpx.HTTPError,ValueError) as exc: raise BulkMarketProviderError(f"EODHD exchange calendar failed: {exc}") from exc

    async def exchange_symbols(self, exchange: str) -> dict[str, dict]:
        exchange=exchange.upper()
        if exchange not in ALLOWED_EXCHANGES: raise ValueError("exchange must be US or KO")
        session=await self._session()
        try:
            response=await session.get(f"https://eodhd.com/api/exchange-symbol-list/{exchange}",
                                       params={"api_token":self.token,"delisted":"0"})
            if response.status_code in (401,403,429): raise BulkMarketProviderError(f"EODHD symbol master rejected: HTTP {response.status_code}")
            response.raise_for_status(); payload=response.json()
            if not isinstance(payload,list): raise BulkMarketProviderError("Unexpected EODHD symbol master response")
            return {str(x.get("Code") or "").upper():x for x in payload if x.get("Code")}
        except (httpx.HTTPError,ValueError) as exc: raise BulkMarketProviderError(f"EODHD symbol master failed: {exc}") from exc

    def load_series(self, exchange: str, start: date, end: date, min_observations: int=200) -> dict[str,list[dict]]:
        with sqlite3.connect(self.db_path) as db:
            if exchange.upper()=="KR":
                rows=db.execute("SELECT symbol,day,open,high,low,close,volume FROM bars WHERE exchange IN ('KO','KQ') AND day>=? AND day<=? ORDER BY symbol,day",
                                (start.isoformat(),end.isoformat())).fetchall()
            else:
                rows=db.execute("SELECT symbol,day,open,high,low,close,volume FROM bars WHERE exchange=? AND day>=? AND day<=? ORDER BY symbol,day",
                                (exchange.upper(),start.isoformat(),end.isoformat())).fetchall()
        grouped={}
        for symbol,day,op,hi,lo,close,volume in rows:
            grouped.setdefault(symbol,{})[day]={"date":day,"open":op,"high":hi,"low":lo,"close":close,"volume":volume}
        result={symbol:[bars[day] for day in sorted(bars)] for symbol,bars in grouped.items()}
        return {symbol:bars for symbol,bars in result.items() if len(bars)>=min_observations}
