"""Exchange universe collectors. No market-price assumptions are made here."""
from __future__ import annotations
import csv
import io
from dataclasses import dataclass, asdict
from typing import Iterable
import httpx

NASDAQ_LISTED = "https://www.nasdaqtrader.com/dynamic/SymDir/nasdaqlisted.txt"
OTHER_LISTED = "https://www.nasdaqtrader.com/dynamic/SymDir/otherlisted.txt"

@dataclass
class Security:
    symbol: str
    name: str
    market: str
    security_type: str
    exchange: str = ""
    is_etf: bool = False

def _rows(payload: str) -> list[dict[str, str]]:
    lines = [line for line in payload.splitlines() if line.strip()]
    if not lines:
        return []
    # Nasdaq files are pipe-delimited; final metadata row is not a security.
    reader = csv.DictReader(io.StringIO("\n".join(lines)), delimiter="|")
    return [dict(row) for row in reader if row.get("Symbol") and "File Creation Time" not in row.get("Symbol", "")]

async def fetch_us_universe(client: httpx.AsyncClient | None = None, include_etfs: bool = True) -> list[Security]:
    own = client is None
    client = client or httpx.AsyncClient(timeout=30, headers={"User-Agent": "MarketScanner/2.0 contact: admin"})
    try:
        responses = await client.get(NASDAQ_LISTED), await client.get(OTHER_LISTED)
        for response in responses:
            response.raise_for_status()
        result: dict[str, Security] = {}
        for market, response in zip(("NASDAQ", "OTHER"), responses):
            for row in _rows(response.text):
                symbol = (row.get("Symbol") or row.get("ACT Symbol") or "").strip()
                name = (row.get("Security Name") or "").strip()
                test = (row.get("Test Issue") or "").strip().upper() == "Y"
                etf = (row.get("ETF") or "").strip().upper() == "Y"
                if not symbol or test or (etf and not include_etfs):
                    continue
                if any(ch in symbol for ch in ("^", "$")):
                    continue
                exchange = (row.get("Market Category") or row.get("Exchange") or "").strip()
                result[symbol] = Security(symbol, name, market, "ETF" if etf else "LISTED_SECURITY", exchange, etf)
        return sorted(result.values(), key=lambda x: x.symbol)
    finally:
        if own:
            await client.aclose()

def parse_krx_rows(rows: Iterable[dict], market: str) -> list[Security]:
    """Normalize KRX OutBlock_1 rows from approved KRX Open API responses."""
    out = []
    for row in rows:
        symbol = str(row.get("ISU_SRT_CD") or row.get("ISU_CD") or "").strip()
        name = str(row.get("ISU_ABBRV") or row.get("ISU_NM") or "").strip()
        if not symbol or not name:
            continue
        out.append(Security(symbol, name, market, str(row.get("SECUGRP_NM") or "LISTED_SECURITY")))
    return out
