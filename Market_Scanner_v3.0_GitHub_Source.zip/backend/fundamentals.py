"""SEC EDGAR company-facts adapter with filing-date point-in-time controls."""
from __future__ import annotations
import os, re, time
from datetime import date
from typing import Any
import httpx

SEC_TICKERS="https://www.sec.gov/files/company_tickers.json"
SEC_FACTS="https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json"

class SecNotConfigured(RuntimeError): pass
class SecProviderError(RuntimeError): pass

_SEC_TICKER_CACHE: dict | None = None
_SEC_TICKER_CACHE_AT = 0.0
_SEC_TICKER_CACHE_TTL = 24 * 60 * 60


async def _sec_ticker_directory(client: httpx.AsyncClient) -> dict:
    """Cache SEC's company ticker directory for 24 hours per process."""
    global _SEC_TICKER_CACHE, _SEC_TICKER_CACHE_AT
    now = time.monotonic()
    if _SEC_TICKER_CACHE is not None and now - _SEC_TICKER_CACHE_AT < _SEC_TICKER_CACHE_TTL:
        return _SEC_TICKER_CACHE
    response = await client.get(SEC_TICKERS)
    response.raise_for_status()
    _SEC_TICKER_CACHE = response.json()
    _SEC_TICKER_CACHE_AT = now
    return _SEC_TICKER_CACHE

def _units(fact:dict)->list[dict]:
    units=fact.get("units",{})
    # Prefer USD, shares, or pure; callers filter compatible unit by concept.
    for key in ("USD","shares","USD/shares","pure"):
        if key in units: return units[key]
    return next(iter(units.values()),[]) if units else []

def _period_value(fact:dict, as_of:date, forms=("10-K","10-Q"), fy_only=False):
    """Return latest filed value with filing date <= as_of; never use future filings."""
    candidates=[]
    for unit, entries in fact.get("units",{}).items():
        for x in entries:
            try:
                filed=date.fromisoformat(x["filed"])
                end=date.fromisoformat(x["end"])
            except (KeyError,ValueError): continue
            if filed>as_of or x.get("form") not in forms: continue
            if fy_only and x.get("fp")!="FY": continue
            if "val" not in x: continue
            candidates.append((filed,end,x.get("fy",0),x.get("fp",""),float(x["val"]),unit,x.get("form")))
    if not candidates: return None
    # Latest filing then latest period end. A restatement is therefore respected only
    # from the date it became public.
    candidates.sort(key=lambda z:(z[0],z[1]),reverse=True)
    return candidates[0]


def _latest_instant_value(fact: dict | None, cutoff: date):
    """Latest filed instant fact, with the selected period end and unit."""
    if not fact:
        return None
    candidates = []
    for unit, entries in fact.get("units", {}).items():
        for item in entries:
            if item.get("start"):
                continue
            try:
                filed = date.fromisoformat(item["filed"])
                end = date.fromisoformat(item["end"])
                value = float(item["val"])
            except (KeyError, ValueError, TypeError):
                continue
            if filed <= cutoff:
                candidates.append((filed, end, value, unit))
    return max(candidates, key=lambda x: (x[0], x[1])) if candidates else None


def _latest_interest_bearing_debt(facts: dict, cutoff: date):
    """Sum current + non-current debt only when same date and compatible unit."""
    pairs = [
        (["LongTermDebtAndFinanceLeaseObligationsCurrent"],
         ["LongTermDebtAndFinanceLeaseObligationsNoncurrent"]),
        (["LongTermDebtCurrent"], ["LongTermDebtNoncurrent"]),
        (["LongTermDebtAndCapitalLeaseObligationsCurrent"],
         ["LongTermDebtAndCapitalLeaseObligations"]),
    ]
    for current_tags, noncurrent_tags in pairs:
        current_fact = _find_fact(facts, current_tags)
        noncurrent_fact = _find_fact(facts, noncurrent_tags)
        current = _latest_instant_value(current_fact, cutoff)
        noncurrent = _latest_instant_value(noncurrent_fact, cutoff)
        if current and noncurrent and current[1] == noncurrent[1] and current[3] == noncurrent[3]:
            return {"value": current[2] + noncurrent[2], "period_end": current[1],
                    "filed_at": max(current[0], noncurrent[0]), "method": "current_plus_noncurrent"}
    # Fallbacks are explicitly total debt concepts, not current debt alone.
    for tag in ("LongTermDebt", "LongTermDebtAndCapitalLeaseObligations",
                "LongTermDebtAndFinanceLeaseObligations"):
        fact = _find_fact(facts, [tag])
        value = _latest_instant_value(fact, cutoff)
        if value:
            return {"value": value[2], "period_end": value[1],
                    "filed_at": value[0], "method": f"single_tag:{tag}"}
    return None

def _find_fact(facts:dict, tags:list[str]):
    for namespace in ("us-gaap","dei"):
        ns=facts.get(namespace,{})
        for tag in tags:
            if tag in ns: return ns[tag]
    return None

def annual_values(fact, cutoff):
    if not fact: return []
    vals=[]
    for unit,entries in fact.get("units",{}).items():
        for x in entries:
            try:
                filed=date.fromisoformat(x["filed"]); end=date.fromisoformat(x["end"])
                start=date.fromisoformat(x["start"]) if x.get("start") else None
            except (KeyError,ValueError): continue
            if filed>cutoff or x.get("form")!="10-K" or x.get("fp")!="FY" or start is None: continue
            if not 300 <= (end-start).days <= 400: continue
            vals.append((int(x.get("fy",end.year)),filed,end,float(x["val"])))
    by_year={}
    for item in vals:
        if item[0] not in by_year or item[1]>by_year[item[0]][1]: by_year[item[0]]=item
    return [by_year[y] for y in sorted(by_year)]


def quarterly_values(fact:dict|None, cutoff:date)->list[dict]:
    """Normalize SEC duration facts into discrete fiscal quarters, as known by cutoff.

    Prefer directly reported 10-Q/10-K quarter durations. Where only year-to-date
    durations are available, derive Q2/Q3 by subtracting the prior YTD period and
    derive Q4 from FY less Q3 YTD. All inputs are filing-date filtered.
    """
    if not fact: return []
    records=[]
    for unit, entries in fact.get("units",{}).items():
        for x in entries:
            if x.get("form") not in ("10-Q","10-K") or "start" not in x or "end" not in x or "val" not in x:
                continue
            try:
                filed=date.fromisoformat(x["filed"]); start=date.fromisoformat(x["start"]); end=date.fromisoformat(x["end"])
                value=float(x["val"])
            except (KeyError,ValueError,TypeError):
                continue
            if filed>cutoff: continue
            days=(end-start).days+1
            fp=x.get("fp") or ""
            fy=int(x.get("fy") or end.year)
            if 65<=days<=115: kind="Q"
            elif 145<=days<=205: kind="H1"
            elif 225<=days<=315: kind="Q3YTD"
            elif 330<=days<=400: kind="FY"
            else: continue
            records.append({"fy":fy,"fp":fp,"kind":kind,"filed":filed,"start":start,"end":end,"value":value,"unit":unit})
    # Latest publicly filed version of each fiscal-period bucket.
    selected={}
    for r in records:
        key=(r["fy"],r["fp"],r["kind"])
        if key not in selected or r["filed"]>selected[key]["filed"]:
            selected[key]=r
    years=sorted({r["fy"] for r in records})
    quarters=[]
    for fy in years:
        year_rows=[r for r in selected.values() if r["fy"]==fy]
        def pick(fp,kind):
            matches=[r for r in year_rows if r["fp"]==fp and r["kind"]==kind]
            return max(matches,key=lambda r:r["filed"]) if matches else None
        q1=pick("Q1","Q") or pick("Q1","H1")
        q2_direct=pick("Q2","Q"); h1=pick("Q2","H1")
        q3_direct=pick("Q3","Q"); ytd3=pick("Q3","Q3YTD")
        annual=pick("FY","FY")
        # Q1 discrete amount; for most issuers Q1 YTD is itself a quarter.
        if q1:
            quarters.append({"fiscal_year":fy,"quarter":"Q1","period_end":q1["end"],"filed_at":q1["filed"],"value":q1["value"]})
        # Direct quarterly duration is preferred over derived YTD subtraction.
        if q2_direct:
            quarters.append({"fiscal_year":fy,"quarter":"Q2","period_end":q2_direct["end"],"filed_at":q2_direct["filed"],"value":q2_direct["value"]})
        elif h1 and q1:
            quarters.append({"fiscal_year":fy,"quarter":"Q2","period_end":h1["end"],"filed_at":max(h1["filed"],q1["filed"]),"value":h1["value"]-q1["value"]})
        if q3_direct:
            quarters.append({"fiscal_year":fy,"quarter":"Q3","period_end":q3_direct["end"],"filed_at":q3_direct["filed"],"value":q3_direct["value"]})
        elif ytd3 and h1:
            quarters.append({"fiscal_year":fy,"quarter":"Q3","period_end":ytd3["end"],"filed_at":max(ytd3["filed"],h1["filed"]),"value":ytd3["value"]-h1["value"]})
        if annual and ytd3:
            quarters.append({"fiscal_year":fy,"quarter":"Q4","period_end":annual["end"],"filed_at":max(annual["filed"],ytd3["filed"]),"value":annual["value"]-ytd3["value"]})
    # Remove duplicate period ends and require plausible quarter spacing for TTM use.
    by_end={}
    for q in quarters:
        if q["period_end"] not in by_end or q["filed_at"]>by_end[q["period_end"]]["filed_at"]:
            by_end[q["period_end"]]=q
    return sorted(by_end.values(),key=lambda q:q["period_end"])


def trailing_four_quarters(fact:dict|None, cutoff:date)->dict|None:
    qs=quarterly_values(fact,cutoff)
    if len(qs)<4: return None
    last=qs[-4:]
    ends=[q["period_end"] for q in last]
    if any(not 70 <= (ends[i]-ends[i-1]).days <= 110 for i in range(1,4)):
        return None
    current=sum(q["value"] for q in last)
    prior=None
    if len(qs)>=8:
        prev=qs[-8:-4]
        all_e=[q["period_end"] for q in prev+last]
        if all(70 <= (all_e[i]-all_e[i-1]).days <= 110 for i in range(1,8)):
            prior=sum(q["value"] for q in prev)
    return {"value":current,"prior_value":prior,
            "yoy_pct":round((current/prior-1)*100,2) if prior not in (None,0) else None,
            "period_end":last[-1]["period_end"].isoformat(),
            "quarters":[{"quarter":q["quarter"],"period_end":q["period_end"].isoformat()} for q in last]}


def extract_us_fundamentals(companyfacts:dict, as_of:str|None=None)->dict:
    cutoff=date.fromisoformat(as_of) if as_of else date.today()
    facts=companyfacts.get("facts",{})
    def get(tags):
        f=_find_fact(facts,tags)
        return _period_value(f,cutoff) if f else None
    rev=get(["RevenueFromContractWithCustomerExcludingAssessedTax","Revenues","SalesRevenueNet"])
    op=get(["OperatingIncomeLoss"])
    net=get(["NetIncomeLoss","ProfitLoss"])
    debt_total=_latest_interest_bearing_debt(facts,cutoff)
    equity=get(["StockholdersEquity"])
    assets=get(["Assets"])
    liabilities=get(["Liabilities"])
    cash=get(["NetCashProvidedByUsedInOperatingActivities"])
    capex=get(["PaymentsToAcquirePropertyPlantAndEquipment"])
    def val(x): return x[4] if x else None
    def filed(x): return x[0].isoformat() if x else None
    def period(x): return x[1].isoformat() if x else None
    revenue=val(rev); operating=val(op); net_income=val(net)
    revenue_series=annual_values(_find_fact(facts,["RevenueFromContractWithCustomerExcludingAssessedTax","Revenues","SalesRevenueNet"]),cutoff)
    net_series=annual_values(_find_fact(facts,["NetIncomeLoss","ProfitLoss"]),cutoff)
    def yoy(series):
        if len(series)<2 or series[-2][3]==0: return None
        return round((series[-1][3]/abs(series[-2][3])-1)*100,2)
    debt_v=debt_total["value"] if debt_total else None
    equity_v=val(equity); assets_v=val(assets); liabilities_v=val(liabilities)
    cfo=val(cash); capex_v=val(capex)
    fcf=(cfo-abs(capex_v)) if cfo is not None and capex_v is not None else None
    rev_fact=_find_fact(facts,["RevenueFromContractWithCustomerExcludingAssessedTax","Revenues","SalesRevenueNet"])
    op_fact=_find_fact(facts,["OperatingIncomeLoss"])
    net_fact=_find_fact(facts,["NetIncomeLoss","ProfitLoss"])
    cfo_fact=_find_fact(facts,["NetCashProvidedByUsedInOperatingActivities"])
    capex_fact=_find_fact(facts,["PaymentsToAcquirePropertyPlantAndEquipment"])
    rev_ttm=trailing_four_quarters(rev_fact,cutoff)
    op_ttm=trailing_four_quarters(op_fact,cutoff)
    net_ttm=trailing_four_quarters(net_fact,cutoff)
    cfo_ttm=trailing_four_quarters(cfo_fact,cutoff)
    capex_ttm=trailing_four_quarters(capex_fact,cutoff)
    fcf_ttm=(cfo_ttm["value"]-abs(capex_ttm["value"])) if cfo_ttm and capex_ttm else None
    return {
      "source":"SEC EDGAR CompanyFacts","as_of":cutoff.isoformat(),
      "revenue_latest":revenue,"revenue_period_end":period(rev),"revenue_filed_at":filed(rev),
      "revenue_yoy_pct_fy":yoy(revenue_series),
      "revenue_fy_observations":[{"fiscal_year":x[0],"filed_at":x[1].isoformat(),"period_end":x[2].isoformat(),"value":x[3]} for x in revenue_series[-3:]],
      "operating_income_latest":operating,"operating_income_filed_at":filed(op),
      "net_income_latest":net_income,"net_income_filed_at":filed(net),
      "net_income_yoy_pct_fy":yoy(net_series),
      "total_liabilities":liabilities_v,
      "stockholders_equity":equity_v,
      "liabilities_to_assets_pct":(liabilities_v/assets_v*100) if liabilities_v is not None and assets_v and assets_v>0 else None,
      "interest_bearing_debt":debt_v,
      "interest_bearing_debt_period_end":debt_total["period_end"].isoformat() if debt_total else None,
      "interest_bearing_debt_method":debt_total["method"] if debt_total else None,
      "debt_to_equity_pct":(debt_v/equity_v*100) if debt_v is not None and equity_v and equity_v>0 else None,
      "debt_to_assets_pct":(debt_v/assets_v*100) if debt_v is not None and assets_v and assets_v>0 else None,
      "roe_pct":(net_ttm["value"]/equity_v*100) if net_ttm and equity_v and equity_v>0 else None,
      "free_cash_flow":fcf,
      "revenue_ttm":rev_ttm["value"] if rev_ttm else None,
      "revenue_ttm_yoy_pct":rev_ttm["yoy_pct"] if rev_ttm else None,
      "operating_income_ttm":op_ttm["value"] if op_ttm else None,
      "operating_income_ttm_yoy_pct":op_ttm["yoy_pct"] if op_ttm else None,
      "net_income_ttm":net_ttm["value"] if net_ttm else None,
      "net_income_ttm_yoy_pct":net_ttm["yoy_pct"] if net_ttm else None,
      "operating_margin_ttm_pct":round(op_ttm["value"]/rev_ttm["value"]*100,2) if op_ttm and rev_ttm and rev_ttm["value"] else None,
      "net_margin_ttm_pct":round(net_ttm["value"]/rev_ttm["value"]*100,2) if net_ttm and rev_ttm and rev_ttm["value"] else None,
      "cfo_ttm":cfo_ttm["value"] if cfo_ttm else None,
      "capex_ttm":capex_ttm["value"] if capex_ttm else None,
      "free_cash_flow_ttm":fcf_ttm,
      "fcf_margin_ttm_pct":round(fcf_ttm/rev_ttm["value"]*100,2) if fcf_ttm is not None and rev_ttm and rev_ttm["value"] else None,
      "ttm_period_end":rev_ttm["period_end"] if rev_ttm else None,
      "ttm_quarters":rev_ttm["quarters"] if rev_ttm else [],
      "data_quality":"PARTIAL" if any(x is None for x in (revenue,operating,net_income,equity_v)) else "AVAILABLE",
      "warning":"TTM is available only when four consecutive quarterly periods can be normalized; issuer-specific XBRL tagging may leave fields unavailable."
    }

async def fetch_sec_fundamentals(ticker:str, as_of:str|None=None)->dict:
    ua=os.getenv("SEC_USER_AGENT")
    if not ua or "example.com" in ua.lower() or "replace-with" in ua.lower():
        raise SecNotConfigured("SEC_USER_AGENT must identify the application and a real monitored contact email")
    ticker=ticker.upper().strip()
    if not re.fullmatch(r"[A-Z0-9.\-]{1,15}",ticker):
        raise ValueError("Invalid US ticker")
    headers={"User-Agent":ua,"Accept-Encoding":"gzip, deflate"}
    async with httpx.AsyncClient(timeout=30,headers=headers) as client:
        mapping=await _sec_ticker_directory(client)
        match=next((v for v in mapping.values() if str(v.get("ticker","")).upper()==ticker),None)
        if not match: raise ValueError("Ticker not found in SEC company ticker directory")
        cik=int(match["cik_str"])
        r=await client.get(SEC_FACTS.format(cik=f"{cik:010d}")); r.raise_for_status()
        payload=r.json()
    result=extract_us_fundamentals(payload,as_of)
    result.update({"ticker":ticker,"company":match.get("title"),"cik":f"{cik:010d}"})
    return result
