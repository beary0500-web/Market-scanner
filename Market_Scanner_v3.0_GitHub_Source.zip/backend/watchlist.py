"""Free-tier EODHD watchlist scanner with a persistent daily call budget."""
from __future__ import annotations
import os, sqlite3
from datetime import date, datetime, timezone
from typing import Any
import httpx
from features import features_from_bars

DB_PATH = os.getenv("MARKET_DATA_DB", "/data/market_scanner.sqlite3")
EOD_URL = "https://eodhd.com/api/eod/{symbol}"
MAX_WATCHLIST = 12
DAILY_CALL_LIMIT = 20
BENCHMARKS = {"SPY.US", "QQQ.US", "IWM.US"}

class WatchlistError(RuntimeError): pass
class WatchlistNotConfigured(WatchlistError): pass
class WatchlistQuotaExceeded(WatchlistError): pass
class WatchlistProviderError(WatchlistError): pass

def _db():
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    c=sqlite3.connect(DB_PATH, timeout=20)
    c.execute("CREATE TABLE IF NOT EXISTS watchlist (symbol TEXT PRIMARY KEY, name TEXT, market TEXT NOT NULL, updated_at TEXT NOT NULL)")
    c.execute("CREATE TABLE IF NOT EXISTS eodhd_daily_usage (usage_date TEXT PRIMARY KEY, calls INTEGER NOT NULL)")
    c.execute("CREATE TABLE IF NOT EXISTS watchlist_bars (symbol TEXT NOT NULL, trade_date TEXT NOT NULL, open REAL, high REAL, low REAL, close REAL, volume REAL, PRIMARY KEY(symbol,trade_date))")
    return c

def get_watchlist():
    with _db() as c:
        rows=c.execute("SELECT symbol,name,market,updated_at FROM watchlist ORDER BY market,symbol").fetchall()
        return [{"symbol":r[0],"name":r[1],"market":r[2],"updated_at":r[3]} for r in rows]

def set_watchlist(items: list[dict[str, Any]]):
    if len(items)>MAX_WATCHLIST: raise ValueError(f"watchlist is limited to {MAX_WATCHLIST} securities")
    normalized=[]; seen=set()
    for x in items:
        symbol=str(x.get("symbol","")).strip().upper()
        market=str(x.get("market","")).strip().upper()
        name=str(x.get("name") or symbol).strip()[:100]
        if not symbol or len(symbol)>32 or market not in ("KR","US") or symbol in seen:
            raise ValueError("each item needs a unique symbol and market KR or US")
        if market=="KR" and not (symbol.endswith(".KO") or symbol.endswith(".KQ")):
            raise ValueError("Korean symbols must use .KO or .KQ suffix")
        if market=="US" and not symbol.endswith(".US"):
            raise ValueError("US symbols must use .US suffix")
        seen.add(symbol); normalized.append((symbol,name,market,datetime.now(timezone.utc).isoformat()))
    with _db() as c:
        c.execute("DELETE FROM watchlist")
        c.executemany("INSERT INTO watchlist VALUES (?,?,?,?)",normalized)
    return get_watchlist()

def usage():
    today=datetime.now(timezone.utc).date().isoformat()
    with _db() as c:
        row=c.execute("SELECT calls FROM eodhd_daily_usage WHERE usage_date=?",(today,)).fetchone()
    return {"date":today,"used":row[0] if row else 0,"limit":DAILY_CALL_LIMIT,"remaining":max(0,DAILY_CALL_LIMIT-(row[0] if row else 0))}

def _reserve_call():
    today=datetime.now(timezone.utc).date().isoformat()
    with _db() as c:
        c.execute("INSERT OR IGNORE INTO eodhd_daily_usage VALUES (?,0)",(today,))
        row=c.execute("SELECT calls FROM eodhd_daily_usage WHERE usage_date=?",(today,)).fetchone()
        if row[0]>=DAILY_CALL_LIMIT: raise WatchlistQuotaExceeded("EODHD free daily call budget exhausted")
        c.execute("UPDATE eodhd_daily_usage SET calls=calls+1 WHERE usage_date=?",(today,))

def _save_bars(symbol, rows):
    with _db() as c:
        c.executemany("INSERT OR REPLACE INTO watchlist_bars VALUES (?,?,?,?,?,?,?)",[(symbol,r["date"],r["open"],r["high"],r["low"],r["close"],r.get("volume",0)) for r in rows])

def _cached_bars(symbol):
    with _db() as c:
        rows=c.execute("SELECT trade_date,open,high,low,close,volume FROM watchlist_bars WHERE symbol=? ORDER BY trade_date",(symbol,)).fetchall()
    return [{"date":r[0],"open":r[1],"high":r[2],"low":r[3],"close":r[4],"volume":r[5]} for r in rows]

async def _fetch_symbol(symbol: str, token: str):
    _reserve_call()
    params={"api_token":token,"fmt":"json","period":"d"}
    async with httpx.AsyncClient(timeout=25) as client:
        try:
            resp=await client.get(EOD_URL.format(symbol=symbol),params=params)
            if resp.status_code in (401,403,402,429): raise WatchlistProviderError(f"EODHD rejected {symbol}: HTTP {resp.status_code}")
            resp.raise_for_status(); payload=resp.json()
        except (httpx.HTTPError,ValueError) as e: raise WatchlistProviderError(f"EODHD request failed for {symbol}: {e}") from e
    if not isinstance(payload,list): raise WatchlistProviderError(f"Unexpected EODHD payload for {symbol}")
    clean=[]
    for r in payload:
        try:
            b={"date":str(r["date"])[:10],"open":float(r["open"]),"high":float(r["high"]),"low":float(r["low"]),"close":float(r.get("adjusted_close") or r["close"]),"volume":float(r.get("volume") or 0)}
            if min(b["open"],b["high"],b["low"],b["close"])>0 and b["high"]>=max(b["open"],b["close"],b["low"]) and b["low"]<=min(b["open"],b["close"],b["high"]): clean.append(b)
        except (KeyError,TypeError,ValueError): continue
    _save_bars(symbol,clean)

async def scan_watchlist():
    token=os.getenv("EODHD_API_TOKEN")
    if not token: raise WatchlistNotConfigured("EODHD_API_TOKEN is not configured")
    items=get_watchlist()
    if not items: raise ValueError("watchlist is empty")
    # 12 user securities + 3 ETF market proxies = 15 calls; 5 calls remain as safety buffer.
    requested=[x["symbol"] for x in items]
    benchmarks=[x for x in sorted(BENCHMARKS) if x not in requested]
    if len(requested)+len(benchmarks)>15: benchmarks=benchmarks[:max(0,15-len(requested))]
    before=usage(); results=[]; errors=[]
    for symbol in requested+benchmarks:
        try:
            await _fetch_symbol(symbol,token)
            bars=_cached_bars(symbol)
            market="US" if symbol.endswith(".US") else "KR"
            features=features_from_bars(bars,market)
            if symbol in requested:
                action="WAIT"
                if features.get("status")=="OK":
                    p=features["price"]; m20=features.get("ma20");m50=features.get("ma50");m200=features.get("ma200")
                    if m20 and m50 and m200 and p>m20>m50>m200 and (features.get("return_3m_pct") or -999)>0: action="BUY_WATCH"
                    elif m50 and p<m50: action="SELL_REVIEW"
                results.append({"symbol":symbol,"name":next(x["name"] for x in items if x["symbol"]==symbol),"market":market,"features":features,"signal":action,"signal_type":"DAILY_CLOSE_TECHNICAL"})
        except WatchlistQuotaExceeded as e:
            errors.append({"symbol":symbol,"error":str(e)}); break
        except WatchlistError as e: errors.append({"symbol":symbol,"error":str(e)})
    after=usage()
    return {"provider":"EODHD_EOD","data_mode":"END_OF_DAY","watchlist_count":len(items),"results":results,"errors":errors,"usage_before":before,"usage_after":after,"benchmarks_requested":benchmarks,"note":"Signals are technical watch alerts, not orders or guaranteed entry/exit instructions. Prices are end-of-day; intraday trigger monitoring is not included."}
