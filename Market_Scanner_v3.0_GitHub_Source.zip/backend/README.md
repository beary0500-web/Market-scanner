# Market Scanner API — v2.0 development

This is a research backend scaffold. It is not a production trading service.

## Run

```bash
python -m venv .venv
# activate the environment
pip install -r requirements-dev.txt
cp .env.example .env
uvicorn main:app --host 127.0.0.1 --port 8000
```

Interactive API docs are at `/docs`. `/health` is public; protected routes require `X-API-Key` matching the server-side `API_KEY`. The server fails closed when `API_KEY` is absent.

## Implemented routes

- `GET /health`
- `GET /universe/us`
- `GET /universe/kr?bas_dd=YYYYMMDD`
- `GET /market/kr/daily`
- `GET /market/kr/screen`
- `GET /market/kr/etf/daily`
- `GET /market-data/us/trading-halts/{symbol}`
- `GET /market-data/provider-status`
- `POST /market-data/us/daily`
- `GET /market-data/toss/provider-status`
- `GET /market-data/toss/rankings`
- `POST /market-data/toss/daily`
- `POST /market-data/toss/prices`
- `POST /scan/toss-ranked`
- `POST /scan/full-universe`
- `POST /scan/features`
- `POST /scan/rank`
- `POST /scan/score`
- `POST /scan/analyze`
- `POST /backtest/run`
- `POST /backtest/full-universe`
- `POST /scan/market-regime`
- `POST /scan/correlation`
- `POST /scan/decisions`
- `POST /risk/drawdown-state`
- `POST /risk/position-size`
- `POST /risk/portfolio-exposure`
- `GET /fundamentals/us/{ticker}?as_of=YYYY-MM-DD`
- `POST /fundamentals/us/normalize`
- `GET /fundamentals/kr/{stock_code}?bsns_year=YYYY&fs_div=CFS|OFS`
- `GET /integrations/status`

## Toss read-only market data and account context

Read-only account endpoints:
- `GET /toss/accounts` — returns account sequence/type and a masked account number
- `GET /toss/orders?account_seq=...&status=OPEN|CLOSED` — order history only
- `GET /toss/holdings?account_seq=...` — returns the selected account's holdings
- `GET /toss/buying-power?account_seq=...&currency=KRW|USD`
- `GET /toss/commissions?account_seq=...`
- `GET /toss/exchange-rate?base_currency=USD&quote_currency=KRW`
- `GET /toss/portfolio-summary?account_seq=...` — approximate KRW-normalized holdings + cash summary

Account numbers are masked by the backend. `account_seq` is selected from the account list and passed through `X-Tossinvest-Account`. These routes do not create or modify orders.

## Toss read-only market data

The adapter uses the official Client Credentials flow and supports market rankings, batched current prices, adjusted daily candles with `nextBefore` pagination, and KOSPI/KOSDAQ index candles. The token cache is shared within one backend process because Toss issues one valid access token per client and a new token invalidates the previous one. Run a single backend worker unless a cross-worker shared token store is implemented.

- Configure `TOSS_CLIENT_ID` and `TOSS_CLIENT_SECRET` only on the backend.
- Register the backend's static outbound IP in Toss Open API settings. A dynamic mobile or GitHub Actions IP is not suitable.
- `/scan/toss-ranked` screens a ranking-based shortlist (up to 100 symbols per market per request), not the complete exchange listing. Optional SEC/OpenDART enrichment is limited to the top 10 candidates per market per request. If `account_seq` is supplied, existing holdings and open orders are fetched, same-market return correlations are checked, duplicate pending BUY orders are blocked, and 15% max position / 25% sector / 40% country caps are screened. Incomplete sector classification blocks candidates. Korean listings use Toss warning/VI checks; US candidates use the Nasdaq Trader current halt RSS and fail closed if the feed is unavailable; missing held-symbol price histories block candidate decisions.
- Historical candles are adjusted by default. The caller can request raw candles only through the server adapter.
- No Toss account mutation, order creation, modification, or cancellation method is implemented. `order_execution` remains disabled.

Official reference: https://developers.tossinvest.com/docs

## Fundamentals

### US — SEC EDGAR

The adapter caches the SEC company-ticker directory for 24 hours per process and retrieves CompanyFacts, applies a `filed <= as_of` point-in-time cutoff, normalizes discrete quarters from direct quarter durations or YTD/FY differences, and calculates TTM values when four sequential quarters are available. It reports TTM YoY only when eight sequential quarters are available.

Debt ratios use a best-effort interest-bearing debt mapping. Current and non-current tags are summed only when they share the same balance-sheet date and unit; otherwise the adapter returns no paired total rather than combining mismatched facts. Issuer-specific XBRL concepts remain incomplete. ROE uses TTM net income divided by the latest reported equity, not average equity; it remains a proxy.

Set `SEC_USER_AGENT` to a real application identity and monitored contact address; placeholder example.com values are rejected. Respect SEC fair-access policy. `EODHD_API_TOKEN` is separate from `EODAPI_TOKEN` and is used for ETF fundamentals and whole-exchange bulk history.

### KR — OpenDART

The adapter caches the OpenDART corporation-code registry for 24 hours per process and resolves six-digit stock codes through `corpCode.xml` and requests Q1, half-year, Q3, and FY statements for the current and prior two fiscal years to support eight-quarter TTM YoY when filings exist. It retains `thstrm_amount` and `thstrm_add_amount` separately. The TTM helper derives missing discrete quarters from cumulative amounts and Q4 from annual less Q3 YTD. TTM is withheld unless four consecutive quarters are available; YoY requires eight sequential quarters.

Account aliases are best-effort. Consolidated (`CFS`) is the default; `OFS` is optional. Issuer-specific account mapping, fiscal year-end differences, amended filings, and source availability still require live issuer-level validation.

Set `DART_API_KEY` only in server-side secrets. Avoid repeated full registry downloads in high-frequency production use; add a controlled cache before scaling.

## Scoring and selection

`score_snapshot` uses bounded transformations and excludes missing components rather than imputing neutral values. `fundamental_detail` exposes the individual normalized sub-scores. PER/PBR are derived from the latest adjusted daily close, Toss stock-master shares outstanding, TTM net income and latest reported equity when those inputs are available. These transforms are initial heuristics and are not sector-adjusted or backtested; the price/share/equity timestamps may not be perfectly synchronized.

`decide_candidates` returns `BUY_CANDIDATE`, `WATCH`, or `BLOCKED`. `BUY_CANDIDATE` is not an order. Correlation filtering works only when the caller supplies a correctly aligned correlation matrix and current holdings.

## Whole-exchange scan

`POST /scan/full-universe` uses EODHD whole-exchange historical bulk snapshots and the EODHD exchange symbol master for `US`, `KO` (KOSPI) and `KQ` (KOSDAQ). It persists daily OHLCV in SQLite at `MARKET_DATA_DB` (default `/data/market_scanner.sqlite3`) so subsequent scans reuse cached dates. The route builds the full-exchange technical universe, then enriches up to 10 top candidates per market with SEC/OpenDART fundamentals or ETF quality, applies current halt/warning checks, and optionally incorporates the selected account's holdings, open BUY orders, correlation, sector and country caps. Candidates outside the enriched subset are blocked for missing required data. `BUY_CANDIDATE` remains a research gate, not an order.

This endpoint requires `EODHD_API_TOKEN` (separate from `EODAPI_TOKEN`), a paid EODHD plan that includes bulk EOD and exchange-symbol-list endpoints, a persistent `/data` volume, and a positive server-side `EODHD_BULK_CALL_UNITS_PER_RUN`. The budget is split across requested markets. Each exchange/day bulk snapshot consumes 100 API-call units. A year of weekday snapshots is approximately 26,000 units per exchange before cached dates and holidays. Korea scans both KO (KOSPI) and KQ (KOSDAQ), so Korea plus US can require about 78,000 units. The default budget is zero and the endpoint remains disabled until explicitly provisioned.

`POST /backtest/full-universe` generates historical technical signals from the stored daily whole-exchange snapshots, uses only data through each signal close, and delegates next-symbol-session open execution to the backtester. It is technical-only and excludes point-in-time fundamentals, delisting proceeds, taxes, FX, market impact and other real-world frictions.

## Backtesting

`POST /backtest/run` runs a long-only, event-driven daily-bar simulation. Signals are assumed known only after their dated close and execute at the symbol's next available session open. Stops use the stop price or a worse opening gap; configurable fees and slippage are applied. It reports equity curve, total return, CAGR, max drawdown, win rate, exposure, trades and open positions.

The endpoint accepts precomputed dated signals; it does not fabricate historical fundamentals or claim that current fundamentals were available historically. Corporate actions, survivorship/delisting bias, point-in-time universe membership, taxes, market impact and real broker fills still require separate datasets and validation. Backtest results are not evidence of future performance.

## Risk

Position sizing takes the minimum of risk-budget, position, cash, sector, and country limits. Optional `cost_buffer_pct` and `gap_buffer_pct` increase modeled per-share risk. Their defaults are zero because no universal transaction-cost or gap assumption is defensible; production configuration must be calibrated to venue, broker, asset, and order type.

Drawdown thresholds are provisional user-defined guardrails, not optimized risk parameters. Currency conversion, taxes, market impact, partial fills, stop gaps, and portfolio covariance still require additional modeling.

## Remaining production gates

- The Android app exposes ranked scanning, full-universe technical scan, read-only account context and cached full-universe backtest; it does not expose every backend endpoint or a complete trade approval workflow.
- Full-universe OHLCV ingestion is implemented conditionally through EODHD Bulk EOD, but requires a paid subscription, sufficient call quota, EODHD_API_TOKEN and persistent server storage. No live provider integration test has been run in this environment.
- Point-in-time historical fundamentals, issuer-level XBRL/DART reconciliation, sector-neutral factors, delisted-security proceeds, historical exchange halts, taxes, FX costs and market impact are not fully modeled.
- Toss order placement/modification/cancellation and explicit approval workflow remain disabled.
- Static-egress deployment, secret manager, audit trail, durable idempotency, kill switch and broker order-state reconciliation remain external deployment requirements.
- Paper trading and a sufficiently long forward validation period remain mandatory before any real-order capability is considered.

Never put broker credentials in the Android app or repository. Do not enable live orders until all execution controls are implemented and independently tested.

## Free-tier 12-security watchlist mode

`PUT /watchlist` stores up to 12 symbols (US symbols use `.US`; Korean symbols use `.KO` for KOSPI or `.KQ` for KOSDAQ). `GET /watchlist` and `GET /watchlist/usage` expose the saved list and local daily usage. `POST /watchlist/scan` fetches EODHD daily bars once per saved symbol and calculates close-based technical watch signals. It also attempts up to three market proxy ETFs (`SPY.US`, `QQQ.US`, `IWM.US`) while reserving five of the 20 free daily API calls for safety. The local counter is persistent in `MARKET_DATA_DB` and resets by UTC date, matching EODHD's documented midnight-GMT reset. Failed requests can still consume provider quota, so the local counter reserves a call before each request.

This is an on-demand scan endpoint, not a background scheduler or push-notification service. The current release does not send Android push notifications and does not monitor intraday prices. `BUY_WATCH` and `SELL_REVIEW` are daily-close technical review flags, not executable trade instructions. Fundamentals are excluded from this free-tier scan because EODHD Fundamentals requests cost 10 calls and are not included in the free package.
