"""OHLCV feature engineering and staged candidate ranking."""
from __future__ import annotations
from math import sqrt
from statistics import mean, pstdev

def features_from_bars(bars: list[dict], market: str) -> dict:
    bars = sorted(bars, key=lambda b:b["date"])
    closes = [float(b["close"]) for b in bars if b.get("close") and float(b["close"]) > 0]
    if len(closes) < 60:
        return {"status":"INSUFFICIENT_HISTORY","observations":len(closes)}
    last = closes[-1]
    def ret(n):
        return (last/closes[-n-1]-1)*100 if len(closes)>n and closes[-n-1]>0 else None
    ma=lambda n: mean(closes[-n:]) if len(closes)>=n else None
    daily=[closes[i]/closes[i-1]-1 for i in range(1,len(closes)) if closes[i-1]>0]
    vol=pstdev(daily[-60:])*sqrt(252)*100 if len(daily)>=20 else None
    peak=max(closes[-252:]) if closes else last
    dd=(last/peak-1)*100 if peak else None
    turnovers=[]
    for b in bars[-20:]:
        try: turnovers.append(float(b.get("close",0))*float(b.get("volume",0)))
        except (TypeError,ValueError): pass
    return {"status":"OK","observations":len(closes),"price":last,
            "price_as_of":bars[-1].get("date") if bars else None,
            "ma20":ma(20),"ma50":ma(50),
            "ma200":ma(200),"return_3m_pct":ret(63),"return_6m_pct":ret(126),
            "return_12m_pct":ret(252),"volatility_annual_pct":vol,"max_drawdown_pct":dd,
            "avg_daily_turnover":mean(turnovers) if turnovers else None,"market":market}

def rank_candidates(rows: list[dict], min_history: int=200, top_n: int=100) -> list[dict]:
    eligible=[]
    for row in rows:
        if row.get("status") != "OK" or row.get("observations",0)<min_history:
            continue
        if row.get("score") is None or row.get("coverage_pct",0)<50:
            continue
        eligible.append(row)
    eligible.sort(key=lambda r:(r.get("score",0),r.get("avg_daily_turnover",0)),reverse=True)
    return eligible[:top_n]
