"""Read-only Toss Securities market-data adapter.

Broker credentials remain server-side. This module intentionally contains no
account mutation or order-placement methods.
"""
from __future__ import annotations

import os
import time
import asyncio
from datetime import datetime
from typing import Any
from urllib.parse import quote

import httpx


class TossNotConfigured(RuntimeError):
    pass


class TossProviderError(RuntimeError):
    pass


# Toss issues one valid access token per client. Reissuing invalidates the
# previous token, so all requests in one worker must share this cache.
_TOKEN_VALUE: str | None = None
_TOKEN_CLIENT_ID: str | None = None
_TOKEN_EXPIRES_AT = 0.0
_TOKEN_LOCK = asyncio.Lock()


class TossMarketDataProvider:
    BASE_URL = "https://openapi.tossinvest.com"

    def __init__(self, client_id: str | None = None, client_secret: str | None = None,
                 base_url: str | None = None, client: httpx.AsyncClient | None = None):
        self.client_id = client_id or os.getenv("TOSS_CLIENT_ID")
        self.client_secret = client_secret or os.getenv("TOSS_CLIENT_SECRET")
        self.base_url = (base_url or os.getenv("TOSS_BASE_URL") or self.BASE_URL).rstrip("/")
        self._client = client
        self._owns_client = client is None
        if not self.client_id or not self.client_secret:
            raise TossNotConfigured("TOSS_CLIENT_ID and TOSS_CLIENT_SECRET must be configured on the server")

    async def aclose(self):
        if self._owns_client and self._client is not None:
            await self._client.aclose()
            self._client = None

    async def _http(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=30)
        return self._client

    async def _access_token(self, rejected_token: str | None = None) -> str:
        global _TOKEN_VALUE, _TOKEN_CLIENT_ID, _TOKEN_EXPIRES_AT
        async with _TOKEN_LOCK:
            now = time.monotonic()
            same_client = _TOKEN_CLIENT_ID == self.client_id
            if same_client and _TOKEN_VALUE and now < _TOKEN_EXPIRES_AT:
                # Another request may already have refreshed the rejected token.
                if rejected_token is None or _TOKEN_VALUE != rejected_token:
                    return _TOKEN_VALUE
            client = await self._http()
            response = await client.post(
                f"{self.base_url}/oauth2/token",
                data={
                    "grant_type": "client_credentials",
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            if response.status_code == 403:
                raise TossProviderError("Toss API rejected the server IP (403). Check the registered static egress IP.")
            if response.status_code >= 400:
                raise TossProviderError(f"Toss OAuth failed: HTTP {response.status_code}")
            payload = response.json()
            token = payload.get("access_token")
            expires = int(payload.get("expires_in", 86400))
            if not token or expires <= 0:
                raise TossProviderError("Toss OAuth response did not contain a valid access token")
            _TOKEN_VALUE = token
            _TOKEN_CLIENT_ID = self.client_id
            # No refresh token is issued. Renew before expiry.
            _TOKEN_EXPIRES_AT = now + max(60, expires - 300)
            return token

    async def _get(self, path: str, params: dict[str, Any],
                   account_seq: int | None = None, retry_auth: bool = True) -> dict:
        client = await self._http()
        token = await self._access_token()
        headers = {"Authorization": f"Bearer {token}"}
        if account_seq is not None:
            if not isinstance(account_seq, int) or account_seq <= 0:
                raise ValueError("account_seq must be a positive integer")
            headers["X-Tossinvest-Account"] = str(account_seq)
        response = await client.get(
            f"{self.base_url}{path}", params=params, headers=headers,
        )
        if response.status_code == 401 and retry_auth:
            await self._access_token(rejected_token=token)
            return await self._get(path, params, account_seq=account_seq, retry_auth=False)
        if response.status_code == 403:
            raise TossProviderError("Toss API rejected the server IP (403). Check the registered static egress IP.")
        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After", "unknown")
            raise TossProviderError(f"Toss rate limit exceeded (429); Retry-After={retry_after}")
        if response.status_code >= 400:
            raise TossProviderError(f"Toss API request failed: HTTP {response.status_code}")
        payload = response.json()
        if not isinstance(payload, dict) or "result" not in payload:
            raise TossProviderError("Unexpected Toss API response envelope")
        return payload["result"]

    async def prices(self, symbols: list[str]) -> list[dict]:
        clean = [self._validate_symbol(x) for x in symbols]
        if not clean or len(clean) > 200:
            raise ValueError("symbols must contain 1 to 200 symbols")
        result = await self._get("/api/v1/prices", {"symbols": ",".join(clean)})
        if not isinstance(result, list):
            raise TossProviderError("Unexpected Toss prices result")
        return result

    async def warnings(self, symbol: str) -> list[dict]:
        symbol = self._validate_symbol(symbol)
        result = await self._get(f"/api/v1/stocks/{quote(symbol, safe='')}/warnings", {})
        if not isinstance(result, list):
            raise TossProviderError("Unexpected Toss stock warnings result")
        return result

    async def stocks(self, symbols: list[str]) -> list[dict]:
        clean = [self._validate_symbol(x) for x in symbols]
        if not clean or len(clean) > 200:
            raise ValueError("symbols must contain 1 to 200 symbols")
        result = await self._get("/api/v1/stocks", {"symbols": ",".join(clean)})
        if not isinstance(result, list):
            raise TossProviderError("Unexpected Toss stocks result")
        return result

    async def accounts(self) -> list[dict]:
        result = await self._get("/api/v1/accounts", {})
        if not isinstance(result, list):
            raise TossProviderError("Unexpected Toss accounts result")
        return result

    async def orders(self, account_seq: int, status: str = "OPEN") -> dict:
        status = status.upper()
        if status not in ("OPEN", "CLOSED"):
            raise ValueError("status must be OPEN or CLOSED")
        result = await self._get("/api/v1/orders", {"status": status},
                                 account_seq=account_seq)
        if not isinstance(result, dict) or not isinstance(result.get("orders"), list):
            raise TossProviderError("Unexpected Toss orders result")
        return result

    async def holdings(self, account_seq: int, symbol: str | None = None) -> dict:
        params = {"symbol": symbol} if symbol else {}
        result = await self._get("/api/v1/holdings", params, account_seq=account_seq)
        if not isinstance(result, dict):
            raise TossProviderError("Unexpected Toss holdings result")
        return result

    async def buying_power(self, account_seq: int, currency: str) -> dict:
        currency = currency.upper()
        if currency not in ("KRW", "USD"):
            raise ValueError("currency must be KRW or USD")
        result = await self._get("/api/v1/buying-power", {"currency": currency},
                                 account_seq=account_seq)
        if not isinstance(result, dict):
            raise TossProviderError("Unexpected Toss buying power result")
        return result

    async def exchange_rate(self, base_currency: str = "USD",
                            quote_currency: str = "KRW",
                            date_time: str | None = None) -> dict:
        base_currency = base_currency.upper()
        quote_currency = quote_currency.upper()
        if base_currency not in ("KRW", "USD") or quote_currency not in ("KRW", "USD") or base_currency == quote_currency:
            raise ValueError("base_currency and quote_currency must be different values among KRW and USD")
        params = {"baseCurrency": base_currency, "quoteCurrency": quote_currency}
        if date_time:
            params["dateTime"] = date_time
        result = await self._get("/api/v1/exchange-rate", params)
        if not isinstance(result, dict):
            raise TossProviderError("Unexpected Toss exchange-rate result")
        return result

    async def commissions(self, account_seq: int) -> list[dict]:
        result = await self._get("/api/v1/commissions", {}, account_seq=account_seq)
        if not isinstance(result, list):
            raise TossProviderError("Unexpected Toss commissions result")
        return result

    async def rankings(self, market_country: str, duration: str = "1d",
                      count: int = 100, ranking_type: str = "MARKET_TRADING_AMOUNT",
                      exclude_investment_caution: bool = True) -> dict:
        market_country = market_country.upper()
        if market_country not in ("KR", "US"):
            raise ValueError("market_country must be KR or US")
        if duration not in ("realtime", "1d", "1w", "1mo", "3mo", "6mo", "1y"):
            raise ValueError("Unsupported ranking duration")
        allowed_types = {
            "MARKET_TRADING_AMOUNT", "MARKET_TRADING_VOLUME",
            "TOP_GAINERS", "TOP_LOSERS",
            "TOSS_SECURITIES_TRADING_AMOUNT", "TOSS_SECURITIES_TRADING_VOLUME",
        }
        if ranking_type not in allowed_types:
            raise ValueError("Unsupported ranking_type")
        if ranking_type in ("TOP_GAINERS", "TOP_LOSERS") and duration == "realtime":
            raise ValueError("TOP_GAINERS/TOP_LOSERS do not support realtime")
        if not 1 <= count <= 100:
            raise ValueError("count must be between 1 and 100")
        result = await self._get("/api/v1/rankings", {
            "type": ranking_type,
            "marketCountry": market_country,
            "duration": duration,
            "count": count,
            "excludeInvestmentCaution": str(exclude_investment_caution).lower(),
        })
        if not isinstance(result, dict) or not isinstance(result.get("rankings"), list):
            raise TossProviderError("Unexpected Toss rankings result")
        return result

    async def market_indicator_daily_bars(self, symbol: str, count: int = 260) -> list[dict]:
        symbol = str(symbol).strip().upper()
        if symbol not in ("KOSPI", "KOSDAQ"):
            raise ValueError("Only KOSPI and KOSDAQ index daily candles are supported here")
        if not 1 <= count <= 1000:
            raise ValueError("count must be between 1 and 1000")
        bars: dict[str, dict] = {}
        before = None
        while len(bars) < count:
            page_count = min(200, count - len(bars))
            params: dict[str, Any] = {"interval": "1d", "count": page_count}
            if before:
                params["before"] = before
            result = await self._get(f"/api/v1/market-indicators/{symbol}/candles", params)
            if not isinstance(result, dict):
                raise TossProviderError("Unexpected Toss market indicator candles result")
            candles = result.get("candles") or []
            for candle in candles:
                timestamp = str(candle.get("timestamp", ""))
                try:
                    day = datetime.fromisoformat(timestamp.replace("Z", "+00:00")).date().isoformat()
                    bar = {
                        "date": day,
                        "open": float(candle["openPrice"]),
                        "high": float(candle["highPrice"]),
                        "low": float(candle["lowPrice"]),
                        "close": float(candle["closePrice"]),
                        "volume": float(candle.get("volume") or 0),
                    }
                except (KeyError, TypeError, ValueError):
                    continue
                if min(bar["open"], bar["high"], bar["low"], bar["close"]) <= 0:
                    continue
                bars[day] = bar
            next_before = result.get("nextBefore")
            if not next_before or not candles or next_before == before:
                break
            before = next_before
        return sorted(bars.values(), key=lambda x: x["date"])[-count:]

    async def daily_bars(self, symbol: str, count: int = 260,
                         adjusted: bool = True) -> list[dict]:
        symbol = self._validate_symbol(symbol)
        if not 1 <= count <= 1000:
            raise ValueError("count must be between 1 and 1000")
        bars: dict[str, dict] = {}
        before = None
        while len(bars) < count:
            page_count = min(200, count - len(bars))
            params: dict[str, Any] = {
                "symbol": symbol, "interval": "1d",
                "count": page_count, "adjusted": str(adjusted).lower(),
            }
            if before:
                params["before"] = before
            result = await self._get("/api/v1/candles", params)
            if not isinstance(result, dict):
                raise TossProviderError("Unexpected Toss candles result")
            candles = result.get("candles") or []
            for candle in candles:
                timestamp = str(candle.get("timestamp", ""))
                try:
                    day = datetime.fromisoformat(timestamp.replace("Z", "+00:00")).date().isoformat()
                    bar = {
                        "date": day,
                        "open": float(candle["openPrice"]),
                        "high": float(candle["highPrice"]),
                        "low": float(candle["lowPrice"]),
                        "close": float(candle["closePrice"]),
                        "volume": float(candle.get("volume") or 0),
                    }
                except (KeyError, TypeError, ValueError):
                    continue
                if min(bar["open"], bar["high"], bar["low"], bar["close"]) <= 0:
                    continue
                if bar["high"] < max(bar["open"], bar["close"], bar["low"]):
                    continue
                if bar["low"] > min(bar["open"], bar["close"], bar["high"]):
                    continue
                bars[day] = bar
            next_before = result.get("nextBefore")
            if not next_before or not candles or next_before == before:
                break
            before = next_before
        return sorted(bars.values(), key=lambda x: x["date"])[-count:]

    @staticmethod
    def _validate_symbol(symbol: str) -> str:
        value = str(symbol).strip()
        if not value or len(value) > 20 or not all(c.isalnum() or c in ".-" for c in value):
            raise ValueError("Invalid Toss symbol")
        return value
