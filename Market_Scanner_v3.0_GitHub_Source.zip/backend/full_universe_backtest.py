"""Point-in-time technical signal generation from daily whole-exchange snapshots."""
from __future__ import annotations
from datetime import date
from features import features_from_bars
from scoring import score_snapshot
from selection import market_regime
from backtest import run_backtest


def generate_signals(series: dict[str,list[dict]], market: str, min_history: int=200,
                     score_threshold: float=75, min_coverage_pct: float=60) -> tuple[list[dict],dict]:
    from bisect import bisect_right
    if market not in ("KR","US"): raise ValueError("market must be KR or US")
    benchmark="069500" if market=="KR" else "SPY"
    benchmark_bars=sorted(series.get(benchmark,[]),key=lambda x:str(x["date"]))
    benchmark_dates=[str(b["date"])[:10] for b in benchmark_bars]
    dates=sorted({str(b["date"])[:10] for bars in series.values() for b in bars})
    regime_by_day={}; regime_counts={"BULL":0,"BEAR":0,"SIDEWAYS":0,"UNKNOWN":0}
    for day in dates:
        idx=bisect_right(benchmark_dates,day)
        regime=market_regime(benchmark_bars[:idx])
        regime_by_day[day]=regime
        regime_counts[regime["state"]]=regime_counts.get(regime["state"],0)+1
    signals=[]
    for symbol,bars in series.items():
        if symbol==benchmark: continue
        ordered=sorted(bars,key=lambda x:str(x["date"]))
        for index,bar in enumerate(ordered):
            if index+1<min_history: continue
            day=str(bar["date"])[:10]
            regime=regime_by_day.get(day,{"state":"UNKNOWN"})
            if regime["state"] in ("BEAR","UNKNOWN"): continue
            features=features_from_bars(ordered[max(0,index-259):index+1],market)
            scored=score_snapshot({**features,"market":market})
            if (scored.get("score") is None or scored["score"]<score_threshold
                or scored.get("coverage_pct",0)<min_coverage_pct
                or features.get("status")!="OK"
                or (features.get("price") or 0)<(features.get("ma200") or float("inf"))
                or (features.get("volatility_annual_pct") or 999)>60):
                continue
            signals.append({"date":day,"symbol":symbol,"score":scored["score"],
                            "coverage_pct":scored["coverage_pct"]})
    return signals,{"benchmark":benchmark,"regime_day_counts":regime_counts,
                    "signals_generated":len(signals),
                    "signal_logic":"technical-only score, price above MA200, volatility <=60%, non-BEAR regime",
                    "lookahead_control":"each signal uses only bars dated on or before signal close; execution is delegated to next-symbol-session backtester"}


def backtest_cached_universe(series:dict[str,list[dict]],market:str,initial_capital:float=6_000_000,
                              fee_bps:float=0,slippage_bps:float=5,score_threshold:float=75,
                              min_coverage_pct:float=60,max_positions:int=5,
                              risk_per_trade_pct:float=.005,max_position_pct:float=.15,
                              stop_loss_pct:float=.08,max_drawdown_stop_pct:float=-10)->dict:
    signals,metadata=generate_signals(series,market,score_threshold=score_threshold,
                                       min_coverage_pct=min_coverage_pct)
    result=run_backtest(series,signals,initial_capital=initial_capital,
        score_threshold=score_threshold,min_coverage_pct=min_coverage_pct,
        max_positions=max_positions,risk_per_trade_pct=risk_per_trade_pct,
        max_position_pct=max_position_pct,stop_loss_pct=stop_loss_pct,
        fee_bps=fee_bps,slippage_bps=slippage_bps,
        max_drawdown_stop_pct=max_drawdown_stop_pct)
    return {**result,"market":market,"signal_metadata":metadata,
            "warning":"Technical-only research backtest. Historical whole-exchange membership is approximated by the symbols present in the provider's daily bulk snapshots. No point-in-time fundamentals, sector neutralization, taxes, FX conversion, borrow costs, market impact or delisting proceeds are included. Results are not evidence of future returns."}
