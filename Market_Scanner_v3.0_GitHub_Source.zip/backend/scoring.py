"""Transparent technical and fundamental scoring.

Missing inputs reduce coverage; they are never imputed as neutral. Fundamental
subscores use bounded transforms so extreme accounting values cannot dominate.
"""
from __future__ import annotations
from math import isfinite

WEIGHTS = {"trend": .25, "momentum": .25, "risk": .15, "liquidity": .10,
           "fundamentals": .20, "valuation": .05}


def _bounded(x: float) -> float:
    return max(0.0, min(100.0, x))


def _number(d: dict, *keys):
    for key in keys:
        value = d.get(key)
        if isinstance(value, (int, float)) and isfinite(value):
            return float(value)
    return None


def _growth_score(value: float) -> float:
    # -100% growth maps to 0, +100% or more maps to 100.
    return _bounded(50.0 + value / 2.0)


def _roe_score(value: float) -> float:
    # A bounded quality proxy, not a sector-adjusted valuation.
    return _bounded(50.0 + value * 1.25)


def _margin_score(value: float) -> float:
    # Operating/net margin: -20% -> 0, +20% -> 100.
    return _bounded(50.0 + value * 2.5)


def _leverage_score(value: float) -> float:
    # Debt/assets: 0% -> 100, 80%+ -> 0.
    return _bounded(100.0 - value * 1.25)


def _cashflow_score(value: float) -> float:
    # FCF margin: -20% -> 0, +20% -> 100.
    return _bounded(50.0 + value * 2.5)


def fundamental_subscore(d: dict) -> tuple[float | None, dict]:
    """Build a comparable but deliberately simple fundamental quality score.

    Accepted aliases allow SEC/DART normalized outputs to feed the same engine.
    Sector effects, accounting-policy differences and one-off adjustments are
    not modeled; callers must retain the component-level audit trail.
    """
    metrics = {}
    revenue_growth = _number(d, "sales_growth_pct", "revenue_ttm_yoy_pct")
    earnings_growth = _number(d, "earnings_growth_pct", "net_income_ttm_yoy_pct")
    roe = _number(d, "roe_pct", "roe_ttm_pct")
    op_margin = _number(d, "operating_margin_ttm_pct", "operating_margin_pct")
    net_margin = _number(d, "net_margin_ttm_pct", "net_margin_pct")
    debt_assets = _number(d, "liabilities_to_assets_pct", "debt_to_assets_pct", "debt_ratio_pct")
    fcf_margin = _number(d, "fcf_margin_ttm_pct", "free_cash_flow_margin_pct")

    candidates = [
        ("revenue_growth", revenue_growth, _growth_score, .20),
        ("earnings_growth", earnings_growth, _growth_score, .20),
        ("roe", roe, _roe_score, .15),
        ("operating_margin", op_margin, _margin_score, .15),
        ("net_margin", net_margin, _margin_score, .10),
        ("leverage", debt_assets, _leverage_score, .10),
        ("free_cash_flow_margin", fcf_margin, _cashflow_score, .10),
    ]
    weighted = [(name, fn(value), weight) for name, value, fn, weight in candidates
                if value is not None]
    for name, score, _ in weighted:
        metrics[name] = round(score, 2)
    if not weighted:
        return None, metrics
    result = sum(score * weight for _, score, weight in weighted) / sum(
        weight for _, _, weight in weighted
    )
    return round(result, 2), metrics


def score_snapshot(d: dict) -> dict:
    parts: dict[str, float] = {}

    def put(key, value):
        if value is not None and isinstance(value, (int, float)) and isfinite(value):
            parts[key] = _bounded(float(value))

    price, ma20, ma50, ma200 = (d.get(k) for k in ("price", "ma20", "ma50", "ma200"))
    if all(isinstance(x, (int, float)) and x > 0 for x in (price, ma20, ma50, ma200)):
        put("trend", 100 * sum((price > ma20, ma20 > ma50, ma50 > ma200)) / 3)

    returns = [d.get(k) for k in ("return_3m_pct", "return_6m_pct", "return_12m_pct")]
    valid = [(v, w) for v, w in zip(returns, (.35, .25, .15))
             if isinstance(v, (int, float)) and isfinite(v)]
    if valid:
        denom = sum(w for _, w in valid)
        put("momentum", sum(_bounded(50 + v) * w for v, w in valid) / denom)

    vol, dd = d.get("volatility_annual_pct"), d.get("max_drawdown_pct")
    if (isinstance(vol, (int, float)) and isfinite(vol)
            and isinstance(dd, (int, float)) and isfinite(dd)):
        put("risk", 100 - vol * 1.2 - abs(dd) * 1.5)

    turnover = d.get("avg_daily_turnover")
    if isinstance(turnover, (int, float)) and isfinite(turnover) and turnover > 0:
        import math
        threshold = 1_000_000_000 if d.get("market") == "KR" else 1_000_000
        put("liquidity", 50 + 50 * math.log10(max(.01, turnover / threshold)))

    fundamentals, fundamental_metrics = fundamental_subscore(d)
    if d.get("instrument_type") == "ETF":
        fundamentals = _number(d, "etf_quality_score")
        fundamental_metrics = {"etf_quality": fundamentals} if fundamentals is not None else {}
    put("fundamentals", fundamentals)

    valuation_scores = []
    per = _number(d, "per")
    pbr = _number(d, "pbr")
    if per is not None and per > 0:
        valuation_scores.append(_bounded(100 - (per - 5) * 2.2))
    if pbr is not None and pbr > 0:
        valuation_scores.append(_bounded(100 - (pbr - 1) * 20))
    if valuation_scores:
        put("valuation", sum(valuation_scores) / len(valuation_scores))

    used = sum(WEIGHTS[k] for k in parts)
    total = sum(parts[k] * WEIGHTS[k] for k in parts) / used if used else None
    return {"score": round(total, 2) if total is not None else None,
            "coverage_pct": round(used * 100, 1),
            "components": {k: round(parts[k], 2) if k in parts else None for k in WEIGHTS},
            "fundamental_detail": fundamental_metrics,
            "status": "PARTIAL" if used < 1 else "COMPLETE"}
