"""Market regime, cross-asset correlation and explainable candidate decisions."""
from __future__ import annotations
from math import sqrt
from statistics import mean, pstdev

def market_regime(bars: list[dict]) -> dict:
    ordered=sorted(bars,key=lambda x:x["date"])
    closes=[float(x["close"]) for x in ordered if x.get("close") and float(x["close"])>0]
    if len(closes)<200:
        return {"state":"UNKNOWN","confidence":"LOW","reason":"200거래일 이상의 벤치마크 데이터가 필요"}
    last=closes[-1]; ma50=mean(closes[-50:]); ma200=mean(closes[-200:])
    ret63=(last/closes[-64]-1)*100
    daily=[closes[i]/closes[i-1]-1 for i in range(1,len(closes))]
    vol=pstdev(daily[-60:])*sqrt(252)*100
    if last>ma200 and ma50>ma200 and ret63>0: state="BULL"
    elif last<ma200 and ma50<ma200 and ret63<0: state="BEAR"
    else: state="SIDEWAYS"
    return {"state":state,"confidence":"MEDIUM","price":last,"ma50":ma50,"ma200":ma200,
            "return_3m_pct":ret63,"volatility_annual_pct":vol,
            "reason":"가격·50일선·200일선·3개월 수익률의 방향 일치 여부로 분류"}

def _returns_by_date(bars):
    ordered=sorted(bars,key=lambda x:x["date"])
    closes={str(x["date"]):float(x["close"]) for x in ordered if x.get("close") and float(x["close"])>0}
    dates=sorted(closes)
    return {dates[i]:closes[dates[i]]/closes[dates[i-1]]-1 for i in range(1,len(dates))}

def correlation_matrix(series: dict[str,list[dict]], min_overlap: int=30) -> dict:
    returns={s:_returns_by_date(b) for s,b in series.items()}; names=list(returns); matrix={}
    for a in names:
        matrix[a]={}
        for b in names:
            common=sorted(set(returns[a])&set(returns[b]))
            if len(common)<min_overlap: matrix[a][b]=None; continue
            xa=[returns[a][d] for d in common]; xb=[returns[b][d] for d in common]
            ma=mean(xa); mb=mean(xb); da=sum((x-ma)**2 for x in xa); db=sum((x-mb)**2 for x in xb)
            matrix[a][b]=round(sum((x-ma)*(y-mb) for x,y in zip(xa,xb))/sqrt(da*db),4) if da and db else None
    return {"symbols":names,"overlap_min":min_overlap,"matrix":matrix}

def decide_candidates(candidates:list[dict], regime:dict, holdings:list[dict]|None=None,
                      max_candidates:int=5, correlations:dict|None=None, correlation_limit:float=.85,
                      sector_exposure_pct:dict|None=None, country_exposure_pct:dict|None=None,
                      max_position_pct:float=.15, max_sector_pct:float=.25,
                      max_country_pct:float=.40, sector_coverage_pct:float=100) -> list[dict]:
    holdings=holdings or []; correlations=correlations or {}
    if isinstance(correlations.get("matrix"), dict):
        correlations=correlations["matrix"]
    state=regime.get("state","UNKNOWN"); out=[]
    sector_exposure_pct=sector_exposure_pct or {}; country_exposure_pct=country_exposure_pct or {}
    for c in candidates:
        score=c.get("score"); coverage=c.get("coverage_pct",0); reasons=[]; blockers=[]
        if score is None: blockers.append("종합점수 없음")
        if coverage<60: blockers.append("데이터 커버리지 60% 미만")
        if c.get("fundamentals_required") and c.get("fundamentals_status") != "AVAILABLE":
            blockers.append("필수 재무 데이터 미확보")
        if c.get("etf_quality_required") and c.get("etf_quality_status") != "AVAILABLE":
            blockers.append("ETF 기초정보·비용 데이터 미확보")
        if c.get("holdings_required") and not c.get("holdings_loaded"):
            blockers.append("계좌 보유현황 미확보")
        if c.get("holdings_required") and c.get("holdings_loaded") and not c.get("holdings_history_complete"):
            blockers.append("기존 보유종목 가격이력 미확보")
        if c.get("open_order_pending"):
            blockers.append("동일 종목 미체결 매수주문 존재")
        if c.get("portfolio_exposure_required"):
            sector=c.get("sector")
            if not sector:
                blockers.append("후보 종목 섹터 정보 미확보")
            if sector_coverage_pct<90:
                blockers.append("기존 보유종목 섹터 분류 커버리지 90% 미만")
            elif sector and sector_exposure_pct.get(sector,0)+max_position_pct>max_sector_pct:
                blockers.append("신규 최대 비중 반영 시 섹터 한도 초과")
            country=c.get("market")
            if country_exposure_pct.get(country,0)+max_position_pct>max_country_pct:
                blockers.append("신규 최대 비중 반영 시 국가 한도 초과")
        if c.get("warnings_required") and c.get("warnings_status") != "CLEAR":
            blockers.append("토스 매수 유의사항 존재 또는 조회 실패")
        if c.get("status")!="OK": blockers.append("가격 데이터 상태 불량")
        if c.get("observations",0)<200: blockers.append("200거래일 미만")
        if c.get("price") and c.get("ma200") and c["price"]<c["ma200"]: blockers.append("현재가가 200일 이동평균 아래")
        if state=="BEAR": blockers.append("시장 국면 약세")
        if state=="UNKNOWN": blockers.append("시장 국면 판정 불가")
        if score is not None and score>=75: reasons.append("종합점수 상위 구간")
        if c.get("return_3m_pct") is not None and c["return_3m_pct"]>0: reasons.append("3개월 상승 모멘텀")
        if c.get("volatility_annual_pct") is not None and c["volatility_annual_pct"]>60: blockers.append("연환산 변동성 60% 초과")
        if any(h.get("symbol")==c.get("symbol") for h in holdings):
            blockers.append("이미 보유 중인 종목으로 신규매수 후보에서 제외")
        for h in holdings:
            hs=h.get("symbol")
            corr=(correlations.get(c.get("symbol"),{}) or {}).get(hs)
            if isinstance(corr,(int,float)) and corr>correlation_limit:
                blockers.append(f"보유종목 {hs}와 상관계수 {corr:.2f}로 집중 위험")
        action="BLOCKED" if blockers else ("BUY_CANDIDATE" if score>=75 else "WATCH")
        out.append({**c,"decision":action,"reasons":reasons,"blockers":blockers})
    eligible=[x for x in out if x["decision"]=="BUY_CANDIDATE"]
    eligible.sort(key=lambda x:(x.get("score",0),x.get("coverage_pct",0)),reverse=True)
    selected=[]
    for candidate in eligible:
        symbol=candidate.get("symbol")
        correlated_with=None
        for prior in selected:
            prior_symbol=prior.get("symbol")
            corr=(correlations.get(symbol,{}) or {}).get(prior_symbol)
            reverse=(correlations.get(prior_symbol,{}) or {}).get(symbol)
            value=corr if isinstance(corr,(int,float)) else reverse
            if isinstance(value,(int,float)) and value>correlation_limit:
                correlated_with=(prior_symbol,value); break
        if correlated_with:
            candidate["decision"]="WATCH"
            candidate["blockers"].append(
                f"선정 후보 {correlated_with[0]}와 상관계수 {correlated_with[1]:.2f}로 중복 위험"
            )
        elif len(selected)<max_candidates:
            selected.append(candidate)
        else:
            candidate["decision"]="WATCH"
            candidate["blockers"].append("상위 후보 수 제한")
    chosen={x.get("symbol") for x in selected}
    return sorted(out,key=lambda x:({"BUY_CANDIDATE":0,"WATCH":1,"BLOCKED":2}[x["decision"]],-(x.get("score") or -1)))
