"""Event-driven, long-only daily-bar backtester with next-session execution."""
from __future__ import annotations

from datetime import date
from math import floor, isfinite


def run_backtest(
    bars_by_symbol: dict[str, list[dict]],
    signals: list[dict],
    initial_capital: float = 6_000_000,
    score_threshold: float = 75,
    min_coverage_pct: float = 60,
    max_positions: int = 5,
    risk_per_trade_pct: float = 0.005,
    max_position_pct: float = 0.15,
    stop_loss_pct: float = 0.08,
    fee_bps: float = 0,
    slippage_bps: float = 0,
    max_drawdown_stop_pct: float = -10,
    max_holding_sessions: int = 60,
) -> dict:
    """Signals are known after a session close and execute no earlier than next open."""
    if initial_capital <= 0 or max_positions < 1:
        raise ValueError("initial_capital must be positive and max_positions >= 1")
    if not 0 < risk_per_trade_pct <= 0.05:
        raise ValueError("risk_per_trade_pct must be in (0, 5%]")
    if not 0 < max_position_pct <= 1:
        raise ValueError("max_position_pct must be in (0, 100%]")
    if not 0 < stop_loss_pct < 1:
        raise ValueError("stop_loss_pct must be between 0 and 100%")
    if not 0 <= fee_bps <= 500 or not 0 <= slippage_bps <= 500:
        raise ValueError("fee_bps and slippage_bps must be between 0 and 500")
    if not 0 <= score_threshold <= 100 or not 0 <= min_coverage_pct <= 100:
        raise ValueError("score_threshold and min_coverage_pct must be between 0 and 100")
    if not -100 <= max_drawdown_stop_pct <= 0:
        raise ValueError("max_drawdown_stop_pct must be between -100 and 0")
    if not 1 <= max_positions <= 50:
        raise ValueError("max_positions must be between 1 and 50")
    if max_holding_sessions < 1:
        raise ValueError("max_holding_sessions must be positive")
    if not isinstance(bars_by_symbol, dict) or not bars_by_symbol:
        raise ValueError("bars_by_symbol is required")

    normalized = {}
    all_dates = set()
    for symbol, rows in bars_by_symbol.items():
        if not isinstance(rows, list):
            raise ValueError(f"bars for {symbol} must be a list")
        by_date = {}
        for row in rows:
            try:
                day = date.fromisoformat(str(row["date"])[:10])
                o, h, l, c = (float(row[k]) for k in ("open", "high", "low", "close"))
                volume = float(row.get("volume") or 0)
            except (KeyError, TypeError, ValueError):
                continue
            if min(o, h, l, c) <= 0 or h < max(o, l, c) or l > min(o, h, c):
                continue
            if not all(isfinite(x) for x in (o, h, l, c, volume)):
                continue
            by_date[day] = {"date": day, "open": o, "high": h, "low": l,
                            "close": c, "volume": volume}
        normalized[symbol] = by_date
        all_dates.update(by_date)
    dates = sorted(all_dates)
    if len(dates) < 2:
        raise ValueError("At least two distinct trading dates are required")

    signal_map = {}
    for signal in signals:
        try:
            signal_day = date.fromisoformat(str(signal["date"])[:10])
            symbol = str(signal["symbol"])
            score = float(signal["score"])
            coverage = float(signal.get("coverage_pct", 0))
        except (KeyError, TypeError, ValueError):
            continue
        if symbol in normalized and isfinite(score) and isfinite(coverage):
            signal_map.setdefault(signal_day, []).append({
                "symbol": symbol, "score": score, "coverage_pct": coverage
            })

    due_signals = {}
    for signal_day, day_signals in signal_map.items():
        for signal in day_signals:
            symbol_dates = sorted(normalized[signal["symbol"]])
            next_session = next((d for d in symbol_dates if d > signal_day), None)
            if next_session is not None:
                due_signals.setdefault(next_session, []).append(signal)

    cash = float(initial_capital)
    positions = {}
    closed_trades = []
    equity_curve = []
    peak_equity = float(initial_capital)
    fee_rate = fee_bps / 10000
    slippage_rate = slippage_bps / 10000
    blocked_by_drawdown = 0
    exposure_sum = 0.0

    def mark_equity(day):
        value = cash
        exposure = 0.0
        for symbol, pos in positions.items():
            bar = normalized[symbol].get(day)
            if bar:
                market_value = pos["quantity"] * bar["close"]
                value += market_value
                exposure += market_value
            else:
                value += pos["quantity"] * pos["last_close"]
                exposure += pos["quantity"] * pos["last_close"]
        return value, exposure

    for index, day in enumerate(dates):
        # Exits first. Stops are triggered by the day's low; overnight gaps fill
        # at the open when worse than the stop, never at an impossible stop price.
        for symbol in list(positions):
            pos = positions[symbol]
            bar = normalized[symbol].get(day)
            if not bar:
                continue
            pos["last_close"] = bar["close"]
            held_sessions = index - pos["entry_index"]
            exit_price = None
            exit_reason = None
            if bar["low"] <= pos["stop_price"]:
                exit_price = min(bar["open"], pos["stop_price"]) * (1 - slippage_rate)
                exit_reason = "STOP"
            elif held_sessions >= max_holding_sessions:
                exit_price = bar["open"] * (1 - slippage_rate)
                exit_reason = "TIME"
            if exit_price is not None:
                gross = pos["quantity"] * exit_price
                fee = gross * fee_rate
                cash += gross - fee
                pnl = (gross - fee) - pos["entry_cost"]
                closed_trades.append({
                    "symbol": symbol, "entry_date": pos["entry_date"].isoformat(),
                    "exit_date": day.isoformat(), "entry_price": pos["entry_price"],
                    "exit_price": round(exit_price, 6), "quantity": pos["quantity"],
                    "pnl": round(pnl, 2), "return_pct": round(pnl / pos["entry_cost"] * 100, 2),
                    "reason": exit_reason,
                })
                del positions[symbol]

        # A close-of-day signal from the previous available date is executable
        # only at today's open. Signals dated today are not read until tomorrow.
        if day in due_signals:
            candidates = sorted(
                due_signals.get(day, []),
                key=lambda x: x["score"], reverse=True
            )
            current_equity, _ = mark_equity(day)
            peak_equity = max(peak_equity, current_equity)
            drawdown_pct = (current_equity / peak_equity - 1) * 100 if peak_equity else 0
            if drawdown_pct <= max_drawdown_stop_pct:
                blocked_by_drawdown += len(candidates)
            else:
                for signal in candidates:
                    symbol = signal["symbol"]
                    if len(positions) >= max_positions:
                        break
                    if symbol in positions or signal["score"] < score_threshold or signal["coverage_pct"] < min_coverage_pct:
                        continue
                    bar = normalized[symbol].get(day)
                    if not bar:
                        continue
                    entry_price = bar["open"] * (1 + slippage_rate)
                    stop_price = entry_price * (1 - stop_loss_pct)
                    risk_budget = current_equity * risk_per_trade_pct
                    per_share_risk = entry_price - stop_price + entry_price * (fee_rate * 2 + slippage_rate * 2)
                    risk_qty = floor(risk_budget / per_share_risk) if per_share_risk > 0 else 0
                    position_qty = floor(current_equity * max_position_pct / entry_price)
                    cash_qty = floor(cash / (entry_price * (1 + fee_rate)))
                    quantity = min(risk_qty, position_qty, cash_qty)
                    if quantity <= 0:
                        continue
                    gross_cost = quantity * entry_price
                    entry_fee = gross_cost * fee_rate
                    total_cost = gross_cost + entry_fee
                    cash -= total_cost
                    positions[symbol] = {
                        "quantity": quantity, "entry_price": entry_price,
                        "stop_price": stop_price, "entry_date": day,
                        "entry_index": index, "entry_cost": total_cost,
                        "last_close": bar["close"],
                    }
                    # A same-session low can hit the stop after an opening fill.
                    if bar["low"] <= stop_price:
                        exit_price = min(bar["open"], stop_price) * (1 - slippage_rate)
                        gross = quantity * exit_price
                        exit_fee = gross * fee_rate
                        cash += gross - exit_fee
                        pnl = (gross - exit_fee) - total_cost
                        closed_trades.append({
                            "symbol": symbol, "entry_date": day.isoformat(),
                            "exit_date": day.isoformat(), "entry_price": round(entry_price, 6),
                            "exit_price": round(exit_price, 6), "quantity": quantity,
                            "pnl": round(pnl, 2), "return_pct": round(pnl / total_cost * 100, 2),
                            "reason": "SAME_DAY_STOP",
                        })
                        del positions[symbol]
                    current_equity, _ = mark_equity(day)

        equity, exposure = mark_equity(day)
        peak_equity = max(peak_equity, equity)
        drawdown = (equity / peak_equity - 1) * 100 if peak_equity else 0
        exposure_sum += exposure / equity if equity > 0 else 0
        equity_curve.append({
            "date": day.isoformat(), "equity": round(equity, 2),
            "cash": round(cash, 2), "exposure": round(exposure, 2),
            "drawdown_pct": round(drawdown, 2),
        })

    final_equity = equity_curve[-1]["equity"]
    total_return = (final_equity / initial_capital - 1) * 100
    elapsed_days = max(1, (dates[-1] - dates[0]).days)
    cagr = ((final_equity / initial_capital) ** (365.25 / elapsed_days) - 1) * 100 if final_equity > 0 else -100
    wins = sum(1 for t in closed_trades if t["pnl"] > 0)
    max_dd = min((x["drawdown_pct"] for x in equity_curve), default=0)
    return {
        "initial_capital": round(initial_capital, 2),
        "final_equity": round(final_equity, 2),
        "total_return_pct": round(total_return, 2),
        "cagr_pct": round(cagr, 2),
        "max_drawdown_pct": round(max_dd, 2),
        "closed_trades": len(closed_trades),
        "open_positions": [{
            "symbol": symbol, "quantity": pos["quantity"],
            "entry_date": pos["entry_date"].isoformat(),
            "entry_price": round(pos["entry_price"], 6),
            "stop_price": round(pos["stop_price"], 6),
        } for symbol, pos in positions.items()],
        "win_rate_pct": round(wins / len(closed_trades) * 100, 2) if closed_trades else None,
        "average_exposure_pct": round(exposure_sum / len(equity_curve) * 100, 2),
        "blocked_signals_by_drawdown": blocked_by_drawdown,
        "trades": closed_trades,
        "equity_curve": equity_curve,
        "assumptions": {
            "execution": "Signal at close; entry at next session open; stop at stop price or worse open gap",
            "fee_bps_per_side": fee_bps,
            "slippage_bps_per_side": slippage_bps,
            "stop_loss_pct": stop_loss_pct * 100,
            "risk_per_trade_pct": risk_per_trade_pct * 100,
            "max_position_pct": max_position_pct * 100,
            "max_drawdown_stop_pct": max_drawdown_stop_pct,
            "max_holding_sessions": max_holding_sessions,
        },
        "warning": "Research backtest only. Survivorship bias, corporate actions, delisted symbols, historical point-in-time fundamentals, taxes, market impact and actual broker fills may not be fully represented.",
    }
