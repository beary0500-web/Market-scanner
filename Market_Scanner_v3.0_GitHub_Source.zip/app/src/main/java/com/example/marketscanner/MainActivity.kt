package com.example.marketscanner

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.net.URI
import java.net.URL
import javax.net.ssl.HttpsURLConnection
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val executor = Executors.newFixedThreadPool(2)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowContentAccess = false
        webView.settings.allowFileAccess = true
        webView.settings.allowFileAccessFromFileURLs = false
        webView.settings.allowUniversalAccessFromFileURLs = false
        webView.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean =
                url != "file:///android_asset/index.html"
        }
        webView.addJavascriptInterface(ScannerBridge(), "AndroidMarketData")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class ScannerBridge {
        private fun validateBase(raw: String): String {
            val uri = URI(raw.trim())
            require(uri.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null &&
                uri.query == null && uri.fragment == null && (uri.path.isNullOrEmpty() || uri.path == "/")) {
                "백엔드 주소는 경로가 없는 HTTPS 주소여야 합니다."
            }
            return raw.trim().trimEnd('/')
        }

        private fun callback(id: String, result: JSONObject) {
            val js = "window.__marketCallbacks && window.__marketCallbacks[" + JSONObject.quote(id) +
                "] && window.__marketCallbacks[" + JSONObject.quote(id) + "](" + result.toString() + ");"
            runOnUiThread { webView.evaluateJavascript(js, null) }
        }

        @JavascriptInterface
        fun fetchJson(rawUrl: String, callbackId: String) {
            executor.execute {
                val result = try {
                    val uri = URI(rawUrl)
                    require(uri.scheme == "https" && uri.path == "/health" && !uri.host.isNullOrBlank() &&
                        uri.userInfo == null && uri.query == null && uri.fragment == null) {
                        "허용되지 않은 서버 상태 확인 주소입니다."
                    }
                    val connection = (URL(rawUrl).openConnection() as HttpsURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 10000
                        readTimeout = 15000
                        setRequestProperty("Accept", "application/json")
                    }
                    try {
                        val code = connection.responseCode
                        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                        val body = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
                        if (code !in 200..299) throw Exception("서버 응답 오류 ($code): $body")
                        JSONObject(body)
                    } finally { connection.disconnect() }
                } catch (e: Exception) { JSONObject().put("error", e.message ?: "서버 연결 실패") }
                callback(callbackId, result)
            }
        }

        @JavascriptInterface
        fun scanFullUniverse(baseUrl: String, apiKey: String, requestJson: String, callbackId: String) {
            executor.execute {
                val result = try {
                    require(apiKey.isNotBlank() && apiKey.length <= 512) { "서버 API Key를 입력하세요." }
                    require(requestJson.length <= 100000) { "요청 데이터가 너무 큽니다." }
                    val endpoint = URL(validateBase(baseUrl) + "/scan/full-universe")
                    val connection = (endpoint.openConnection() as HttpsURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 15000
                        readTimeout = 600000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        setRequestProperty("Accept", "application/json")
                        setRequestProperty("X-API-Key", apiKey)
                    }
                    try {
                        connection.outputStream.use { it.write(requestJson.toByteArray(Charsets.UTF_8)) }
                        val code = connection.responseCode
                        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                        val body = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
                        if (code !in 200..299) throw Exception("분석 서버 오류 ($code): $body")
                        JSONObject(body)
                    } finally { connection.disconnect() }
                } catch (e: Exception) { JSONObject().put("error", e.message ?: "시장 분석 실패") }
                callback(callbackId, result)
            }
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        webView.removeJavascriptInterface("AndroidMarketData")
        webView.destroy()
        super.onDestroy()
    }
}
