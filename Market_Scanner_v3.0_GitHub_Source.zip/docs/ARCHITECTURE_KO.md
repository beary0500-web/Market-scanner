# Market Scanner 아키텍처

## 구성

```text
Android WebView App
  ├─ HTTPS + X-API-Key
  ├─ /scan/toss-ranked
  ├─ /toss/accounts, /toss/holdings, /toss/orders
  ├─ /toss/portfolio-summary
  ├─ /scan/score
  ├─ /risk/position-size
  └─ /backtest/run
          |
          v
FastAPI Backend (single worker)
  ├─ Toss OAuth token cache
  ├─ Toss market ranking / stock master / warnings / candles
  ├─ Toss account read-only endpoints
  ├─ SEC CompanyFacts adapter
  ├─ OpenDART adapter
  ├─ EODHD ETF Fundamentals adapter
  ├─ Nasdaq Trader US halt RSS adapter
  ├─ EODHD bulk whole-exchange snapshots + SQLite cache
  ├─ feature engineering + scoring
  ├─ regime + correlation + candidate gates
  ├─ risk sizing
  └─ event-driven backtest
```

## 스캔 데이터 흐름

1. 토스 랭킹 API에서 시장별 거래대금 상위 후보를 가져온다.
2. 종목 기본정보에서 활성 상태와 주식/ETF 유형을 확인한다.
3. 각 후보의 수정주가 일봉을 최대 600개까지 페이지네이션으로 수집한다.
4. 한국 종목은 토스 매수 유의사항/VI API를 조회한다. 조회 실패 종목은 결과 후보에서 제외한다. 미국 종목의 거래정지·경고 데이터는 아직 통합되지 않았다.
5. KOSPI 또는 SPY 벤치마크로 시장 국면을 분류한다.
6. 동일 시장 후보 및 선택 계좌 보유종목의 수익률 상관관계를 계산한다.
7. 사용자가 선택한 경우 상위 후보에 한해 SEC/OpenDART 재무정보를 추가한다.
8. 종가 기준 기술·모멘텀·위험·유동성·재무·밸류에이션 점수를 계산한다.
9. 필수 재무정보, ETF 기초정보, 경고, 보유종목 이력, 미체결 매수주문, 시장 국면, 상관관계 조건을 통과한 후보만 `BUY_CANDIDATE`로 표시한다.

`BUY_CANDIDATE`는 자동 주문 명령이 아니다. 현재 앱은 계좌 조회·보유 조회·미체결 주문 조회만 수행하며 주문 생성/취소 API는 구현하지 않았다.

## 신뢰 경계

- Android 앱에는 Toss Client ID/Secret을 넣지 않는다.
- Toss 인증은 백엔드 환경변수에서만 수행한다.
- Android 앱에는 개인 백엔드 `API_KEY`를 세션 동안 입력하며 디스크에 저장하지 않는다.
- 모든 백엔드 요청은 HTTPS만 허용한다.
- 백엔드 API는 `X-API-Key`를 검증하고, 키가 없으면 fail-closed 한다.
- WebView는 번들된 `file:///android_asset/index.html`만 로드하고 외부 페이지 이동을 차단한다.
- 백엔드는 Toss 인증 토큰을 한 프로세스에서 공유한다. 멀티워커/다중 인스턴스 배포 전에는 분산 토큰 저장소가 필요하다.

## 후보 판정 게이트

매수 검토 후보는 아래 항목을 모두 통과해야 한다.

- 가격 데이터 상태 정상, 최소 200개 관측치
- 종합점수 및 데이터 커버리지 기준 충족
- 시장 국면이 BEAR/UNKNOWN이 아님
- 가격이 200일 이동평균 위
- 필수 재무 데이터 확보
- ETF인 경우 EODHD ETF Fundamentals에서 비용·순자산·보유종목 수 등 필수 품질 데이터 확보 (공급자 권한/필수 데이터가 없으면 ETF는 매수 검토 후보에서 차단)
- 토스 매수 유의사항 조회 결과 CLEAR
- 계좌를 선택했다면 보유종목 데이터와 가격 이력 확보
- 동일 종목 미체결 매수주문 없음
- 동일 시장 내 후보/보유종목 상관관계 제한 통과

## 알려진 구조적 한계

- 토스 랭킹은 상위 후보 목록이며 거래소 전체 종목 마스터가 아니다.
- 후보는 랭킹 기반 상위 100개/시장으로 제한된다.
- ETF 비용·순자산·보유종목 수·상위 보유비중은 EODHD ETF Fundamentals에서 조회한다. 공급자 권한 또는 필수 필드가 없으면 매수 후보를 차단한다. 추적오차 시계열은 아직 별도 검증이 필요하다.
- 섹터·국가 익스포저는 계좌 보유종목과 현재 종목 마스터 분류를 기준으로 추정한다. 미분류 비중이 10% 이상이면 후보를 차단하지만, 미체결 주문의 전체 예상 익스포저·미결제 현금·세금·환전 스프레드는 완전하게 통합하지 않았다.
- 전체 거래소 기술 스캔은 EODHD Bulk EOD + 거래소 종목 마스터로 구현했으며, 유료 데이터 권한·호출 예산·영속 SQLite 볼륨이 없으면 비활성이다.
- 과거 시점별 유니버스, 상장폐지, 기업행위, 과거 재무공시 시점을 완전하게 복원하지 못해 백테스트에 생존편향/미래정보 편향이 남을 수 있다.
