# 배포 전 체크리스트

## 필수 인프라

1. 고정된 outbound IPv4를 제공하는 서버를 준비한다.
2. 해당 IP를 Toss Open API 허용 IP에 등록한다.
3. HTTPS 도메인과 TLS 인증서를 준비한다.
4. FastAPI를 단일 worker로 실행한다. Toss Client Credentials 토큰은 한 프로세스에서만 공유된다.
5. 방화벽에서 백엔드 HTTPS 포트만 공개하고 SSH는 관리자 IP로 제한한다.
6. 서버 로그에 API Key, Client Secret, 계좌번호, 보유내역 전체를 기록하지 않는다.

GitHub Actions runner와 모바일 데이터 IP는 고정 출구 IP로 보장되지 않으므로 Toss 실 API 서버로 사용하지 않는다.

## 환경변수

서버 Secret Manager 또는 보호된 환경변수에 설정한다.

- `API_KEY`: Android 앱에서 사용하는 백엔드 접근키
- `TOSS_CLIENT_ID`
- `TOSS_CLIENT_SECRET`
- `SEC_USER_AGENT`: 실제 앱 식별자 및 모니터링 가능한 연락처
- `DART_API_KEY`
- `KRX_AUTH_KEY`
- `EODAPI_TOKEN` (기존 EODAPI 단일 종목 시세 어댑터, 선택)
- `EODHD_API_TOKEN` (EODHD ETF Fundamentals 및 전체 거래소 Bulk EOD)
- `EODHD_BULK_CALL_UNITS_PER_RUN` (일회 실행 예산, 기본 0=비활성)
- `MARKET_DATA_DB=/data/market_scanner.sqlite3`

실제 `.env` 파일은 저장소에 커밋하지 않는다. `.env.example`만 저장소에 둔다.

## 실행

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --host 127.0.0.1 --port 8000 --workers 1
```

앞단의 Nginx/Caddy 등 TLS reverse proxy에서 HTTPS를 종료하고, 백엔드 포트는 외부에 직접 공개하지 않는다. Docker 배포 시 `/data`를 영속 볼륨으로 마운트해야 Bulk EOD 캐시가 재시작 후에도 유지된다.

EODHD Bulk EOD는 거래소·일자 스냅샷당 100 API call units를 사용한다. 1년 평일 기준 대략 거래소 하나당 26,000 units다. 한국은 KO(KOSPI)+KQ(KOSDAQ) 두 거래소이므로 약 52,000 units, 미국 US까지 함께 스캔하면 약 78,000 units가 필요할 수 있다. EODHD 요금제와 잔여 quota를 확인한 뒤 `EODHD_BULK_CALL_UNITS_PER_RUN`을 설정한다. 무료 EODAPI 키가 곧 EODHD Bulk 권한을 의미하지 않으며 두 인증변수는 분리되어 있다.

## 배포 검증

- `/health` 200 응답
- 잘못된 `X-API-Key` 401 응답
- `API_KEY` 미설정 시 보호 API 503 응답
- Toss provider status configured 확인
- Toss 계좌 목록에서 계좌번호 마스킹 확인
- KRW/USD 매수 가능 금액 및 환율 변환 대조
- KOSPI/SPY benchmark candle history 확보
- `/scan/toss-ranked` 오류율·응답시간·요청량 확인
- SEC/DART 데이터 일부 표본을 원문 공시와 대조
- Android HTTPS 연결 및 API Key 미저장 확인
- 백테스트 입력·수수료·슬리피지·갭 처리 검증

## 실계좌 주문

현재 주문 생성·수정·취소는 의도적으로 비활성이다. 주문 기능을 구현하기 전에는 별도 설계와 검증이 필요하다.

- 사용자가 승인한 정확한 종목·방향·수량·가격·계좌를 서명/만료가 있는 승인 토큰으로 묶는다.
- 서버가 승인 직전 현금, 보유수량, 미체결 주문, 종목 경고, 거래시간, 주문 가능 수량을 재검증한다.
- idempotency key와 영속 주문 원장을 사용해 중복 주문을 방지한다.
- 주문 제출 결과와 체결/부분체결/취소 상태를 대조한다.
- 독립 kill switch, 일일 손실 한도, 최대 주문 금액, 감사 로그를 둔다.
- paper trading 및 장기간 모의 운영 후 별도 승인 절차를 거친다.

이 체크리스트가 충족되기 전에는 실계좌 주문을 활성화하지 않는다.
