# GitHub 업로드 안내 — Market Scanner v2.1-dev

대상 저장소: `beary0500-web/Market-scanner`

이 패키지는 GitHub에 업로드할 프로젝트 루트 전체입니다. 아직 원격 저장소에 반영되거나 APK 빌드가 성공한 상태는 아닙니다.

## 업로드 절차

1. 이 ZIP을 PC에서 압축 해제합니다. 압축을 풀었을 때 `README_KO.md`, `app/`, `backend/`, `.github/`가 바로 보여야 합니다.
2. GitHub에서 `beary0500-web/Market-scanner`를 엽니다.
3. `main`을 직접 덮어쓰지 말고 `v2.1-dev` 브랜치를 새로 만듭니다.
4. 압축 해제한 폴더의 **내용 전체**를 저장소 루트에 업로드합니다. `ms_work/` 같은 상위 폴더를 한 겹 더 만들지 않습니다.
5. GitHub Actions에서 `Backend tests`와 `Android debug build`를 실행합니다.
6. 두 워크플로가 성공하면 Android 워크플로의 `market-scanner-v2-debug-apk` artifact를 내려받아 실제 Android 기기에 설치·검증합니다.
7. 검증 결과와 `docs/RELEASE_GATE_KO.md`를 확인한 뒤 PR을 생성합니다.

## 보안 주의

- `.env`, Toss Client ID/Secret, 계좌번호, API 키, 실제 사용자 데이터는 업로드하지 않습니다.
- `backend/.env.example`은 예시 설정 파일이며 실제 비밀값을 넣지 않습니다.
- API 키는 GitHub Actions 일반 로그나 APK에 넣지 않습니다.

## 현재 상태

- 버전 표기: `2.1-dev`
- Android 빌드 워크플로: 포함(실제 GitHub Actions 실행 결과는 업로드 후 확인 필요)
- Android APK: 이 패키지에 포함하지 않음. 성공한 Actions 빌드 artifact에서 취득
- 자동주문: 미구현. 주문은 사용자가 직접 실행
- 서버 자동 스케줄러 및 FCM 푸시: 미구현
- 실제 SEC/DART/KRX/EODHD/Toss 연동: 자격증명 기반 통합시험 미실시

이 저장소는 개발·검증 후보이며 실거래 운용 준비 완료를 의미하지 않습니다.
