package com.example.marketscanner

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URI
import javax.net.ssl.HttpsURLConnection
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val executor = Executors.newFixedThreadPool(3)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowContentAccess = false
        webView.settings.allowFileAccess = true
        webView.settings.allowFileAccessFromFileURLs = false
        webView.settings.allowUniversalAccessFromFileURLs = false
        webView.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                // Keep the JavaScript bridge available only to the bundled local app.
                return url != "file:///android_asset/index.html"
            }
        }
        webView.addJavascriptInterface(NativeMarketData(), "AndroidMarketData")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class NativeMarketData {
        @JavascriptInterface
        fun scoreWithBackend(baseUrl: String, apiKey: String, requestJson: String, callbackId: String) {
            executor.execute {
                val result = try {
                    require(apiKey.isNotBlank() && apiKey.length <= 512) { "API Key를 확인하세요." }
                    require(requestJson.length <= 2_000_000) { "요청 데이터가 너무 큽니다." }
                    val uri = URI(baseUrl.trim())
                    require(uri.scheme == "https" && !uri.host.isNullOrBlank() &&
                        uri.userInfo == null && uri.query == null && uri.fragment == null &&
                        (uri.path.isNullOrEmpty() || uri.path == "/")) {
                        "백엔드 주소는 경로가 없는 HTTPS 주소여야 합니다."
                    }
                    val endpoint = URL(baseUrl.trim().trimEnd('/') + "/scan/score")
                    val connection = (endpoint.openConnection() as HttpsURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 10000
                        readTimeout = 30000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        setRequestProperty("Accept", "application/json")
                        setRequestProperty("X-API-Key", apiKey)
                    }
                    try {
                        connection.outputStream.use { it.write(requestJson.toByteArray(Charsets.UTF_8)) }
                        val code = connection.responseCode
                        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                        val body = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
                        if (code !in 200..299) throw Exception("백엔드 응답 오류 ($code): $body")
                        JSONObject(body)
                    } finally {
                        connection.disconnect()
                    }
                } catch (e: Exception) {
                    JSONObject().put("error", e.message ?: "백엔드 점수 계산 실패")
                }
                val js = "window.__marketCallbacks && window.__marketCallbacks[" +
                    JSONObject.quote(callbackId) + "] && window.__marketCallbacks[" +
                    JSONObject.quote(callbackId) + "](" + result.toString() + ");"
                runOnUiThread { webView.evaluateJavascript(js, null) }
            }
        }

        @JavascriptInterface
        fun getTossReadOnly(baseUrl: String, apiKey: String, path: String, callbackId: String) {
            executor.execute {
                val result = try {
                    require(apiKey.isNotBlank() && apiKey.length <= 512) { "API Key를 확인하세요." }
                    val allowed = path == "/toss/accounts" ||
                        Regex("^/toss/holdings\\?account_seq=[1-9][0-9]*$").matches(path) ||
                        Regex("^/toss/buying-power\\?account_seq=[1-9][0-9]*&currency=(KRW|USD)$").matches(path) ||
                        Regex("^/toss/portfolio-summary\\?account_seq=[1-9][0-9]*$").matches(path) ||
                        Regex("^/toss/orders\\?account_seq=[1-9][0-9]*&status=OPEN$").matches(path)
                    require(allowed) { "허용되지 않은 읽기 전용 경로입니다." }
                    val uri = URI(baseUrl.trim())
                    require(uri.scheme == "https" && !uri.host.isNullOrBlank() &&
                        uri.userInfo == null && uri.query == null && uri.fragment == null &&
                        (uri.path.isNullOrEmpty() || uri.path == "/")) {
                        "백엔드 주소는 경로가 없는 HTTPS 주소여야 합니다."
                    }
                    val endpoint = URL(baseUrl.trim().trimEnd('/') + path)
                    val connection = (endpoint.openConnection() as HttpsURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 10000
                        readTimeout = 30000
                        setRequestProperty("Accept", "application/json")
                        setRequestProperty("X-API-Key", apiKey)
                    }
                    try {
                        val code = connection.responseCode
                        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                        val body = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
                        if (code !in 200..299) throw Exception("백엔드 응답 오류 ($code): $body")
                        JSONObject(body)
                    } finally {
                        connection.disconnect()
                    }
                } catch (e: Exception) {
                    JSONObject().put("error", e.message ?: "계좌 정보 조회 실패")
                }
                val js = "window.__marketCallbacks && window.__marketCallbacks[" +
                    JSONObject.quote(callbackId) + "] && window.__marketCallbacks[" +
                    JSONObject.quote(callbackId) + "](" + result.toString() + ");"
                runOnUiThread { webView.evaluateJavascript(js, null) }
            }
        }

        @JavascriptInterface
        fun watchlistRequest(baseUrl: String, apiKey: String, method: String, requestJson: String, callbackId: String) {
            executor.execute {
                val result = try {
                    require(apiKey.isNotBlank() && apiKey.length <= 512) { "API Key를 확인하세요." }
                    require(method in listOf("GET", "PUT", "POST")) { "허용되지 않은 메서드입니다." }
                    require(requestJson.length <= 100_000) { "요청 데이터가 너무 큽니다." }
                    val uri = URI(baseUrl.trim())
                    require(uri.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null && uri.query == null && uri.fragment == null && (uri.path.isNullOrEmpty() || uri.path == "/")) { "백엔드 주소는 경로가 없는 HTTPS 주소여야 합니다." }
                    val path = when (method) { "GET" -> "/watchlist"; "PUT" -> "/watchlist"; else -> "/watchlist/scan" }
                    val connection = (URL(baseUrl.trim().trimEnd('/') + path).openConnection() as HttpsURLConnection).apply {
                        requestMethod = method; connectTimeout = 10000; readTimeout = 90000
                        setRequestProperty("Accept", "application/json"); setRequestProperty("X-API-Key", apiKey)
                        if (method != "GET") { doOutput = true; setRequestProperty("Content-Type", "application/json; charset=utf-8") }
                    }
                    try {
                        if (method != "GET") connection.outputStream.use { it.write(requestJson.toByteArray(Charsets.UTF_8)) }
                        val code = connection.responseCode
                        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                        val body = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
                        if (code !in 200..299) throw Exception("백엔드 응답 오류 ($code): $body")
                        JSONObject(body)
                    } finally { connection.disconnect() }
                } catch (e: Exception) { JSONObject().put("error", e.message ?: "관찰목록 처리 실패") }
                val js = "window.__marketCallbacks && window.__marketCallbacks[" + JSONObject.quote(callbackId) + "] && window.__marketCallbacks[" + JSONObject.quote(callbackId) + "](" + result.toString() + ");"
                runOnUiThread { webView.evaluateJavascript(js, null) }
            }
        }

        @JavascriptInterface
        fun scanTossRanked(baseUrl: String, apiKey: String, requestJson: String, callbackId: String) {
            executor.execute {
                val result = try {
                    require(apiKey.isNotBlank() && apiKey.length <= 512) { "API Key를 확인하세요." }
                    require(requestJson.length <= 100_000) { "요청 데이터가 너무 큽니다." }
                    val uri = URI(baseUrl.trim())
                    require(uri.scheme == "https" && !uri.host.isNullOrBlank() &&
                        uri.userInfo == null && uri.query == null && uri.fragment == null &&
                        (uri.path.isNullOrEmpty() || uri.path == "/")) {
                        "백엔드 주소는 경로가 없는 HTTPS 주소여야 합니다."
                    }
                    val endpoint = URL(baseUrl.trim().trimEnd('/') + "/scan/toss-ranked")
                    val connection = (endpoint.openConnection() as HttpsURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 10000
                        readTimeout = 180000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        setRequestProperty("Accept", "application/json")
                        setRequestProperty("X-API-Key", apiKey)
                    }
                    try {
                        connection.outputStream.use { it.write(requestJson.toByteArray(Charsets.UTF_8)) }
                        val code = connection.responseCode
                        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                        val body = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
                        if (code !in 200..299) throw Exception("백엔드 응답 오류 ($code): $body")
                        JSONObject(body)
                    } finally {
                        connection.disconnect()
                    }
                } catch (e: Exception) {
                    JSONObject().put("error", e.message ?: "랭킹 기반 종목 스캔 실패")
                }
                val js = "window.__marketCallbacks && window.__marketCallbacks[" +
                    JSONObject.quote(callbackId) + "] && window.__marketCallbacks[" +
                    JSONObject.quote(callbackId) + "](" + result.toString() + ");"
                runOnUiThread { webView.evaluateJavascript(js, null) }
            }
        }

        @JavascriptInterface
        fun scanFullUniverse(baseUrl: String, apiKey: String, requestJson: String, callbackId: String) {
            executor.execute {
                val result = try {
                    require(apiKey.isNotBlank() && apiKey.length <= 512) { "API Key를 확인하세요." }
                    require(requestJson.length <= 100_000) { "요청 데이터가 너무 큽니다." }
                    val uri = URI(baseUrl.trim())
                    require(uri.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null &&
                        uri.query == null && uri.fragment == null && (uri.path.isNullOrEmpty() || uri.path == "/")) {
                        "백엔드 주소는 경로가 없는 HTTPS 주소여야 합니다."
                    }
                    val endpoint = URL(baseUrl.trim().trimEnd('/') + "/scan/full-universe")
                    val connection = (endpoint.openConnection() as HttpsURLConnection).apply {
                        requestMethod = "POST"; connectTimeout = 10000; readTimeout = 600000; doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        setRequestProperty("Accept", "application/json"); setRequestProperty("X-API-Key", apiKey)
                    }
                    try {
                        connection.outputStream.use { it.write(requestJson.toByteArray(Charsets.UTF_8)) }
                        val code = connection.responseCode
                        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                        val body = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
                        if (code !in 200..299) throw Exception("백엔드 응답 오류 ($code): $body")
                        JSONObject(body)
                    } finally { connection.disconnect() }
                } catch (e: Exception) { JSONObject().put("error", e.message ?: "전체 시장 스캔 실패") }
                val js = "window.__marketCallbacks && window.__marketCallbacks[" + JSONObject.quote(callbackId) +
                    "] && window.__marketCallbacks[" + JSONObject.quote(callbackId) + "](" + result.toString() + ");"
                runOnUiThread { webView.evaluateJavascript(js, null) }
            }
        }

        @JavascriptInterface
        fun runFullUniverseBacktest(baseUrl: String, apiKey: String, requestJson: String, callbackId: String) {
            executor.execute {
                val result = try {
                    require(apiKey.isNotBlank() && apiKey.length <= 512) { "API Key를 확인하세요." }
                    require(requestJson.length <= 100_000) { "요청 데이터가 너무 큽니다." }
                    val uri = URI(baseUrl.trim())
                    require(uri.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null &&
                        uri.query == null && uri.fragment == null && (uri.path.isNullOrEmpty() || uri.path == "/")) {
                        "백엔드 주소는 경로가 없는 HTTPS 주소여야 합니다."
                    }
                    val endpoint = URL(baseUrl.trim().trimEnd('/') + "/backtest/full-universe")
                    val connection = (endpoint.openConnection() as HttpsURLConnection).apply {
                        requestMethod = "POST"; connectTimeout = 10000; readTimeout = 600000; doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        setRequestProperty("Accept", "application/json"); setRequestProperty("X-API-Key", apiKey)
                    }
                    try {
                        connection.outputStream.use { it.write(requestJson.toByteArray(Charsets.UTF_8)) }
                        val code = connection.responseCode
                        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                        val body = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
                        if (code !in 200..299) throw Exception("백엔드 응답 오류 ($code): $body")
                        JSONObject(body)
                    } finally { connection.disconnect() }
                } catch (e: Exception) { JSONObject().put("error", e.message ?: "전체 시장 백테스트 실패") }
                val js = "window.__marketCallbacks && window.__marketCallbacks[" + JSONObject.quote(callbackId) +
                    "] && window.__marketCallbacks[" + JSONObject.quote(callbackId) + "](" + result.toString() + ");"
                runOnUiThread { webView.evaluateJavascript(js, null) }
            }
        }

        @JavascriptInterface
        fun sizePositionWithBackend(baseUrl: String, apiKey: String, requestJson: String, callbackId: String) {
            executor.execute {
                val result = try {
                    require(apiKey.isNotBlank() && apiKey.length <= 512) { "API Key를 확인하세요." }
                    require(requestJson.length <= 100_000) { "요청 데이터가 너무 큽니다." }
                    val uri = URI(baseUrl.trim())
                    require(uri.scheme == "https" && !uri.host.isNullOrBlank() &&
                        uri.userInfo == null && uri.query == null && uri.fragment == null &&
                        (uri.path.isNullOrEmpty() || uri.path == "/")) {
                        "백엔드 주소는 경로가 없는 HTTPS 주소여야 합니다."
                    }
                    val endpoint = URL(baseUrl.trim().trimEnd('/') + "/risk/position-size")
                    val connection = (endpoint.openConnection() as HttpsURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 10000
                        readTimeout = 20000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        setRequestProperty("Accept", "application/json")
                        setRequestProperty("X-API-Key", apiKey)
                    }
                    try {
                        connection.outputStream.use { it.write(requestJson.toByteArray(Charsets.UTF_8)) }
                        val code = connection.responseCode
                        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                        val body = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
                        if (code !in 200..299) throw Exception("백엔드 응답 오류 ($code): $body")
                        JSONObject(body)
                    } finally {
                        connection.disconnect()
                    }
                } catch (e: Exception) {
                    JSONObject().put("error", e.message ?: "위험 수량 계산 실패")
                }
                val js = "window.__marketCallbacks && window.__marketCallbacks[" +
                    JSONObject.quote(callbackId) + "] && window.__marketCallbacks[" +
                    JSONObject.quote(callbackId) + "](" + result.toString() + ");"
                runOnUiThread { webView.evaluateJavascript(js, null) }
            }
        }

        @JavascriptInterface
        fun fetchJson(rawUrl: String, callbackId: String) {
            executor.execute {
                val result = try {
                    val url = URL(rawUrl)
                    require(url.protocol == "https" && url.host == "query1.finance.yahoo.com") {
                        "허용되지 않은 데이터 주소입니다."
                    }
                    val connection = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 10000
                        readTimeout = 15000
                        setRequestProperty("User-Agent", "Mozilla/5.0 MarketScanner/1.0")
                        setRequestProperty("Accept", "application/json")
                    }
                    try {
                        val code = connection.responseCode
                        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                        val body = stream.bufferedReader().use { it.readText() }
                        if (code !in 200..299) throw Exception("시세 서버 응답 오류 ($code)")
                        JSONObject().put("data", JSONObject(body))
                    } finally {
                        connection.disconnect()
                    }
                } catch (e: Exception) {
                    JSONObject().put("error", e.message ?: "데이터 조회 실패")
                }
                val js = "window.__marketCallbacks && window.__marketCallbacks[" +
                    JSONObject.quote(callbackId) + "] && window.__marketCallbacks[" +
                    JSONObject.quote(callbackId) + "](" + result.toString() + ");"
                runOnUiThread { webView.evaluateJavascript(js, null) }
            }
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        webView.removeJavascriptInterface("AndroidMarketData")
        webView.destroy()
        super.onDestroy()
    }
}
