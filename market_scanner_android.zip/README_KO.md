# Market Scanner Android v1.0

기존 Market Scanner HTML을 Android WebView 앱에 포함한 프로젝트입니다.

## 포함 기능
- 앱 내부 HTML 대시보드
- Android 네이티브 HTTPS 요청 브리지
- Yahoo Finance 검색 및 차트 데이터 조회 시도
- CSV 가져오기 및 기술지표 계산

## 중요 제한
- 이 앱은 토스증권 API에 연결되지 않습니다.
- 매매 주문 기능이 없습니다.
- Yahoo Finance 비공식 인터페이스의 이용 가능성·응답 형식은 변경될 수 있습니다.
- 네이티브 네트워크 브리지는 `query1.finance.yahoo.com` 호스트만 허용합니다.
- Client ID / Client Secret을 앱에 넣지 마세요.
- 실계좌 자동매매를 위해서는 별도의 보안 서버, 고정 IP 및 토스 API 허용 IP 등록 검증이 필요합니다.

## APK 빌드
GitHub 저장소에 프로젝트 파일을 업로드한 뒤 Actions 탭에서 `Build Android APK` 워크플로를 실행합니다.
완료되면 `market-scanner-debug-apk` 아티팩트에서 APK를 내려받을 수 있습니다.

로컬 빌드가 가능한 경우 Android Studio에서 프로젝트를 열고 `:app:assembleDebug`를 실행합니다.
