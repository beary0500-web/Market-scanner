package com.example.marketscanner

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val executor = Executors.newFixedThreadPool(3)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(NativeMarketData(), "AndroidMarketData")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class NativeMarketData {
        @JavascriptInterface
        fun fetchJson(rawUrl: String, callbackId: String) {
            executor.execute {
                val result = try {
                    val url = URL(rawUrl)
                    require(url.protocol == "https" && url.host == "query1.finance.yahoo.com") {
                        "허용되지 않은 데이터 주소입니다."
                    }
                    val connection = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 10000
                        readTimeout = 15000
                        setRequestProperty("User-Agent", "Mozilla/5.0 MarketScanner/1.0")
                        setRequestProperty("Accept", "application/json")
                    }
                    try {
                        val code = connection.responseCode
                        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                        val body = stream.bufferedReader().use { it.readText() }
                        if (code !in 200..299) throw Exception("시세 서버 응답 오류 ($code)")
                        JSONObject().put("data", JSONObject(body))
                    } finally {
                        connection.disconnect()
                    }
                } catch (e: Exception) {
                    JSONObject().put("error", e.message ?: "데이터 조회 실패")
                }
                val js = "window.__marketCallbacks && window.__marketCallbacks[" +
                    JSONObject.quote(callbackId) + "] && window.__marketCallbacks[" +
                    JSONObject.quote(callbackId) + "](" + result.toString() + ");"
                runOnUiThread { webView.evaluateJavascript(js, null) }
            }
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        webView.removeJavascriptInterface("AndroidMarketData")
        webView.destroy()
        super.onDestroy()
    }
}
